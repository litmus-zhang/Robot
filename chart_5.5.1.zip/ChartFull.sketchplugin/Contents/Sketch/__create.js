var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/create.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/createChart.html":
/*!*********************************!*\
  !*** ./assets/createChart.html ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "file://" + String(context.scriptPath).split(".sketchplugin/Contents/Sketch")[0] + ".sketchplugin/Contents/Resources/_webpack_resources/e3e5ddf8adc19177299dbe22c0a31e12.html";

/***/ }),

/***/ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var error;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          error
        );
        if (error != null) {
          return reject(error);
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, error) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          if (error) {
            finished = true;
            return reject(error);
          }
          return resolve(response(res, data));
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/index.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Dialog
(https://github.com/electron/electron/blob/master/docs/api/dialog.md) */

module.exports = {
  showOpenDialog: __webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js").openDialog,
  showOpenDialogSync: __webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js").openDialogSync,
  showSaveDialog: __webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js").saveDialog,
  showSaveDialogSync: __webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js").saveDialogSync,
  showMessageBox: __webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js").messageBox,
  showMessageBoxSync: __webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js").messageBoxSync,
  // showErrorBox: require('./error-box'),
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/message-box.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/message-box.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

var typeMap = {
  none: 0,
  info: 1,
  error: 2,
  question: 1,
  warning: 2,
}

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  } else if (document.sketchObject) {
    document = document.sketchObject
  }
  if (!options) {
    options = {}
  }

  var dialog = NSAlert.alloc().init()

  if (options.type) {
    dialog.alertStyle = typeMap[options.type] || 0
  }

  if (options.buttons && options.buttons.length) {
    options.buttons.forEach(function addButton(button) {
      dialog.addButtonWithTitle(
        options.normalizeAccessKeys ? button.replace(/&/g, '') : button
      )
      // TODO: add keyboard shortcut if options.normalizeAccessKeys
    })
  }

  if (typeof options.defaultId !== 'undefined') {
    var buttons = dialog.buttons()
    if (options.defaultId < buttons.length) {
      // Focus the button at defaultId if the user opted to do so.
      // The first button added gets set as the default selected.
      // So remove that default, and make the requested button the default.
      buttons[0].setKeyEquivalent('')
      buttons[options.defaultId].setKeyEquivalent('\r')
    }
  }

  if (options.title) {
    // not shown on macOS
  }

  if (options.message) {
    dialog.messageText = options.message
  }

  if (options.detail) {
    dialog.informativeText = options.detail
  }

  if (options.checkboxLabel) {
    dialog.showsSuppressionButton = true
    dialog.suppressionButton().title = options.checkboxLabel

    if (typeof options.checkboxChecked !== 'undefined') {
      dialog.suppressionButton().state = options.checkboxChecked
        ? NSOnState
        : NSOffState
    }
  }

  if (options.icon) {
    if (typeof options.icon === 'string') {
      options.icon = NSImage.alloc().initWithContentsOfFile(options.icon)
    }
    dialog.icon = options.icon
  } else if (
    typeof __command !== 'undefined' &&
    __command.pluginBundle() &&
    __command.pluginBundle().icon()
  ) {
    dialog.icon = __command.pluginBundle().icon()
  } else {
    var icon = NSImage.imageNamed('plugins')
    if (icon) {
      dialog.icon = icon
    }
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxbrowserwindow-options
module.exports.messageBox = function messageBox(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        response:
          setup.options.buttons && setup.options.buttons.length
            ? Number(returnCode) - 1000
            : Number(returnCode),
        checkboxChecked: _dialog.suppressionButton().state() == NSOnState,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxsyncbrowserwindow-options
module.exports.messageBoxSync = function messageBoxSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return setup.options.buttons && setup.options.buttons.length
        ? Number(returnCode) - 1000
        : Number(returnCode)
    },
    setup.document
  )
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/open-dialog.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/open-dialog.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSOpenPanel.openPanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  if (options.properties && options.properties.length) {
    options.properties.forEach(function setProperty(p) {
      if (p === 'openFile') {
        dialog.canChooseFiles = true
      } else if (p === 'openDirectory') {
        dialog.canChooseDirectories = true
      } else if (p === 'multiSelections') {
        dialog.allowsMultipleSelection = true
      } else if (p === 'showHiddenFiles') {
        dialog.showsHiddenFiles = true
      } else if (p === 'createDirectory') {
        dialog.canCreateDirectories = true
      } else if (p === 'noResolveAliases') {
        dialog.resolvesAliases = false
      } else if (p === 'treatPackageAsDirectory') {
        dialog.treatsFilePackagesAsDirectories = true
      }
    })
  }

  if (options.message) {
    dialog.message = options.message
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogbrowserwindow-options
module.exports.openDialog = function openDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return {
          canceled: true,
          filePaths: [],
        }
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return {
        canceled: false,
        filePaths: result,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogsyncbrowserwindow-options
module.exports.openDialogSync = function openDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return []
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return result
    },
    setup.document
  )
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/save-dialog.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/save-dialog.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSSavePanel.savePanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    // that's a path
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))

    if (
      options.defaultPath[0] === '.' ||
      options.defaultPath[0] === '~' ||
      options.defaultPath[0] === '/'
    ) {
      var parts = options.defaultPath.split('/')
      if (parts.length > 1 && parts[parts.length - 1]) {
        dialog.setNameFieldStringValue(parts[parts.length - 1])
      }
    } else {
      dialog.setNameFieldStringValue(options.defaultPath)
    }
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  if (options.message) {
    dialog.message = options.message
  }

  if (options.nameFieldLabel) {
    dialog.nameFieldLabel = options.nameFieldLabel
  }

  if (options.showsTagField) {
    dialog.showsTagField = options.showsTagField
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogbrowserwindow-options
module.exports.saveDialog = function saveDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        canceled: returnCode != NSOKButton,
        filePath:
          returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogsyncbrowserwindow-options
module.exports.saveDialogSync = function saveDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined
    },
    setup.document
  )
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/utils.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/utils.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {module.exports.getURL = function getURL(path) {
  return NSURL.URLWithString(
    String(
      NSString.stringWithString(path).stringByExpandingTildeInPath()
    ).replace(/ /g, '%20')
  )
}

module.exports.runDialog = function runDialog(dialog, getResult, document) {
  if (!document) {
    var returnCode = dialog.runModal()
    return Promise.resolve(getResult(dialog, returnCode))
  }

  var fiber = coscript.createFiber()

  var window = (document.sketchObject || document).documentWindow()

  return new Promise(function p(resolve, reject) {
    dialog.beginSheetModalForWindow_completionHandler(
      window,
      __mocha__.createBlock_function('v16@?0q8', function onCompletion(
        _returnCode
      ) {
        try {
          resolve(getResult(dialog, _returnCode))
        } catch (err) {
          reject(err)
        }
        NSApp.endSheet(dialog)
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      })
    )
  })
}

module.exports.runDialogSync = function runDialog(dialog, getResult, document) {
  var returnCode

  if (!document) {
    returnCode = dialog.runModal()
    return getResult(dialog, returnCode)
  }

  var window = (document.sketchObject || document).documentWindow()

  dialog.beginSheetModalForWindow_completionHandler(
    window,
    __mocha__.createBlock_function('v16@?0q8', function onCompletion(
      _returnCode
    ) {
      NSApp.stopModalWithCode(_returnCode)
    })
  )

  returnCode = NSApp.runModalForWindow(window)
  NSApp.endSheet(dialog)
  return getResult(dialog, returnCode)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/mocha-js-delegate/index.js":
/*!*************************************************!*\
  !*** ./node_modules/mocha-js-delegate/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* globals MOClassDescription, NSObject, NSSelectorFromString, NSClassFromString, MOPropertyDescription */

module.exports = function MochaDelegate(definition, superclass) {
  var uniqueClassName =
    'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
    uniqueClassName,
    superclass || NSObject
  )

  // Storage
  var handlers = {}
  var ivars = {}

  // Define an instance method
  function setHandlerForSelector(selectorString, func) {
    var handlerHasBeenSet = selectorString in handlers
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      // eslint-disable-next-line no-eval
      var dynamicFunction = eval(
        '(function (' +
          args.join(', ') +
          ') { return handlers[selectorString].apply(this, arguments); })'
      )

      delegateClassDesc.addInstanceMethodWithSelector_function(
        selector,
        dynamicFunction
      )
    }
  }

  // define a property
  function setIvar(key, value) {
    var ivarHasBeenSet = key in handlers

    ivars[key] = value

    if (!ivarHasBeenSet) {
      delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, '@')
      var description = MOPropertyDescription.new()
      description.name = key
      description.typeEncoding = '@'
      description.weak = true
      description.ivarName = key
      delegateClassDesc.addProperty(description)
    }
  }

  this.getClass = function() {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function(instanceVariables) {
    var instance = NSClassFromString(uniqueClassName).new()
    Object.keys(ivars).forEach(function(key) {
      instance[key] = ivars[key]
    })
    Object.keys(instanceVariables || {}).forEach(function(key) {
      instance[key] = instanceVariables[key]
    })
    return instance
  }
  // alias
  this.new = this.getClassInstance

  // Convenience
  if (typeof definition === 'object') {
    Object.keys(definition).forEach(
      function(key) {
        if (typeof definition[key] === 'function') {
          setHandlerForSelector(key, definition[key])
        } else {
          setIvar(key, definition[key])
        }
      }
    )
  }

  delegateClassDesc.registerClass()
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/browser-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/browser-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function parseHexColor(color) {
  // Check the string for incorrect formatting.
  if (!color || color[0] !== '#') {
    if (
      color &&
      typeof color.isKindOfClass === 'function' &&
      color.isKindOfClass(NSColor)
    ) {
      return color
    }
    throw new Error(
      'Incorrect color formating. It should be an hex color: #RRGGBBAA'
    )
  }

  // append FF if alpha channel is not specified.
  var source = color.substr(1)
  if (source.length === 3) {
    source += 'F'
  } else if (source.length === 6) {
    source += 'FF'
  }
  // Convert the string from #FFF format to #FFFFFF format.
  var hex
  if (source.length === 4) {
    for (var i = 0; i < 4; i += 1) {
      hex += source[i]
      hex += source[i]
    }
  } else if (source.length === 8) {
    hex = source
  } else {
    return NSColor.whiteColor()
  }

  var r = parseInt(hex.slice(0, 2), 16)
  var g = parseInt(hex.slice(2, 4), 16)
  var b = parseInt(hex.slice(4, 6), 16)
  var a = parseInt(hex.slice(6, 8), 16)

  return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a)
}

module.exports = function(browserWindow, panel, webview) {
  // keep reference to the subviews
  browserWindow._panel = panel
  browserWindow._webview = webview
  browserWindow._destroyed = false

  browserWindow.destroy = function() {
    return panel.close()
  }

  browserWindow.close = function() {
    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      var shouldClose = true
      browserWindow.emit('close', {
        get defaultPrevented() {
          return !shouldClose
        },
        preventDefault: function() {
          shouldClose = false
        },
      })
      if (shouldClose) {
        panel.delegate().utils.parentWindow.endSheet(panel)
      }
      return
    }

    if (!browserWindow.isClosable()) {
      return
    }

    panel.performClose(null)
  }

  function focus(focused) {
    if (!browserWindow.isVisible()) {
      return
    }
    if (focused) {
      NSApplication.sharedApplication().activateIgnoringOtherApps(true)
      panel.makeKeyAndOrderFront(null)
    } else {
      panel.orderBack(null)
      NSApp.mainWindow().makeKeyAndOrderFront(null)
    }
  }

  browserWindow.focus = focus.bind(this, true)
  browserWindow.blur = focus.bind(this, false)

  browserWindow.isFocused = function() {
    return panel.isKeyWindow()
  }

  browserWindow.isDestroyed = function() {
    return browserWindow._destroyed
  }

  browserWindow.show = function() {
    // This method is supposed to put focus on window, however if the app does not
    // have focus then "makeKeyAndOrderFront" will only show the window.
    NSApp.activateIgnoringOtherApps(true)

    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
        panel,
        __mocha__.createBlock_function('v16@?0q8', function() {
          browserWindow.emit('closed')
        })
      )
    }

    return panel.makeKeyAndOrderFront(null)
  }

  browserWindow.showInactive = function() {
    return panel.orderFrontRegardless()
  }

  browserWindow.hide = function() {
    return panel.orderOut(null)
  }

  browserWindow.isVisible = function() {
    return panel.isVisible()
  }

  browserWindow.isModal = function() {
    return false
  }

  browserWindow.maximize = function() {
    if (!browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }
  browserWindow.unmaximize = function() {
    if (browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }

  browserWindow.isMaximized = function() {
    if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
      return panel.isZoomed()
    }
    var rectScreen = NSScreen.mainScreen().visibleFrame()
    var rectWindow = panel.frame()
    return (
      rectScreen.origin.x == rectWindow.origin.x &&
      rectScreen.origin.y == rectWindow.origin.y &&
      rectScreen.size.width == rectWindow.size.width &&
      rectScreen.size.height == rectWindow.size.height
    )
  }

  browserWindow.minimize = function() {
    return panel.miniaturize(null)
  }

  browserWindow.restore = function() {
    return panel.deminiaturize(null)
  }

  browserWindow.isMinimized = function() {
    return panel.isMiniaturized()
  }

  browserWindow.setFullScreen = function(fullscreen) {
    if (fullscreen !== browserWindow.isFullscreen()) {
      panel.toggleFullScreen(null)
    }
  }

  browserWindow.isFullscreen = function() {
    return panel.styleMask() & NSFullScreenWindowMask
  }

  browserWindow.setAspectRatio = function(aspectRatio /* , extraSize */) {
    // Reset the behaviour to default if aspect_ratio is set to 0 or less.
    if (aspectRatio > 0.0) {
      panel.setAspectRatio(NSMakeSize(aspectRatio, 1.0))
    } else {
      panel.setResizeIncrements(NSMakeSize(1.0, 1.0))
    }
  }

  browserWindow.setBounds = function(bounds, animate) {
    if (!bounds) {
      return
    }

    // Do nothing if in fullscreen mode.
    if (browserWindow.isFullscreen()) {
      return
    }

    const newBounds = Object.assign(browserWindow.getBounds(), bounds)

    // TODO: Check size constraints since setFrame does not check it.
    // var size = bounds.size
    // size.SetToMax(GetMinimumSize());
    // gfx::Size max_size = GetMaximumSize();
    // if (!max_size.IsEmpty())
    //   size.SetToMin(max_size);

    var cocoaBounds = NSMakeRect(
      newBounds.x,
      0,
      newBounds.width,
      newBounds.height
    )
    // Flip Y coordinates based on the primary screen
    var screen = NSScreen.screens().firstObject()
    cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y

    panel.setFrame_display_animate(cocoaBounds, true, animate)
  }

  browserWindow.getBounds = function() {
    const cocoaBounds = panel.frame()
    var mainScreenRect = NSScreen.screens()
      .firstObject()
      .frame()
    return {
      x: cocoaBounds.origin.x,
      y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
      width: cocoaBounds.size.width,
      height: cocoaBounds.size.height,
    }
  }

  browserWindow.setContentBounds = function(bounds, animate) {
    // TODO:
    browserWindow.setBounds(bounds, animate)
  }

  browserWindow.getContentBounds = function() {
    // TODO:
    return browserWindow.getBounds()
  }

  browserWindow.setSize = function(width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setBounds({ width: width, height: height }, animate)
  }

  browserWindow.getSize = function() {
    var bounds = browserWindow.getBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setContentSize = function(width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setContentBounds(
      { width: width, height: height },
      animate
    )
  }

  browserWindow.getContentSize = function() {
    var bounds = browserWindow.getContentBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setMinimumSize = function(width, height) {
    const minSize = CGSizeMake(width, height)
    panel.setContentMinSize(minSize)
  }

  browserWindow.getMinimumSize = function() {
    const size = panel.contentMinSize()
    return [size.width, size.height]
  }

  browserWindow.setMaximumSize = function(width, height) {
    const maxSize = CGSizeMake(width, height)
    panel.setContentMaxSize(maxSize)
  }

  browserWindow.getMaximumSize = function() {
    const size = panel.contentMaxSize()
    return [size.width, size.height]
  }

  browserWindow.setResizable = function(resizable) {
    return browserWindow._setStyleMask(resizable, NSResizableWindowMask)
  }

  browserWindow.isResizable = function() {
    return panel.styleMask() & NSResizableWindowMask
  }

  browserWindow.setMovable = function(movable) {
    return panel.setMovable(movable)
  }
  browserWindow.isMovable = function() {
    return panel.isMovable()
  }

  browserWindow.setMinimizable = function(minimizable) {
    return browserWindow._setStyleMask(minimizable, NSMiniaturizableWindowMask)
  }

  browserWindow.isMinimizable = function() {
    return panel.styleMask() & NSMiniaturizableWindowMask
  }

  browserWindow.setMaximizable = function(maximizable) {
    if (panel.standardWindowButton(NSWindowZoomButton)) {
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable)
    }
  }

  browserWindow.isMaximizable = function() {
    return (
      panel.standardWindowButton(NSWindowZoomButton) &&
      panel.standardWindowButton(NSWindowZoomButton).isEnabled()
    )
  }

  browserWindow.setFullScreenable = function(fullscreenable) {
    browserWindow._setCollectionBehavior(
      fullscreenable,
      NSWindowCollectionBehaviorFullScreenPrimary
    )
    // On EL Capitan this flag is required to hide fullscreen button.
    browserWindow._setCollectionBehavior(
      !fullscreenable,
      NSWindowCollectionBehaviorFullScreenAuxiliary
    )
  }

  browserWindow.isFullScreenable = function() {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary
  }

  browserWindow.setClosable = function(closable) {
    browserWindow._setStyleMask(closable, NSClosableWindowMask)
  }

  browserWindow.isClosable = function() {
    return panel.styleMask() & NSClosableWindowMask
  }

  browserWindow.setAlwaysOnTop = function(top, level, relativeLevel) {
    var windowLevel = NSNormalWindowLevel
    var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey)
    var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey)

    if (top) {
      if (level === 'normal') {
        windowLevel = NSNormalWindowLevel
      } else if (level === 'torn-off-menu') {
        windowLevel = NSTornOffMenuWindowLevel
      } else if (level === 'modal-panel') {
        windowLevel = NSModalPanelWindowLevel
      } else if (level === 'main-menu') {
        windowLevel = NSMainMenuWindowLevel
      } else if (level === 'status') {
        windowLevel = NSStatusWindowLevel
      } else if (level === 'pop-up-menu') {
        windowLevel = NSPopUpMenuWindowLevel
      } else if (level === 'screen-saver') {
        windowLevel = NSScreenSaverWindowLevel
      } else if (level === 'dock') {
        // Deprecated by macOS, but kept for backwards compatibility
        windowLevel = NSDockWindowLevel
      } else {
        windowLevel = NSFloatingWindowLevel
      }
    }

    var newLevel = windowLevel + (relativeLevel || 0)
    if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
      panel.setLevel(newLevel)
    } else {
      throw new Error(
        'relativeLevel must be between ' +
          minWindowLevel +
          ' and ' +
          maxWindowLevel
      )
    }
  }

  browserWindow.isAlwaysOnTop = function() {
    return panel.level() !== NSNormalWindowLevel
  }

  browserWindow.moveTop = function() {
    return panel.orderFrontRegardless()
  }

  browserWindow.center = function() {
    panel.center()
  }

  browserWindow.setPosition = function(x, y, animate) {
    return browserWindow.setBounds({ x: x, y: y }, animate)
  }

  browserWindow.getPosition = function() {
    var bounds = browserWindow.getBounds()
    return [bounds.x, bounds.y]
  }

  browserWindow.setTitle = function(title) {
    panel.setTitle(title)
  }

  browserWindow.getTitle = function() {
    return String(panel.title())
  }

  var attentionRequestId = 0
  browserWindow.flashFrame = function(flash) {
    if (flash) {
      attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest)
    } else {
      NSApp.cancelUserAttentionRequest(attentionRequestId)
      attentionRequestId = 0
    }
  }

  browserWindow.getNativeWindowHandle = function() {
    return panel
  }

  browserWindow.getNativeWebViewHandle = function() {
    return webview
  }

  browserWindow.loadURL = function(url) {
    // When frameLocation is a file, prefix it with the Sketch Resources path
    if (/^(?!https?|file).*\.html?$/.test(url)) {
      if (typeof __command !== 'undefined' && __command.pluginBundle()) {
        url =
          'file://' +
          __command
            .pluginBundle()
            .urlForResourceNamed(url)
            .path()
      }
    }

    if (/^file:\/\/.*\.html?$/.test(url)) {
      // ensure URLs containing spaces are properly handled
      url = NSString.alloc().initWithString(url)
      url = url.stringByAddingPercentEncodingWithAllowedCharacters(
        NSCharacterSet.URLQueryAllowedCharacterSet()
      )
      webview.loadFileURL_allowingReadAccessToURL(
        NSURL.URLWithString(url),
        NSURL.URLWithString('file:///')
      )
      return
    }

    const properURL = NSURL.URLWithString(url)
    const urlRequest = NSURLRequest.requestWithURL(properURL)

    webview.loadRequest(urlRequest)
  }

  browserWindow.reload = function() {
    webview.reload()
  }

  browserWindow.setHasShadow = function(hasShadow) {
    return panel.setHasShadow(hasShadow)
  }

  browserWindow.hasShadow = function() {
    return panel.hasShadow()
  }

  browserWindow.setOpacity = function(opacity) {
    return panel.setAlphaValue(opacity)
  }

  browserWindow.getOpacity = function() {
    return panel.alphaValue()
  }

  browserWindow.setVisibleOnAllWorkspaces = function(visible) {
    return browserWindow._setCollectionBehavior(
      visible,
      NSWindowCollectionBehaviorCanJoinAllSpaces
    )
  }

  browserWindow.isVisibleOnAllWorkspaces = function() {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces
  }

  browserWindow.setIgnoreMouseEvents = function(ignore) {
    return panel.setIgnoresMouseEvents(ignore)
  }

  browserWindow.setContentProtection = function(enable) {
    panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly)
  }

  browserWindow.setAutoHideCursor = function(autoHide) {
    panel.setDisableAutoHideCursor(autoHide)
  }

  browserWindow.setVibrancy = function(type) {
    var effectView = browserWindow._vibrantView

    if (!type) {
      if (effectView == null) {
        return
      }

      effectView.removeFromSuperview()
      panel.setVibrantView(null)
      return
    }

    if (effectView == null) {
      var contentView = panel.contentView()
      effectView = NSVisualEffectView.alloc().initWithFrame(
        contentView.bounds()
      )
      browserWindow._vibrantView = effectView

      effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
      effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow)
      effectView.setState(NSVisualEffectStateActive)
      effectView.setFrame(contentView.bounds())
      contentView.addSubview_positioned_relativeTo(
        effectView,
        NSWindowBelow,
        null
      )
    }

    var vibrancyType = NSVisualEffectMaterialLight

    if (type === 'appearance-based') {
      vibrancyType = NSVisualEffectMaterialAppearanceBased
    } else if (type === 'light') {
      vibrancyType = NSVisualEffectMaterialLight
    } else if (type === 'dark') {
      vibrancyType = NSVisualEffectMaterialDark
    } else if (type === 'titlebar') {
      vibrancyType = NSVisualEffectMaterialTitlebar
    } else if (type === 'selection') {
      vibrancyType = NSVisualEffectMaterialSelection
    } else if (type === 'menu') {
      vibrancyType = NSVisualEffectMaterialMenu
    } else if (type === 'popover') {
      vibrancyType = NSVisualEffectMaterialPopover
    } else if (type === 'sidebar') {
      vibrancyType = NSVisualEffectMaterialSidebar
    } else if (type === 'medium-light') {
      vibrancyType = NSVisualEffectMaterialMediumLight
    } else if (type === 'ultra-dark') {
      vibrancyType = NSVisualEffectMaterialUltraDark
    }

    effectView.setMaterial(vibrancyType)
  }

  browserWindow._setBackgroundColor = function(colorName) {
    var color = parseHexColor(colorName)
    webview.setValue_forKey(false, 'drawsBackground')
    panel.backgroundColor = color
  }

  browserWindow._invalidate = function() {
    panel.flushWindow()
    panel.contentView().setNeedsDisplay(true)
  }

  browserWindow._setStyleMask = function(on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setStyleMask(panel.styleMask() | flag)
    } else {
      panel.setStyleMask(panel.styleMask() & ~flag)
    }
    // Change style mask will make the zoom button revert to default, probably
    // a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._setCollectionBehavior = function(on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setCollectionBehavior(panel.collectionBehavior() | flag)
    } else {
      panel.setCollectionBehavior(panel.collectionBehavior() & ~flag)
    }
    // Change collectionBehavior will make the zoom button revert to default,
    // probably a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._showWindowButton = function(button) {
    var view = panel.standardWindowButton(button)
    view.superview().addSubview_positioned_relative(view, NSWindowAbove, null)
  }
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/constants.js":
/*!**************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/constants.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  JS_BRIDGE: '__skpm_sketchBridge',
  START_MOVING_WINDOW: '__skpm_startMovingWindow',
  EXECUTE_JAVASCRIPT: '__skpm_executeJS',
  EXECUTE_JAVASCRIPT_SUCCESS: '__skpm_executeJS_success_',
  EXECUTE_JAVASCRIPT_ERROR: '__skpm_executeJS_error_',
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js":
/*!*************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/dispatch-first-click.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var tagsToFocus =
  '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]'

module.exports = function(webView, event) {
  var point = webView.convertPoint_fromView(event.locationInWindow(), null)
  return (
    'var el = document.elementFromPoint(' + // get the DOM element that match the event
    point.x +
    ', ' +
    point.y +
    '); ' +
    'if (el && ' + // some tags need to be focused instead of clicked
    tagsToFocus +
    '.indexOf(el.type) >= 0 && ' +
    'el.focus' +
    ') {' +
    'el.focus();' + // so focus them
    '} else if (el) {' +
    'el.dispatchEvent(new Event("click", {bubbles: true}))' + // click the others
    '}'
  )
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/execute-javascript.js":
/*!***********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/execute-javascript.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function(webview, browserWindow) {
  function executeJavaScript(script, userGesture, callback) {
    if (typeof userGesture === 'function') {
      callback = userGesture
      userGesture = false
    }
    var fiber = coscript.createFiber()

    // if the webview is not ready yet, defer the execution until it is
    if (
      webview.navigationDelegate().state &&
      webview.navigationDelegate().state.wasReady == 0
    ) {
      return new Promise(function(resolve, reject) {
        browserWindow.once('ready-to-show', function() {
          executeJavaScript(script, userGesture, callback)
            .then(resolve)
            .catch(reject)
          fiber.cleanup()
        })
      })
    }

    return new Promise(function(resolve, reject) {
      var requestId = Math.random()

      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
        function(res) {
          try {
            if (callback) {
              callback(null, res)
            }
            resolve(res)
          } catch (err) {
            reject(err)
          }
          fiber.cleanup()
        }
      )
      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
        function(err) {
          try {
            if (callback) {
              callback(err)
              resolve()
            } else {
              reject(err)
            }
          } catch (err2) {
            reject(err2)
          }
          fiber.cleanup()
        }
      )

      webview.evaluateJavaScript_completionHandler(
        module.exports.wrapScript(script, requestId),
        null
      )
    })
  }

  return executeJavaScript
}

module.exports.wrapScript = function(script, requestId) {
  return (
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    '(' +
    requestId +
    ', ' +
    JSON.stringify(script) +
    ')'
  )
}

module.exports.injectScript = function(webView) {
  var source =
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    ' = function(id, script) {' +
    '  try {' +
    '    var res = eval(script);' +
    '    if (res && typeof res.then === "function" && typeof res.catch === "function") {' +
    '      res.then(function (res2) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res2);' +
    '      })' +
    '      .catch(function (err) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '      })' +
    '    } else {' +
    '      window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res);' +
    '    }' +
    '  } catch (err) {' +
    '    window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '  }' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView
    .configuration()
    .userContentController()
    .addUserScript(script)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/fitSubview.js":
/*!***************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/fitSubview.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(
    NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
      subview,
      edge,
      NSLayoutRelationEqual,
      view,
      edge,
      1,
      constant
    )
  )
}
module.exports = function fitSubviewToView(subview, view, constants) {
  constants = constants || []
  subview.setTranslatesAutoresizingMaskIntoConstraints(false)

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0)
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0)
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0)
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Browser window
(https://github.com/electron/electron/blob/master/docs/api/browser-window.md) */
var EventEmitter = __webpack_require__(/*! events */ "events")
var buildBrowserAPI = __webpack_require__(/*! ./browser-api */ "./node_modules/sketch-module-web-view/lib/browser-api.js")
var buildWebAPI = __webpack_require__(/*! ./webview-api */ "./node_modules/sketch-module-web-view/lib/webview-api.js")
var fitSubviewToView = __webpack_require__(/*! ./fitSubview */ "./node_modules/sketch-module-web-view/lib/fitSubview.js")
var dispatchFirstClick = __webpack_require__(/*! ./dispatch-first-click */ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js")
var injectClientMessaging = __webpack_require__(/*! ./inject-client-messaging */ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js")
var movableArea = __webpack_require__(/*! ./movable-area */ "./node_modules/sketch-module-web-view/lib/movable-area.js")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")
var setDelegates = __webpack_require__(/*! ./set-delegates */ "./node_modules/sketch-module-web-view/lib/set-delegates.js")

function BrowserWindow(options) {
  options = options || {}

  var identifier = options.identifier || NSUUID.UUID().UUIDString()
  var threadDictionary = NSThread.mainThread().threadDictionary()

  var existingBrowserWindow = BrowserWindow.fromId(identifier)

  // if we already have a window opened, reuse it
  if (existingBrowserWindow) {
    return existingBrowserWindow
  }

  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (options.modal && !options.parent) {
    throw new Error('A modal needs to have a parent.')
  }

  // Long-running script
  var fiber = coscript.createFiber()

  // Window size
  var width = options.width || 800
  var height = options.height || 600
  var mainScreenRect = NSScreen.screens()
    .firstObject()
    .frame()
  var cocoaBounds = NSMakeRect(
    typeof options.x !== 'undefined'
      ? options.x
      : Math.round((NSWidth(mainScreenRect) - width) / 2),
    typeof options.y !== 'undefined'
      ? NSHeight(mainScreenRect) - options.y
      : Math.round((NSHeight(mainScreenRect) - height) / 2),
    width,
    height
  )

  if (options.titleBarStyle && options.titleBarStyle !== 'default') {
    options.frame = false
  }

  var useStandardWindow = options.windowType !== 'textured'
  var styleMask = NSTitledWindowMask

  // this is commented out because the toolbar doesn't appear otherwise :thinking-face:
  // if (!useStandardWindow || options.frame === false) {
  //   styleMask = NSFullSizeContentViewWindowMask
  // }
  if (options.minimizable !== false) {
    styleMask |= NSMiniaturizableWindowMask
  }
  if (options.closable !== false) {
    styleMask |= NSClosableWindowMask
  }
  if (options.resizable !== false) {
    styleMask |= NSResizableWindowMask
  }
  if (!useStandardWindow || options.transparent || options.frame === false) {
    styleMask |= NSTexturedBackgroundWindowMask
  }

  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
    cocoaBounds,
    styleMask,
    NSBackingStoreBuffered,
    true
  )

  var wkwebviewConfig = WKWebViewConfiguration.alloc().init()
  var webView = WKWebView.alloc().initWithFrame_configuration(
    CGRectMake(0, 0, options.width || 800, options.height || 600),
    wkwebviewConfig
  )
  injectClientMessaging(webView)
  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  setDelegates(browserWindow, panel, webView, options)

  if (options.windowType === 'desktop') {
    panel.setLevel(kCGDesktopWindowLevel - 1)
    // panel.setCanBecomeKeyWindow(false)
    panel.setCollectionBehavior(
      NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorStationary |
        NSWindowCollectionBehaviorIgnoresCycle
    )
  }

  if (
    typeof options.minWidth !== 'undefined' ||
    typeof options.minHeight !== 'undefined'
  ) {
    browserWindow.setMinimumSize(options.minWidth || 0, options.minHeight || 0)
  }

  if (
    typeof options.maxWidth !== 'undefined' ||
    typeof options.maxHeight !== 'undefined'
  ) {
    browserWindow.setMaximumSize(
      options.maxWidth || 10000,
      options.maxHeight || 10000
    )
  }

  // if (options.focusable === false) {
  //   panel.setCanBecomeKeyWindow(false)
  // }

  if (options.transparent || options.frame === false) {
    panel.titlebarAppearsTransparent = true
    panel.titleVisibility = NSWindowTitleHidden
    panel.setOpaque(0)
    panel.isMovableByWindowBackground = true
    var toolbar2 = NSToolbar.alloc().initWithIdentifier(
      'titlebarStylingToolbar'
    )
    toolbar2.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar2)
  }

  if (options.titleBarStyle === 'hiddenInset') {
    var toolbar = NSToolbar.alloc().initWithIdentifier('titlebarStylingToolbar')
    toolbar.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar)
  }

  if (options.frame === false || !options.useContentSize) {
    browserWindow.setSize(width, height)
  }

  if (options.center) {
    browserWindow.center()
  }

  if (options.alwaysOnTop) {
    browserWindow.setAlwaysOnTop(true)
  }

  if (options.fullscreen) {
    browserWindow.setFullScreen(true)
  }
  browserWindow.setFullScreenable(!!options.fullscreenable)

  const title =
    options.title ||
    (typeof __command !== 'undefined' && __command.pluginBundle()
      ? __command.pluginBundle().name()
      : undefined)
  if (title) {
    browserWindow.setTitle(title)
  }

  var backgroundColor = options.backgroundColor
  if (options.transparent) {
    backgroundColor = NSColor.clearColor()
  }
  if (!backgroundColor && options.frame === false && options.vibrancy) {
    backgroundColor = NSColor.clearColor()
  }

  browserWindow._setBackgroundColor(
    backgroundColor || NSColor.windowBackgroundColor()
  )

  if (options.hasShadow === false) {
    browserWindow.setHasShadow(false)
  }

  if (typeof options.opacity !== 'undefined') {
    browserWindow.setOpacity(options.opacity)
  }

  options.webPreferences = options.webPreferences || {}

  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.devTools !== false,
      'developerExtrasEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.javascript !== false,
      'javaScriptEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(!!options.webPreferences.plugins, 'plugInsEnabled')
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.minimumFontSize || 0,
      'minimumFontSize'
    )

  if (options.webPreferences.zoomFactor) {
    webView.setMagnification(options.webPreferences.zoomFactor)
  }

  var contentView = panel.contentView()

  if (options.frame !== false) {
    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)
  } else {
    // In OSX 10.10, adding subviews to the root view for the NSView hierarchy
    // produces warnings. To eliminate the warnings, we resize the contentView
    // to fill the window, and add subviews to that.
    // http://crbug.com/380412
    contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
    fitSubviewToView(contentView, contentView.superview())

    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)

    // The fullscreen button should always be hidden for frameless window.
    if (panel.standardWindowButton(NSWindowFullScreenButton)) {
      panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true)
    }

    if (!options.titleBarStyle || options.titleBarStyle === 'default') {
      // Hide the window buttons.
      panel.standardWindowButton(NSWindowZoomButton).setHidden(true)
      panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true)
      panel.standardWindowButton(NSWindowCloseButton).setHidden(true)

      // Some third-party macOS utilities check the zoom button's enabled state to
      // determine whether to show custom UI on hover, so we disable it here to
      // prevent them from doing so in a frameless app window.
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(false)
    }
  }

  if (options.vibrancy) {
    browserWindow.setVibrancy(options.vibrancy)
  }

  // Set maximizable state last to ensure zoom button does not get reset
  // by calls to other APIs.
  browserWindow.setMaximizable(options.maximizable !== false)

  panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false)

  if (options.remembersWindowFrame) {
    panel.setFrameAutosaveName(identifier)
    panel.setFrameUsingName_force(panel.frameAutosaveName(), false)
  }

  if (options.acceptsFirstMouse) {
    browserWindow.on('focus', function(event) {
      if (event.type() === NSEventTypeLeftMouseDown) {
        browserWindow.webContents
          .executeJavaScript(dispatchFirstClick(webView, event))
          .catch(() => {})
      }
    })
  }

  executeJavaScript.injectScript(webView)
  movableArea.injectScript(webView)
  movableArea.setupHandler(browserWindow)

  if (options.show !== false) {
    browserWindow.show()
  }

  browserWindow.on('closed', function() {
    browserWindow._destroyed = true
    threadDictionary.removeObjectForKey(identifier)
    fiber.cleanup()
  })

  threadDictionary[identifier] = panel

  fiber.onCleanup(function() {
    if (!browserWindow._destroyed) {
      browserWindow.destroy()
    }
  })

  return browserWindow
}

BrowserWindow.fromId = function(identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary()

  if (threadDictionary[identifier]) {
    return BrowserWindow.fromPanel(threadDictionary[identifier], identifier)
  }

  return undefined
}

BrowserWindow.fromPanel = function(panel, identifier) {
  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (!panel || !panel.contentView) {
    throw new Error('needs to pass an NSPanel')
  }

  var webView = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webView &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webView = subviews[i]
    }
  }

  if (!webView) {
    throw new Error('The panel needs to have a webview')
  }

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)

  return browserWindow
}

module.exports = BrowserWindow


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js":
/*!****************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/inject-client-messaging.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function(webView) {
  var source =
    'window.originalPostMessage = window.postMessage;' +
    'window.postMessage = function(actionName) {' +
    'if (!actionName) {' +
    "throw new Error('missing action name')" +
    '}' +
    'window.webkit.messageHandlers.' +
    CONSTANTS.JS_BRIDGE +
    '.postMessage(' +
    'JSON.stringify([].slice.call(arguments))' +
    ');' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView
    .configuration()
    .userContentController()
    .addUserScript(script)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/movable-area.js":
/*!*****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/movable-area.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports.injectScript = function(webView) {
  var source =
    '(function () {' +
    "document.addEventListener('mousedown', onMouseDown);" +
    '' +
    'function shouldDrag(target) {' +
    '  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }' +
    '  if ((target.dataset || {}).appRegion === "drag") { return true }' +
    '  return shouldDrag(target.parentElement)' +
    '};' +
    '' +
    'function onMouseDown(e) {console.log(e);' +
    '  if (e.button !== 0 || !shouldDrag(e.target)) { return }' +
    '  window.postMessage("' +
    CONSTANTS.START_MOVING_WINDOW +
    '");' +
    '};' +
    '})()'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView
    .configuration()
    .userContentController()
    .addUserScript(script)
}

module.exports.setupHandler = function(browserWindow) {
  var initialMouseLocation = null
  var initialWindowPosition = null
  var interval = null

  function moveWindow() {
    // if the user released the button, stop moving the window
    if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
      clearInterval(interval)
      initialMouseLocation = null
      initialWindowPosition = null
      return
    }

    var mouse = NSEvent.mouseLocation()
    browserWindow.setPosition(
      initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
      initialWindowPosition.y + (initialMouseLocation.y - mouse.y), // y is inverted
      false
    )
  }

  browserWindow.webContents.on(CONSTANTS.START_MOVING_WINDOW, function() {
    initialMouseLocation = NSEvent.mouseLocation()
    var position = browserWindow.getPosition()
    initialWindowPosition = {
      x: position[0],
      y: position[1],
    }

    interval = setInterval(moveWindow, 1000 / 60) // 60 fps
  })
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js":
/*!**********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/parseWebArguments.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function(webArguments) {
  var args = null
  try {
    args = JSON.parse(webArguments)
  } catch (e) {
    // malformed arguments
  }

  if (
    !args ||
    !args.constructor ||
    args.constructor !== Array ||
    args.length == 0
  ) {
    return null
  }

  return args
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/set-delegates.js":
/*!******************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/set-delegates.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ObjCClass = __webpack_require__(/*! mocha-js-delegate */ "./node_modules/mocha-js-delegate/index.js")
var parseWebArguments = __webpack_require__(/*! ./parseWebArguments */ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js")
var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

// We create one ObjC class for ourselves here
var WindowDelegateClass
var NavigationDelegateClass
var WebScriptHandlerClass

// TODO: events
// - 'page-favicon-updated'
// - 'new-window'
// - 'did-navigate-in-page'
// - 'will-prevent-unload'
// - 'crashed'
// - 'unresponsive'
// - 'responsive'
// - 'destroyed'
// - 'before-input-event'
// - 'certificate-error'
// - 'found-in-page'
// - 'media-started-playing'
// - 'media-paused'
// - 'did-change-theme-color'
// - 'update-target-url'
// - 'cursor-changed'
// - 'context-menu'
// - 'select-bluetooth-device'
// - 'paint'
// - 'console-message'

module.exports = function(browserWindow, panel, webview, options) {
  if (!WindowDelegateClass) {
    WindowDelegateClass = new ObjCClass({
      utils: null,
      panel: null,

      'windowDidResize:': function() {
        this.utils.emit('resize')
      },

      'windowDidMiniaturize:': function() {
        this.utils.emit('minimize')
      },

      'windowDidDeminiaturize:': function() {
        this.utils.emit('restore')
      },

      'windowDidEnterFullScreen:': function() {
        this.utils.emit('enter-full-screen')
      },

      'windowDidExitFullScreen:': function() {
        this.utils.emit('leave-full-screen')
      },

      'windowDidMove:': function() {
        this.utils.emit('move')
        this.utils.emit('moved')
      },

      'windowShouldClose:': function() {
        var shouldClose = 1
        this.utils.emit('close', {
          get defaultPrevented() {
            return !shouldClose
          },
          preventDefault: function() {
            shouldClose = 0
          },
        })
        return shouldClose
      },

      'windowWillClose:': function() {
        this.utils.emit('closed')
      },

      'windowDidBecomeKey:': function() {
        this.utils.emit('focus', this.panel.currentEvent())
      },

      'windowDidResignKey:': function() {
        this.utils.emit('blur')
      },
    })
  }

  if (!NavigationDelegateClass) {
    NavigationDelegateClass = new ObjCClass({
      state: {
        wasReady: 0,
      },
      utils: null,

      // // Called when the web view begins to receive web content.
      'webView:didCommitNavigation:': function(webView) {
        this.utils.emit('will-navigate', {}, String(String(webView.URL())))
      },

      // // Called when web content begins to load in a web view.
      'webView:didStartProvisionalNavigation:': function() {
        this.utils.emit('did-start-navigation')
        this.utils.emit('did-start-loading')
      },

      // Called when a web view receives a server redirect.
      'webView:didReceiveServerRedirectForProvisionalNavigation:': function() {
        this.utils.emit('did-get-redirect-request')
      },

      // // Called when the web view needs to respond to an authentication challenge.
      // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
      //   webView,
      //   challenge,
      //   completionHandler
      // ) {
      //   function callback(username, password) {
      //     completionHandler(
      //       0,
      //       NSURLCredential.credentialWithUser_password_persistence(
      //         username,
      //         password,
      //         1
      //       )
      //     )
      //   }
      //   var protectionSpace = challenge.protectionSpace()
      //   this.utils.emit(
      //     'login',
      //     {},
      //     {
      //       method: String(protectionSpace.authenticationMethod()),
      //       url: 'not implemented', // TODO:
      //       referrer: 'not implemented', // TODO:
      //     },
      //     {
      //       isProxy: !!protectionSpace.isProxy(),
      //       scheme: String(protectionSpace.protocol()),
      //       host: String(protectionSpace.host()),
      //       port: Number(protectionSpace.port()),
      //       realm: String(protectionSpace.realm()),
      //     },
      //     callback
      //   )
      // },

      // Called when an error occurs during navigation.
      // 'webView:didFailNavigation:withError:': function(
      //   webView,
      //   navigation,
      //   error
      // ) {},

      // Called when an error occurs while the web view is loading content.
      'webView:didFailProvisionalNavigation:withError:': function(
        webView,
        navigation,
        error
      ) {
        this.utils.emit('did-fail-load', error)
      },

      // Called when the navigation is complete.
      'webView:didFinishNavigation:': function() {
        if (this.state.wasReady == 0) {
          this.state.wasReady = 1
          this.utils.emitBrowserEvent('ready-to-show')
        }
        this.utils.emit('did-navigate')
        this.utils.emit('did-frame-navigate')
        this.utils.emit('did-stop-loading')
        this.utils.emit('did-finish-load')
        this.utils.emit('did-frame-finish-load')
      },

      // Called when the web view’s web content process is terminated.
      'webViewWebContentProcessDidTerminate:': function() {
        this.utils.emit('dom-ready')
      },

      // Decides whether to allow or cancel a navigation.
      // webView:decidePolicyForNavigationAction:decisionHandler:

      // Decides whether to allow or cancel a navigation after its response is known.
      // webView:decidePolicyForNavigationResponse:decisionHandler:
    })
  }

  if (!WebScriptHandlerClass) {
    WebScriptHandlerClass = new ObjCClass({
      utils: null,
      'userContentController:didReceiveScriptMessage:': function(_, message) {
        var args = this.utils.parseWebArguments(String(message.body()))
        if (!args) {
          return
        }
        if (!args[0] || typeof args[0] !== 'string') {
          return
        }
        args[0] = String(args[0])

        this.utils.emit.apply(this, args)
      },
    })
  }

  var navigationDelegate = NavigationDelegateClass.new({
    utils: {
      setTitle: browserWindow.setTitle.bind(browserWindow),
      emitBrowserEvent() {
        try {
          browserWindow.emit.apply(browserWindow, arguments)
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
    },
    state: {
      wasReady: 0,
    },
  })

  webview.setNavigationDelegate(navigationDelegate)

  var webScriptHandler = WebScriptHandlerClass.new({
    utils: {
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      parseWebArguments: parseWebArguments,
    },
  })

  webview
    .configuration()
    .userContentController()
    .addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE)

  var utils = {
    emit() {
      try {
        browserWindow.emit.apply(browserWindow, arguments)
      } catch (err) {
        if (
          typeof process !== 'undefined' &&
          process.listenerCount &&
          process.listenerCount('uncaughtException')
        ) {
          process.emit('uncaughtException', err, 'uncaughtException')
        } else {
          console.error(err)
          throw err
        }
      }
    },
  }
  if (options.modal) {
    // find the window of the document
    var msdocument
    if (options.parent.type === 'Document') {
      msdocument = options.parent.sketchObject
    } else {
      msdocument = options.parent
    }
    if (msdocument && String(msdocument.class()) === 'MSDocumentData') {
      // we only have an MSDocumentData instead of a MSDocument
      // let's try to get back to the MSDocument
      msdocument = msdocument.delegate()
    }
    utils.parentWindow = msdocument.windowForSheet()
  }

  var windowDelegate = WindowDelegateClass.new({
    utils: utils,
    panel: panel,
  })

  panel.setDelegate(windowDelegate)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/webview-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/webview-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var EventEmitter = __webpack_require__(/*! events */ "events")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")

// let's try to match https://github.com/electron/electron/blob/master/docs/api/web-contents.md
module.exports = function buildAPI(browserWindow, panel, webview) {
  var webContents = new EventEmitter()

  webContents.loadURL = browserWindow.loadURL

  webContents.loadFile = function(/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.downloadURL = function(/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.getURL = function() {
    return String(webview.url())
  }

  webContents.getTitle = function() {
    return String(webview.title())
  }

  webContents.isDestroyed = function() {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.focus = browserWindow.focus
  webContents.isFocused = browserWindow.isFocused

  webContents.isLoading = function() {
    return !!webview.loading()
  }

  webContents.isLoadingMainFrame = function() {
    // TODO:
    return !!webview.loading()
  }

  webContents.isWaitingForResponse = function() {
    return !webview.loading()
  }

  webContents.stop = function() {
    webview.stopLoading()
  }
  webContents.reload = function() {
    webview.reload()
  }
  webContents.reloadIgnoringCache = function() {
    webview.reloadFromOrigin()
  }
  webContents.canGoBack = function() {
    return !!webview.canGoBack()
  }
  webContents.canGoForward = function() {
    return !!webview.canGoForward()
  }
  webContents.canGoToOffset = function(offset) {
    return !!webview.backForwardList().itemAtIndex(offset)
  }
  webContents.clearHistory = function() {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.goBack = function() {
    webview.goBack()
  }
  webContents.goForward = function() {
    webview.goForward()
  }
  webContents.goToIndex = function(index) {
    var backForwardList = webview.backForwardList()
    var backList = backForwardList.backList()
    var backListLength = backList.count()
    if (backListLength > index) {
      webview.loadRequest(NSURLRequest.requestWithURL(backList[index]))
      return
    }
    var forwardList = backForwardList.forwardList()
    if (forwardList.count() > index - backListLength) {
      webview.loadRequest(
        NSURLRequest.requestWithURL(forwardList[index - backListLength])
      )
      return
    }
    throw new Error('Cannot go to index ' + index)
  }
  webContents.goToOffset = function(offset) {
    if (!webContents.canGoToOffset(offset)) {
      throw new Error('Cannot go to offset ' + offset)
    }
    webview.loadRequest(
      NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
    )
  }
  webContents.isCrashed = function() {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setUserAgent = function(/* userAgent */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.getUserAgent = function() {
    const userAgent = webview.customUserAgent()
    return userAgent ? String(userAgent) : undefined
  }
  webContents.insertCSS = function(css) {
    var source =
      "var style = document.createElement('style'); style.innerHTML = " +
      css.replace(/"/, '\\"') +
      '; document.head.appendChild(style);'
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview
      .configuration()
      .userContentController()
      .addUserScript(script)
  }
  webContents.insertJS = function(source) {
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview
      .configuration()
      .userContentController()
      .addUserScript(script)
  }
  webContents.executeJavaScript = executeJavaScript(webview, browserWindow)
  webContents.setIgnoreMenuShortcuts = function() {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setAudioMuted = function(/* muted */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.isAudioMuted = function() {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setZoomFactor = function(factor) {
    webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0))
  }
  webContents.getZoomFactor = function(callback) {
    callback(Number(webview.magnification()))
  }
  webContents.setZoomLevel = function(level) {
    // eslint-disable-next-line no-restricted-properties
    webContents.setZoomFactor(Math.pow(1.2, level))
  }
  webContents.getZoomLevel = function(callback) {
    // eslint-disable-next-line no-restricted-properties
    callback(Math.log(Number(webview.magnification())) / Math.log(1.2))
  }
  webContents.setVisualZoomLevelLimits = function(/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setLayoutZoomLevelLimits = function(/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  // TODO:
  // webContents.undo = function() {
  //   webview.undoManager().undo()
  // }
  // webContents.redo = function() {
  //   webview.undoManager().redo()
  // }
  // webContents.cut = webview.cut
  // webContents.copy = webview.copy
  // webContents.paste = webview.paste
  // webContents.pasteAndMatchStyle = webview.pasteAsRichText
  // webContents.delete = webview.delete
  // webContents.replace = webview.replaceSelectionWithText

  webContents.send = function() {
    const script =
      'window.postMessage({' +
      'isSketchMessage: true,' +
      "origin: '" +
      String(__command.identifier()) +
      "'," +
      'args: ' +
      JSON.stringify([].slice.call(arguments)) +
      '}, "*")'
    webview.evaluateJavaScript_completionHandler(script, null)
  }

  webContents.getNativeWebview = function() {
    return webview
  }

  browserWindow.webContents = webContents
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/remote.js":
/*!*******************************************************!*\
  !*** ./node_modules/sketch-module-web-view/remote.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals NSThread */
var threadDictionary = NSThread.mainThread().threadDictionary()

module.exports.getWebview = function(identifier) {
  return __webpack_require__(/*! ./lib */ "./node_modules/sketch-module-web-view/lib/index.js").fromId(identifier) // eslint-disable-line
}

module.exports.isWebviewPresent = function isWebviewPresent(identifier) {
  return !!threadDictionary[identifier]
}

module.exports.sendToWebview = function sendToWebview(identifier, evalString) {
  if (!module.exports.isWebviewPresent(identifier)) {
    return
  }

  var panel = threadDictionary[identifier]
  var webview = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webview &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webview = subviews[i]
    }
  }

  if (!webview || !webview.evaluateJavaScript_completionHandler) {
    throw new Error('Webview ' + identifier + ' not found')
  }

  webview.evaluateJavaScript_completionHandler(evalString, null)
}


/***/ }),

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var exception;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          exception
        );
        if (exception != null) {
          var error = new TypeError(
            String(
              typeof exception.localizedDescription === "function"
                ? exception.localizedDescription()
                : exception
            )
          );
          reject(error);
          return;
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
          break;
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, exception) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          finished = true;
          try {
            if (exception) {
              var error = new TypeError(
                String(
                  typeof exception.localizedDescription === "function"
                    ? exception.localizedDescription()
                    : exception
                )
              );
              reject(error);
              return;
            }
            resolve(response(res, data));
          } catch (err) {
            reject(err);
          }
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./src/common.js":
/*!***********************!*\
  !*** ./src/common.js ***!
  \***********************/
/*! exports provided: setTemplate, checkSubscribtion, collectStats, getCanvas, defaultConf, renewTemplate, colorIndex, calculateMargins, calculateMarginsHorizontal, calculateMarginsHistogram, calculateMarginsHeatmap, moveToPoint, lineToPoint, curveToPoint, path, createOval, polarToCartesian, xAxisGrid, xAxisDistrGrid, yAxisGrid, xAxisLabels, xAxisDistrLabels, yAxisLabels, createRandomData, processData, processJSON, createDots, createLineChart, createAreaChart, createStackedAreaChart, createHistogram, createVerticalBarChart, createHorizontalBarChart, createGroupBarChart, createGroupHorizontalBarChart, createPieChart, createDonutChart, createProgressChart, createSparkline, createScatterPlot, createCandlestickChart, createHeatmap, createChart, testChart */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setTemplate", function() { return setTemplate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkSubscribtion", function() { return checkSubscribtion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collectStats", function() { return collectStats; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCanvas", function() { return getCanvas; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultConf", function() { return defaultConf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renewTemplate", function() { return renewTemplate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorIndex", function() { return colorIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMargins", function() { return calculateMargins; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMarginsHorizontal", function() { return calculateMarginsHorizontal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMarginsHistogram", function() { return calculateMarginsHistogram; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMarginsHeatmap", function() { return calculateMarginsHeatmap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveToPoint", function() { return moveToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lineToPoint", function() { return lineToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "curveToPoint", function() { return curveToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "path", function() { return path; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createOval", function() { return createOval; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "polarToCartesian", function() { return polarToCartesian; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisGrid", function() { return xAxisGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisDistrGrid", function() { return xAxisDistrGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yAxisGrid", function() { return yAxisGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisLabels", function() { return xAxisLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisDistrLabels", function() { return xAxisDistrLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yAxisLabels", function() { return yAxisLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createRandomData", function() { return createRandomData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processData", function() { return processData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processJSON", function() { return processJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDots", function() { return createDots; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createLineChart", function() { return createLineChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createAreaChart", function() { return createAreaChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStackedAreaChart", function() { return createStackedAreaChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHistogram", function() { return createHistogram; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createVerticalBarChart", function() { return createVerticalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHorizontalBarChart", function() { return createHorizontalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createGroupBarChart", function() { return createGroupBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createGroupHorizontalBarChart", function() { return createGroupHorizontalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPieChart", function() { return createPieChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDonutChart", function() { return createDonutChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createProgressChart", function() { return createProgressChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSparkline", function() { return createSparkline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createScatterPlot", function() { return createScatterPlot; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createCandlestickChart", function() { return createCandlestickChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHeatmap", function() { return createHeatmap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createChart", function() { return createChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "testChart", function() { return testChart; });
/* harmony import */ var _nicenum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nicenum */ "./src/nicenum.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

 // GENERAL
// check cloud templates

function setTemplate(template, email) {
  var settings = {
    email: email,
    settings: {
      data: JSON.parse(template)
    }
  };
  fetch('https://chart.pavelkuligin.ru/settings/', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Origin': null
    },
    body: JSON.stringify(settings)
  });
} // return the status of subscription

function checkSubscribtion(email) {
  var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      API = "https://api.gumroad.com/v2/products/mPhu9ohiu6ddjaUOUuQ8IQ==/subscribers?access_token=190c56c544530cf3e170a90141c87cf060d920a96f7f0c221d0ee63a06fbdc5d",
      teamAPI = "https://api.gumroad.com/v2/products/Xr8PoVPBvwGyfs5A07MbqQ==/subscribers?access_token=190c56c544530cf3e170a90141c87cf060d920a96f7f0c221d0ee63a06fbdc5d";

  var count = 0,
      teamCount = 0;
  fetch(API).then(function (res) {
    return res.json();
  }).then(function (gumroad) {
    gumroad.subscribers.forEach(function (client) {
      if (client.email.toLowerCase() === email) {
        count += 1;
      }
    });

    if (count > 0) {
      Settings.setGlobalSettingForKey('user_status', true);
      Settings.setGlobalSettingForKey('user_type', 'PRO');
    } else {
      fetch(teamAPI).then(function (res) {
        return res.json();
      }).then(function (gumroad) {
        gumroad.subscribers.forEach(function (client) {
          if (client.email.toLowerCase() === email) {
            teamCount += 1;
          }
        });

        if (teamCount > 0) {
          Settings.setGlobalSettingForKey('user_status', true);
          Settings.setGlobalSettingForKey('user_type', 'TEAM');
        } else {
          Settings.setGlobalSettingForKey('user_status', false);
          Settings.setGlobalSettingForKey('user_type', 'FREE');
        }
      });
    }
  });
} // collect stats

function collectStats(userId, email, appVersion, option, meta) {
  var date = Math.floor(Date.now() / 1000),
      stats = {
    "userId": userId,
    "email": email,
    "date": date,
    "app": "Chart",
    "appVersion": appVersion,
    "option": option,
    "platform": "Sketch",
    "meta": meta
  };
  fetch('https://chart.pavelkuligin.ru/collect', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: stats
  }).then(function (res) {
    if (res.ok) {} else {}
  }).catch(function (error) {});
} // function that returns all parameters of canvases

function getCanvas(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      doc = sketch.getSelectedDocument();

  var selection = doc.selectedLayers,
      canvasArr = new Array(),
      error = false,
      canvas;

  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  if (selection.length > 0) {
    selection.forEach(function (layer) {
      if (layer.shapeType === "Rectangle" || layer.shapeType === "Oval") {
        layer.style.fills = [];
        layer.style.borders = [];
      }

      var setting = Settings.layerSettingForKey(layer, 'localConf');
      var yMin = null,
          yMax = null,
          xMin = null,
          xMax = null;
      var axesNums = layer.name.match(/\[(.*?)]/g);
      var axesRange = [];

      if (axesNums != null) {
        var axes = axesNums[0].replace(/\[(.*?)\]/g, "$1").split(";");
        axes.forEach(function (num) {
          var splitedAxe = num.split("-");

          if (splitedAxe.length > 1) {
            axesRange.push(splitedAxe);
          }
        });
      }

      if (axesRange.length > 0) {
        yMin = axesRange[0][0];
        yMax = axesRange[0][1];

        if (axesRange.length > 1) {
          xMin = axesRange[1][0];
          xMax = axesRange[1][1];
        }
      }

      canvas = {
        layer: layer.id,
        height: layer.frame.height,
        width: layer.frame.width,
        x: layer.frame.x,
        y: layer.frame.y,
        layerType: layer.shapeType,
        startNum: "false",
        yMin: yMin,
        yMax: yMax,
        xMin: xMin,
        xMax: xMax,
        parent: layer.parent.id,
        conf: setting
      };
      canvasArr.push(canvas);
    });
  }

  return [canvasArr, error];
} // default configuration

function defaultConf() {
  var template = [{
    "name": "Default template",
    "id": 0,
    "colors": {
      "common": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "progressChart": ["#e31a1c"],
      "sparkline": ["#343434"],
      "scatterPlot": ["#1f78b4"],
      "candlestickChart": ["#33a02c", "#e31a1c"],
      "heatmap": ["#a6cee3"]
    },
    "grid": {
      "type": 1,
      "lineWidth": 1,
      "color": "#F0F0F0"
    },
    "labels": {
      "type": 1,
      "fontName": "Roboto",
      "fontStyle": "Regular",
      "textCase": "ORIGINAL",
      "fontSize": 10,
      "lineHeight": 10,
      "letterSpacing": 0,
      "color": "#a3a3a3",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom"
    },
    "beginAtZero": 0,
    "lineType": 0,
    "sorting": 0,
    "typeOfCircle": 0,
    "lineChart": {
      "lineWidth": 2,
      "dotType": 1,
      "dotDiameter": 8
    },
    "areaChart": {
      "lineWidth": 0,
      "opacity": 0.8
    },
    "verticalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "horizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "groupedBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": 30
    },
    "progressChart": {
      "backgroundColor": "#f7f7f7",
      "thicknessOfProgress": 10,
      "endOfLine": 0
    },
    "sparkline": {
      "lineWidth": 1,
      "dotDiameter": 4
    },
    "scatterPlot": {
      "dotDiameter": 8
    },
    "candlestickChart": {
      "margin": 0.4,
      "unfilledNegativeBoxes": false
    },
    "histogram": {
      "margin": 2
    },
    "heatmap": {
      "margin": 0,
      "segments": 4
    }
  }];

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

  Settings.setGlobalSettingForKey('chartplugin.templates', JSON.stringify(template));
  return template;
} // apply new options in template

function renewTemplate(templates) {
  var newTemplate = {
    "name": "Default template",
    "id": 0,
    "colors": {
      "common": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "progressChart": ["#e31a1c"],
      "sparkline": ["#343434"],
      "scatterPlot": ["#1f78b4"],
      "candlestickChart": ["#33a02c", "#e31a1c"],
      "heatmap": ["#a6cee3"]
    },
    "grid": {
      "type": 1,
      "lineWidth": 1,
      "color": "#F0F0F0"
    },
    "labels": {
      "type": 1,
      "fontName": "Roboto",
      "fontStyle": "Regular",
      "textCase": "ORIGINAL",
      "fontSize": 10,
      "lineHeight": 10,
      "letterSpacing": 0,
      "color": "#a3a3a3",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom"
    },
    "beginAtZero": 0,
    "lineType": 0,
    "sorting": 0,
    "typeOfCircle": 0,
    "lineChart": {
      "lineWidth": 2,
      "dotType": 1,
      "dotDiameter": 8
    },
    "areaChart": {
      "lineWidth": 0,
      "opacity": 0.8
    },
    "verticalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "horizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "groupedBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": 30
    },
    "progressChart": {
      "backgroundColor": "#f7f7f7",
      "thicknessOfProgress": 10,
      "endOfLine": 0
    },
    "sparkline": {
      "lineWidth": 1,
      "dotDiameter": 4
    },
    "scatterPlot": {
      "dotDiameter": 8
    },
    "candlestickChart": {
      "margin": 0.4,
      "unfilledNegativeBoxes": false
    },
    "histogram": {
      "margin": 2
    },
    "heatmap": {
      "margin": 0,
      "segments": 4
    }
  };

  if (templates.length === 0) {
    templates = [newTemplate];
  }

  templates.forEach(function (oldTemplate) {
    var newKeys = Object.keys(newTemplate);
    newKeys.forEach(function (key, i) {
      if (oldTemplate[key] === undefined) {
        oldTemplate[key] = newTemplate[key];
      }

      if (_typeof(newTemplate[key]) === 'object') {
        Object.keys(newTemplate[key]).forEach(function (secondKey) {
          if (oldTemplate[key] != undefined) {
            if (oldTemplate[key][secondKey] === undefined) {
              oldTemplate[key][secondKey] = newTemplate[key][secondKey];

              if (secondKey === 'lineHeight') {
                oldTemplate[key][secondKey] = oldTemplate.labels.fontSize;
              }
            }
          }
        });
      }
    });
  });

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

  Settings.setGlobalSettingForKey('chartplugin.templates', JSON.stringify(templates));
  return templates;
} // colorPalette index

function colorIndex(i, colorPalette) {
  var colorLength = colorPalette.length;

  if (i + 1 > colorLength) {
    var rest = (i + 1) % colorLength;

    if (rest == 0) {
      return colorLength - 1;
    } else {
      return rest - 1;
    }
  } else {
    return i;
  }
} // margins

function calculateMargins(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      realLabelsIndex = [],
      realLabelsX = [],
      minMaxArray = [data.niceMin, data.niceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // Y labels

  for (var i = 0; i < minMaxArray.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArray[i].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    yLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minW = 10 + Math.max.apply(Math, yLabelsWidth); // X labels

  for (var _i = 0; _i < data.header.length; _i++) {
    var _text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.header[_i].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    xLabelsWidth.push(_text.frame.width);

    _text.remove();
  }

  var minX = Math.max.apply(Math, xLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  }

  if (conf.labels.type === 1) {
    minW > xLabelsWidth[0] / 2 ? margins.left = minW : margins.left = Math.ceil(xLabelsWidth[0] / 2);
    margins.top = conf.labels.fontSize / 2;
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);

    if (chartType == "verticalBarChart" || chartType == "groupedBarChart") {
      margins.right = 0;
    }
  } else if (conf.labels.type === 2) {
    margins.left = minW;
    margins.top = conf.labels.fontSize / 2;
    margins.bottom = conf.labels.fontSize / 2;
  } else if (conf.labels.type === 3) {
    margins.left = Math.ceil(xLabelsWidth[0] / 2);
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);

    if (chartType == "verticalBarChart" || chartType == "groupedBarChart") {
      margins.left = 0;
      margins.right = 0;
    }
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;

  if (chartType === "candlestickChart") {
    initialStep = Math.floor(canvas.width / data.columns);
    counter = Math.ceil(minX / initialStep);
    numLabels = Math.ceil(data.columns / counter) - 1;
    step = initialStep * counter;
  } // workaround for first and last label case


  if (data.header != false) {
    data.header.forEach(function (header) {
      if (header === "") {
        counter = 1;
        numLabels = data.header.length - 1;
        step = canvas.width / (data.columns - 1);

        if (chartType === "candlestickChart") {
          step = initialStep;
        }
      }
    });
  } // positions of all labels


  for (var _i2 = 0; _i2 < numLabels + 1; _i2++) {
    var positionX = canvas.x + step * _i2;
    realLabelsIndex.push(_i2 * counter);
    realLabelsX.push(Math.floor(positionX) + xLabelsWidth[_i2 * counter]);
  }

  var actualWidth = canvas.width + canvas.x,
      lastLabelX = realLabelsX[realLabelsX.length - 1] - xLabelsWidth[realLabelsIndex[realLabelsIndex.length - 1]] / 2;

  if (actualWidth > lastLabelX) {
    canvas.width += margins.right;

    if (chartType === "candlestickChart") {
      initialStep = Math.floor(canvas.width / data.columns);
    } else {
      initialStep = canvas.width / (data.columns - 1);
    }

    step = initialStep * counter;
  }

  if (canvas.width % 2) {
    canvas.width = canvas.width - 1;
  }

  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter,
    initialStep: initialStep
  };
}
function calculateMarginsHorizontal(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      minMaxArray = [data.niceMin, data.niceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // X labels

  for (var i = 0; i < minMaxArray.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArray[i].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    yLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minX = Math.max.apply(Math, yLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  } // Y labels


  for (var _i3 = 0; _i3 < data.header.length; _i3++) {
    var _text2 = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.header[_i3].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    xLabelsWidth.push(_text2.frame.width);

    _text2.remove();
  }

  var minW = 10 + Math.max.apply(Math, xLabelsWidth);

  if (conf.labels.type === 1) {
    margins.left = minW;
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(yLabelsWidth[yLabelsWidth.length - 1] / 2);
  } else if (conf.labels.type === 2) {
    margins.left = Math.ceil(yLabelsWidth[0] / 2);
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(yLabelsWidth[yLabelsWidth.length - 1] / 2);
  } else if (conf.labels.type === 3) {
    margins.left = minW;
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;
  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter
  };
}
function calculateMarginsHistogram(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      realLabelsIndex = [],
      realLabelsX = [],
      minMaxArrayX = [data.xNiceMin, data.xNiceMax],
      minMaxArrayY = [data.yNiceMin, data.yNiceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // X labels

  for (var i = 0; i < minMaxArrayX.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArrayX[i].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    xLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minX = Math.max.apply(Math, xLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  } // Y labels


  for (var _i4 = 0; _i4 < minMaxArrayY.length; _i4++) {
    var _text3 = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArrayY[_i4].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    yLabelsWidth.push(_text3.frame.width);

    _text3.remove();
  }

  var minW = 10 + Math.max.apply(Math, yLabelsWidth);

  if (conf.labels.type === 1) {
    margins.top = conf.labels.fontSize / 2;
    margins.left = minW;
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);
  } else if (conf.labels.type === 2) {
    margins.left = minW;
    margins.top = conf.labels.fontSize / 2;
    margins.bottom = conf.labels.fontSize / 2;
  } else if (conf.labels.type === 3) {
    margins.left = Math.ceil(xLabelsWidth[0] / 2);
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;
  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter
  };
}
function calculateMarginsHeatmap(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      minMaxArray = [data.niceMin, data.niceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // X labels

  for (var i = 0; i < data.horizontalHeaders.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.horizontalHeaders[i].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    xLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minX = Math.max.apply(Math, xLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  } // Y labels


  for (var _i5 = 0; _i5 < data.header.length; _i5++) {
    var _text4 = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.header[_i5].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    yLabelsWidth.push(_text4.frame.width);

    _text4.remove();
  }

  var minW = 10 + Math.max.apply(Math, yLabelsWidth);

  if (conf.labels.type === 1) {
    margins.left = minW;
    margins.bottom = 10 + conf.labels.fontSize;
  } else if (conf.labels.type === 2) {
    margins.bottom = 10 + conf.labels.fontSize;
  } else if (conf.labels.type === 3) {
    margins.left = minW;
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;
  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter
  };
} // Helper SVG functions

function moveToPoint(x, y) {
  return "M " + Math.floor(x) + " " + Math.floor(y);
}
function lineToPoint(x, y) {
  return " L " + Math.floor(x) + " " + Math.floor(y);
}
function curveToPoint(points) {
  return " C " + Math.floor(points.c1x) + " " + Math.floor(points.c1y) + " " + Math.floor(points.c2x) + " " + Math.floor(points.c2y) + " " + Math.floor(points.x) + " " + Math.floor(points.y);
}
function path(canvas, data, conf, i, dir) {
  var x0 = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1),
      y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - data.niceMin);

  if (dir === "back") {
    x0 = canvas.x + canvas.width;
    y0 = zero - canvas.height / yAxe * (Number(data.table[i][data.columns - 1]) - data.niceMin);
  }

  var xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0),
      m = 0,
      dx1 = 0,
      dy1 = 0,
      dx2 = 0,
      dy2 = 0,
      preP = {
    x: x0,
    y: y0
  },
      nexP = {},
      f,
      t;

  function gradient(a, b) {
    return (b.y - a.y) / (b.x - a.x);
  }

  if (dir === "forward") {
    for (var j = 1; j < data.columns; j++) {
      if (conf.lineType === 0) {
        f = 0.5;
        t = 0;
      } else if (conf.lineType === 1) {
        f = 0;
        t = 0;
      } else {
        f = 0.3;
        t = 0.5;
      }

      xNext = xLast + xStep;
      y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
      var curP = {
        x: xNext,
        y: y
      };

      if (j == data.columns - 1) {
        dx2 = 0;
        dy2 = 0;
      } else {
        nexP = {
          x: xNext + xStep,
          y: zero - canvas.height / yAxe * (Number(data.table[i][j + 1]) - data.niceMin)
        };
        m = gradient(preP, nexP);
        dx2 = (nexP.x - curP.x) * -f;
        dy2 = dx2 * m * t;
      }

      var points = {
        x: curP.x,
        y: curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: curP.x + dx2,
        c2y: curP.y + dy2
      };
      pathData += curveToPoint(points);
      dx1 = dx2;
      dy1 = dy2;
      preP = curP;
      xLast = xNext;
      yLast = y;
    }
  } else {
    pathData = "";

    for (var _j = data.columns - 2; _j >= 0; _j--) {
      if (conf.lineType === 0) {
        f = 0.5;
        t = 0;
      } else if (conf.lineType === 1) {
        f = 0;
        t = 0;
      } else {
        f = 0.3;
        t = 0.5;
      }

      xNext = xLast - xStep;
      y = zero - canvas.height / yAxe * (Number(data.table[i][_j]) - data.niceMin);
      var _curP = {
        x: xNext,
        y: y
      };

      if (_j == 0) {
        dx2 = 0;
        dy2 = 0;
      } else {
        nexP = {
          x: xNext - xStep,
          y: zero - canvas.height / yAxe * (Number(data.table[i][_j - 1]) - data.niceMin)
        };
        m = gradient(preP, nexP);
        dx2 = (nexP.x - _curP.x) * -f;
        dy2 = dx2 * m * t;
      }

      var _points = {
        x: _curP.x,
        y: _curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: _curP.x + dx2,
        c2y: _curP.y + dy2
      };
      pathData += curveToPoint(_points);
      dx1 = dx2;
      dy1 = dy2;
      preP = _curP;
      xLast = xNext;
      yLast = y;
    }
  }

  return pathData;
}
function createOval(cx, cy, r) {
  var oval = "M " + cx + " " + cy + " m -" + r + ", 0 a " + r + "," + r + " 0 1,0 " + r * 2 + ",0 a " + r + "," + r + " 0 1,0 -" + r * 2 + ",0";
  return oval;
}
function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
  var angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return {
    x: centerX + radius * Math.cos(angleInRadians),
    y: centerY + radius * Math.sin(angleInRadians)
  };
} // GRIDS

function xAxisGrid(conf, canvas, data, group, chartType, marginsData) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var numLines = marginsData.numLabels,
      step = marginsData.step,
      counter = marginsData.counter,
      lineCounter;

  if (chartType === "candlestickChart") {
    var _path = moveToPoint(canvas.x, canvas.y) + lineToPoint(canvas.x, canvas.y + canvas.height),
        gridLine = ShapePath.fromSVGPath(_path);

    gridLine.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    gridLine.name = "Grid_v_0";
    group.push(gridLine);
  }

  for (var i = 0; i < numLines + 1; i++) {
    var positionX = canvas.x + step * i;

    if (chartType === "candlestickChart") {
      positionX = canvas.x + marginsData.initialStep / 2 + step * i;
    }

    var _path2 = moveToPoint(positionX, canvas.y) + lineToPoint(positionX, canvas.y + canvas.height),
        _gridLine = ShapePath.fromSVGPath(_path2);

    _gridLine.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    _gridLine.name = "Grid_v_" + (i + 1);
    group.push(_gridLine);
    lineCounter = i;
  }

  if (canvas.width > step * numLines) {
    var _path3 = moveToPoint(canvas.x + canvas.width, canvas.y) + lineToPoint(canvas.x + canvas.width, canvas.y + canvas.height),
        _gridLine2 = ShapePath.fromSVGPath(_path3);

    _gridLine2.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    _gridLine2.name = "Grid_v_" + (lineCounter + 1);
    group.push(_gridLine2);
  }
}
function xAxisDistrGrid(conf, canvas, data, group, dir) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (dir === "horizontal") {
    var xStep = canvas.width / data.columns,
        x0x = canvas.x,
        y0x = canvas.y,
        y1x = canvas.y + canvas.height;

    for (var i = 0; i < data.columns + 1; i++) {
      var _path4 = moveToPoint(x0x, y0x) + lineToPoint(x0x, y1x),
          gridLine = ShapePath.fromSVGPath(_path4);

      gridLine.style = {
        borders: [{
          color: conf.grid.color,
          thickness: conf.grid.lineWidth
        }]
      };
      gridLine.name = "Grid_v_" + (i + 1);
      group.push(gridLine);
      x0x = x0x + xStep;
    }
  } else {
    var yStep = canvas.height / data.columns,
        _y0x = canvas.y,
        _x0x = canvas.x,
        x1x = canvas.x + canvas.width;

    for (var _i6 = 0; _i6 < data.columns + 1; _i6++) {
      var _path5 = moveToPoint(_x0x, _y0x) + lineToPoint(x1x, _y0x),
          _gridLine3 = ShapePath.fromSVGPath(_path5);

      _gridLine3.style = {
        borders: [{
          color: conf.grid.color,
          thickness: conf.grid.lineWidth
        }]
      };
      _gridLine3.name = "Grid_v_" + (_i6 + 1);
      group.push(_gridLine3);
      _y0x = _y0x + yStep;
    }
  }
}
function yAxisGrid(conf, canvas, data, group, dir, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var minStepPx = 30,
      range = data.niceMax - data.niceMin,
      maxNumTicks = Math.floor(canvas.height / minStepPx),
      dividers = [0.1, 0.2, 0.5],
      axisNum = data.niceMin;

  if (chartType === "scatterPlot" && dir === "vertical" || chartType === "histogram" && dir === "vertical") {
    range = data.yNiceMax - data.yNiceMin;
    axisNum = data.yNiceMin;
  } else if (chartType === "scatterPlot" && dir === "horizontal" || chartType === "histogram" && dir === "horizontal") {
    range = data.xNiceMax - data.xNiceMin;
    axisNum = data.xNiceMin;
  }

  if (dir === "horizontal") {
    minStepPx = 40;
    maxNumTicks = Math.floor(canvas.width / minStepPx);
  }

  var step = dividers[0],
      numLines = Math.ceil(range / step),
      i = 0,
      count = 1;

  while (numLines >= maxNumTicks) {
    step = dividers[i] * count;
    numLines = Math.ceil(range / step);

    if (i === 2) {
      i = 0;
      count = count * 10;
    } else {
      i++;
    }
  }

  var textStep = step;
  step = canvas.height / numLines;

  if (dir === "horizontal") {
    step = canvas.width / numLines;
  }

  for (var _i7 = 0; _i7 < numLines + 1; _i7++) {
    var positionY = canvas.y + canvas.height - step * _i7,
        _path6 = moveToPoint(canvas.x, positionY) + lineToPoint(canvas.x + canvas.width, positionY);

    if (dir === "horizontal") {
      positionY = canvas.x + step * _i7;
      _path6 = moveToPoint(positionY, canvas.y) + lineToPoint(positionY, canvas.y + canvas.height);
    }

    var gridLine = ShapePath.fromSVGPath(_path6);
    gridLine.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    gridLine.name = "Grid_" + (_i7 + 1);
    group.push(gridLine);
  }
} // LABELS

function xAxisLabels(canvas, data, group, conf, marginsData, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var numLabels = marginsData.numLabels,
      step = marginsData.step,
      counter = marginsData.counter;

  for (var i = 0; i < numLabels + 1; i++) {
    var positionX = canvas.x + step * i;

    if (chartType === "candlestickChart") {
      positionX = canvas.x + marginsData.initialStep / 2 + step * i;
    }

    if (data.header != false && data.header[i] != "") {
      var text = new Text({
        frame: new Rectangle(Math.floor(positionX), Math.floor(canvas.y + canvas.height + 10), 50, conf.labels.lineHeight),
        text: data.header[i * counter].toString(),
        style: {
          alignment: Text.Alignment.center,
          fontSize: conf.labels.fontSize,
          fontFamily: conf.labels.fontName,
          fontWeight: conf.labels.fontStyle,
          kerning: conf.labels.letterSpacing,
          paragraphSpacing: 0,
          textTransform: conf.labels.textCase,
          lineHeight: conf.labels.lineHeight,
          textColor: conf.labels.color + 'ff',
          fills: [],
          borders: [{
            enabled: false
          }]
        }
      });
      group.push(text);
      text.frame.x = text.frame.x - text.frame.width / 2;
    }
  }
}
function xAxisDistrLabels(canvas, data, group, conf, dir, chartType, minW) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (dir === "horizontal") {
    var xStep = canvas.width / data.columns,
        x0x = canvas.x,
        numberColumns = data.columns;

    if (chartType === "heatmap") {
      var margin = conf.heatmap.margin;
      data.header = data.horizontalHeaders;
      numberColumns = data.rows;
      xStep = (canvas.width - margin * (numberColumns - 1)) / numberColumns;
      x0x = canvas.x;
    }

    for (var i = 0; i < numberColumns; i++) {
      if (data.header != false) {
        var text = new Text({
          fixedWidth: true,
          frame: new Rectangle(Math.floor(x0x), Math.floor(canvas.y + canvas.height + 10), xStep, conf.labels.lineHeight),
          text: data.header[i],
          style: {
            alignment: Text.Alignment.center,
            fontSize: conf.labels.fontSize,
            fontFamily: conf.labels.fontName,
            fontWeight: conf.labels.fontStyle,
            kerning: conf.labels.letterSpacing,
            paragraphSpacing: 0,
            textTransform: conf.labels.textCase,
            lineHeight: conf.labels.lineHeight,
            textColor: conf.labels.color + 'ff',
            fills: [],
            borders: [{
              enabled: false
            }]
          }
        });
        group.push(text);
      }

      x0x = x0x + xStep;

      if (chartType === "heatmap") {
        x0x += conf.heatmap.margin;
      }
    }
  } else {
    var yStep = canvas.height / data.columns,
        y0x = canvas.y + (yStep - 10) / 2;

    for (var _i8 = 0; _i8 < data.columns; _i8++) {
      if (data.header != false) {
        var _text5 = new Text({
          frame: new Rectangle(Math.floor(canvas.x - minW), Math.floor(y0x), 30, conf.labels.lineHeight),
          text: data.header[_i8],
          style: {
            alignment: Text.Alignment.right,
            fontSize: conf.labels.fontSize,
            fontFamily: conf.labels.fontName,
            fontWeight: conf.labels.fontStyle,
            kerning: conf.labels.letterSpacing,
            paragraphSpacing: 0,
            textTransform: conf.labels.textCase,
            lineHeight: conf.labels.lineHeight,
            textColor: conf.labels.color + 'ff',
            fills: [],
            borders: [{
              enabled: false
            }]
          }
        });

        group.push(_text5);
      }

      y0x = y0x + yStep;
    }
  }
}
function yAxisLabels(canvas, data, group, conf, dir, chartType, minW) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var minStepPx = 30,
      range = data.niceMax - data.niceMin,
      maxNumTicks = Math.floor(canvas.height / minStepPx),
      dividers = [0.1, 0.2, 0.5],
      axisNum = data.niceMin;

  if (chartType === "scatterPlot" && dir === "vertical" || chartType === "histogram" && dir === "vertical") {
    range = data.yNiceMax - data.yNiceMin;
    axisNum = data.yNiceMin;
  } else if (chartType === "scatterPlot" && dir === "horizontal" || chartType === "histogram" && dir === "horizontal") {
    range = data.xNiceMax - data.xNiceMin;
    axisNum = data.xNiceMin;
  }

  if (dir === "horizontal") {
    minStepPx = 40;
    maxNumTicks = Math.floor(canvas.width / minStepPx);
  }

  var step = dividers[0],
      numLines = Math.ceil(range / step),
      i = 0,
      count = 1;

  while (numLines >= maxNumTicks) {
    step = dividers[i] * count;
    numLines = Math.ceil(range / step);

    if (i === 2) {
      i = 0;
      count = count * 10;
    } else {
      i++;
    }
  }

  var textStep = step;
  step = canvas.height / numLines;

  if (dir === "horizontal") {
    step = canvas.width / numLines;
  }

  for (var _i9 = 0; _i9 < numLines + 1; _i9++) {
    var textFrame = new Rectangle(Math.floor(canvas.x - minW), Math.floor(canvas.y + canvas.height - step * _i9 - conf.labels.lineHeight / 2), 50, conf.labels.lineHeight),
        textAlignment = Text.Alignment.right;

    if (dir === "horizontal") {
      textFrame = new Rectangle(Math.floor(canvas.x + step * _i9), Math.floor(canvas.y + canvas.height + conf.labels.lineHeight), 40, conf.labels.lineHeight);
      textAlignment = Text.Alignment.center;
    }

    var textValue = void 0;

    if (data.symbol === "%") {
      textValue = (Math.round(axisNum * 100) / 100).toString() + data.symbol;
    } else {
      textValue = data.symbol + (Math.round(axisNum * 100) / 100).toString();
    }

    var text = new Text({
      frame: textFrame,
      text: textValue,
      style: {
        alignment: textAlignment,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    group.push(text);

    if (dir == "vertical") {
      text.frame.width = minW - 10;
    }

    if (dir == "horizontal") {
      text.frame.x = text.frame.x - text.frame.width / 2;
    }

    axisNum = Math.round(axisNum * 100) / 100 + textStep;
  }
} // PROCESS DATA
// Create random data set

function createRandomData(rows, columns, min, max, distr, type) {
  var dataRow = new Array(),
      dataTable = new Array(),
      dataMax = new Array(),
      dataMin = new Array(),
      headers = [];

  function randNum(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var data = new Array();

    for (var i = 0; i < col; i++) {
      data[i] = Number(Math.random() * (max - min) + min).toFixed(0);
    }

    return data;
  }

  function trendUp(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
        data = new Array();

    for (var i = 0; i < col; i++) {
      var tempNum = min + step * (Math.random() * (1.3 - 0.5) + 0.5);
      min += tempNum - min;
      data[i] = tempNum.toFixed(0);
    }

    return data;
  }

  function trendDown(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
        data = new Array();

    for (var i = 0; i < col; i++) {
      var tempNum = max - step * (Math.random() * (1.3 - 0.5) + 0.5);
      max -= max - tempNum;
      data[i] = tempNum.toFixed(0);
    }

    return data;
  }

  function normalDistr(min, max, col) {
    max = Number(max);
    min = Number(min);
    col = Number(col - 1);
    var data = new Array(),
        originalMax = max;

    for (var i = 0; i <= col; i++) {
      max = max * Math.random();
      var c = min,
          b = 4 * (max - min) / col,
          a = -b / col;
      var tempNum = a * Math.pow(i, 2) + b * i + c;
      data[i] = tempNum.toFixed(0);
      max = originalMax;
    }

    return data;
  }

  var funcArr = [randNum, trendUp, trendDown, normalDistr];

  if (type == "candlestickChart") {
    var newRandom = function newRandom(min, max) {
      return Math.random() * (max - min) + min;
    };

    var range = max - min,
        minTrend = min + newRandom(range * 0.1, range * 0.3),
        maxTrend = max - newRandom(range * 0.1, range * 0.3),
        trendStep = (maxTrend - minTrend) / columns,
        startUp = minTrend,
        startDown = maxTrend,
        centerPoint,
        high,
        close,
        open,
        low,
        delta,
        highArr = new Array(),
        closeArr = new Array(),
        openArr = new Array(),
        lowArr = new Array();

    for (var j = 0; j < columns; j++) {
      if (distr == "1") {
        // Up
        centerPoint = Number(startUp) + trendStep * newRandom(0.7, 1.3);
        startUp = centerPoint;
      } else if (distr == "2") {
        // Down
        centerPoint = Number(startDown) - trendStep * newRandom(0.7, 1.3);
        startDown = centerPoint;
      } else {
        // Noise
        centerPoint = newRandom(range * 0.1, range * 0.9);
      }

      high = centerPoint * newRandom(1.1, 1.3);
      low = centerPoint * newRandom(0.7, 0.9);
      delta = high - low;
      close = newRandom(Number(low) + 0.2 * delta, Number(high) - 0.2 * delta);

      if (close < high - (high - low) / 2) {
        var openDelta = high - close;
        open = newRandom(Number(close) + 0.2 * openDelta, Number(high) - 0.2 * openDelta);
      } else {
        var openDelta = close - low;
        open = newRandom(Number(low) + 0.2 * openDelta, Number(close) - 0.2 * openDelta);
      }

      highArr[j] = high.toFixed(0);
      closeArr[j] = close.toFixed(0);
      openArr[j] = open.toFixed(0);
      lowArr[j] = low.toFixed(0);
    }

    dataTable[0] = highArr;
    dataTable[1] = closeArr;
    dataTable[2] = openArr;
    dataTable[3] = lowArr;
  } else {
    for (var i = 0; i < rows; i++) {
      if (distr == "0") {
        dataRow = randNum(min, max, columns);
      } else if (distr == "1") {
        dataRow = trendUp(min, max, columns);
      } else if (distr == "2") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = trendDown(min, max, columns);
        }
      } else if (distr == "3") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = normalDistr(min, max, columns);
        }
      } else {
        var _randNum = Number(Math.random() * (funcArr.length - 1)).toFixed(0);

        dataRow = funcArr[_randNum](min, max, columns);
      }

      dataTable[i] = dataRow;
      dataMax[i] = Math.max.apply(Math, _toConsumableArray(dataRow));
      dataMin[i] = Math.min.apply(Math, _toConsumableArray(dataRow));
    }
  }

  for (var h = 0; h < columns; h++) {
    headers[h] = "Text";
  }

  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers,
    symbol: ""
  };
  return dataObj;
} // Create data set from real data

function processData(csv) {
  function transpose(a) {
    return Object.keys(a[0]).map(function (c) {
      return a.map(function (r) {
        return r[c];
      });
    });
  }

  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  function tableMin(N) {
    var min = new Array();

    for (var i in N) {
      min[i] = Math.min.apply(Math, _toConsumableArray(N[i]));
    }

    return Math.min.apply(Math, min);
  }

  function tableMax(N) {
    var max = new Array();

    for (var i in N) {
      max[i] = Math.max.apply(Math, _toConsumableArray(N[i]));
    }

    return Math.max.apply(Math, max);
  }

  function parseNumber(num) {
    var numText = num.toString(),
        commaIndex = numText.lastIndexOf(','),
        dotIndex = numText.lastIndexOf('.'),
        cleanNumber;
    symbol = numText.match(/[%$£€]/);

    if (symbol === null) {
      symbol = "";
    } else {
      symbol = symbol[0];
    }

    if (commaIndex >= 0 && commaIndex > dotIndex) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    } else if (dotIndex >= 0 && dotIndex > commaIndex) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (commaIndex < 0) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (dotIndex < 0) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    }

    return cleanNumber;
  }

  var dataObj, symbol;

  if (csv.type === null) {
    var col = csv.data[0].length,
        row = csv.data.length,
        newData = csv.data,
        header;

    if (csv.headers == true) {
      header = newData[0];
      newData.splice(0, 1);

      for (var i = 0; i < row - 1; i++) {
        for (var j = 0; j < col; j++) {
          newData[i][j] = parseFloat(parseNumber(newData[i][j]));
        }
      }

      row = row - 1;
    } else {
      header = false;

      for (var _i10 = 0; _i10 < row; _i10++) {
        for (var _j2 = 0; _j2 < col; _j2++) {
          newData[_i10][_j2] = parseFloat(parseNumber(newData[_i10][_j2]));
        }
      }
    }

    dataObj = {
      table: newData,
      rows: row,
      columns: col,
      min: tableMin(newData),
      max: tableMax(newData),
      header: header,
      symbol: symbol
    };
  } else {
    var _newData = new Array(),
        selectedRows = new Array(),
        headerIndex,
        transposedTable = transpose(csv.data);

    csv.columns.forEach(function (column) {
      if (column.checked) {
        selectedRows.push(column.index);
      }
    });
    selectedRows.forEach(function (row) {
      _newData.push(transposedTable[row]);
    });

    for (var _i11 = 0; _i11 < _newData.length; _i11++) {
      for (var _j3 = 0; _j3 < _newData[0].length; _j3++) {
        _newData[_i11][_j3] = parseFloat(parseNumber(_newData[_i11][_j3]));
      }
    }

    csv.header.forEach(function (header) {
      if (header.checked) {
        headerIndex = header.index;
      }
    });
    dataObj = {
      table: _newData,
      rows: _newData.length,
      columns: _newData[0].length,
      min: tableMin(_newData),
      max: tableMax(_newData),
      header: transposedTable[headerIndex],
      symbol: symbol
    };
  }

  return dataObj;
} // Create data set from JSON

function processJSON(JSON, rawKeys, rawHeader) {
  var keys = new Array(),
      headerKey = "",
      dataTable = new Array(),
      dataMax = new Array(),
      dataMin = new Array();

  function getValues(obj, key) {
    var objects = [];

    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;

      if (_typeof(obj[i]) == 'object') {
        objects = objects.concat(getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }

    return objects;
  }

  function parseNumber(num) {
    var numText = num.toString(),
        commaIndex = numText.lastIndexOf(','),
        dotIndex = numText.lastIndexOf('.'),
        cleanNumber;
    symbol = numText.match(/[%$£€]/);

    if (symbol === null) {
      symbol = "";
    } else {
      symbol = symbol[0];
    }

    if (commaIndex >= 0 && commaIndex > dotIndex) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    } else if (dotIndex >= 0 && dotIndex > commaIndex) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (commaIndex < 0) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (dotIndex < 0) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    }

    return cleanNumber;
  }

  rawKeys.forEach(function (key) {
    if (key.checked == true) {
      keys.push(key.name);
    }
  });
  rawHeader.forEach(function (header) {
    if (header.checked == true) {
      headerKey = header.name;
    }
  });
  var headers = getValues(JSON, headerKey),
      symbol;

  for (var i in keys) {
    var row = getValues(JSON, keys[i]);

    for (var j in row) {
      row[j] = parseFloat(parseNumber(row[j]));
    }

    dataTable[i] = row;
    dataMax[i] = Math.max.apply(Math, _toConsumableArray(dataTable[i]));
    dataMin[i] = Math.min.apply(Math, _toConsumableArray(dataTable[i]));
  }

  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers,
    symbol: symbol
  };
  return dataObj;
} // CHARTS
// Line chart

function createDots(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style,
      Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

  var x = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1),
      radius = conf.lineChart.dotDiameter;

  for (var j = 0; j < data.columns; j++) {
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var dot = new ShapePath({
      name: "Dot_" + (i + 1) + (j + 1),
      shapeType: ShapePath.ShapeType.Oval,
      frame: new Rectangle(Math.floor(x) - radius / 2, Math.floor(y) - radius / 2, radius, radius)
    });

    if (conf.lineChart.dotType == 1) {
      dot.style = {
        fills: [conf.colors.common[colorIndex(i, conf.colors.common)]],
        borders: [{
          enabled: false
        }]
      };
    } else {
      dot.style = {
        fills: ["#fff"],
        borders: [{
          color: conf.colors.common[colorIndex(i, conf.colors.common)],
          thickness: conf.lineChart.lineWidth,
          position: Style.BorderPosition.Inside
        }]
      };
    }

    group.push(dot);
    x = x + xStep;
  }
}
function createLineChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var pathData = path(canvas, data, conf, i, "forward");
  var line = ShapePath.fromSVGPath(pathData);
  line.style = {
    borders: [{
      color: conf.colors.common[colorIndex(i, conf.colors.common)],
      thickness: conf.lineChart.lineWidth
    }]
  };
  line.name = "Line_" + (i + 1);
  group.push(line); // Dots

  if (conf.lineChart.dotType != 0) {
    createDots(canvas, conf, data, i, group);
  }
} // Area chart

function createAreaChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var pathData = path(canvas, data, conf, i, "forward"),
      zero;

  if (data.niceMin < 0) {
    zero = canvas.y + canvas.height * data.niceMax / (data.niceMax - data.niceMin);
  } else {
    zero = canvas.y + canvas.height;
  }

  pathData += lineToPoint(canvas.x + canvas.width, zero);
  pathData += lineToPoint(canvas.x, zero);
  pathData += " Z";
  var area = ShapePath.fromSVGPath(pathData);
  area.style = {
    fills: [conf.colors.common[colorIndex(i, conf.colors.common)]],
    borders: [{
      enabled: false
    }],
    opacity: conf.areaChart.opacity
  };
  area.name = "Area_" + (i + 1);
  group.push(area);

  if (conf.areaChart.lineWidth > 0) {
    var topLine = path(canvas, data, conf, i, "forward");
    var line = ShapePath.fromSVGPath(topLine);
    line.style = {
      borders: [{
        color: conf.colors.common[colorIndex(i, conf.colors.common)],
        thickness: conf.areaChart.lineWidth
      }]
    };
    line.name = "Line";
    group.push(line);
  }
} // Stacked area chart

function createStackedAreaChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var pathData = path(canvas, data, conf, i, "forward"),
      zero;

  if (data.niceMax < 0) {
    zero = canvas.y;
  } else {
    zero = canvas.y + canvas.height;
  }

  var yAxe = data.niceMax - data.niceMin,
      yEnd = zero - canvas.height / yAxe * (Number(data.table[i - 1][data.columns - 1]) - data.niceMin);
  pathData += lineToPoint(canvas.x + canvas.width, yEnd);
  pathData += path(canvas, data, conf, i - 1, "back");
  pathData += " Z";
  var area = ShapePath.fromSVGPath(pathData);
  area.style = {
    fills: [conf.colors.common[colorIndex(i - 1, conf.colors.common)]],
    borders: [{
      enabled: false
    }]
  };
  area.name = "Area_" + (i + 1);
  group.push(area);
} // Histogram

function createHistogram(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.table[1].length,
      margin = conf.histogram.margin,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.yNiceMax - data.yNiceMin,
      zero = canvas.y + canvas.height,
      barArray = new Array();

  for (var j = 0; j < data.table[1].length; j++) {
    x0 = x0 + xStep * n;
    x1 = x0 + xStep - 2 * margin;
    y0 = zero;
    y1 = zero - canvas.height / yAxe * (Number(data.table[1][j]) - data.yNiceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors.common[0]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + (j + 1);
    group.push(bar);
    n = n + 1;
    x0 = canvas.x + margin;
  }

  return barArray;
} // Vertical bar chart

function createVerticalBarChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.columns,
      margin = conf.verticalBarChart.margin / 2 * xStep,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height;

  for (var j = 0; j < data.columns; j++) {
    x0 = x0 + xStep * n;
    x1 = x0 + xStep - 2 * margin;
    y0 = zero - canvas.height / yAxe * (Number(data.table[i - 1][j]) - data.niceMin);
    y1 = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors.common[colorIndex(i - 1, conf.colors.common)]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + i + "_" + (j + 1);

    if (i === data.rows - 1 && bar.frame.height > conf.verticalBarChart.roundTop * 2 && bar.frame.height > 4) {
      bar.points[1].cornerRadius = conf.verticalBarChart.roundTop;
      bar.points[2].cornerRadius = conf.verticalBarChart.roundTop;
    }

    group.push(bar);
    n = n + 1;
    x0 = canvas.x + margin;
  }
} // Horizontal bar chart

function createHorizontalBarChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.height / data.columns,
      margin = conf.horizontalBarChart.margin / 2 * xStep,
      y0 = canvas.y + margin,
      x1,
      x0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.x;

  for (var j = 0; j < data.columns; j++) {
    y0 = y0 + xStep * n;
    y1 = y0 + xStep - 2 * margin;
    x0 = zero + canvas.width / yAxe * (Number(data.table[i - 1][j]) - data.niceMin);
    x1 = zero + canvas.width / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors.common[colorIndex(i - 1, conf.colors.common)]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + i + "_" + (j + 1);

    if (i === data.rows - 1 && bar.frame.width > conf.horizontalBarChart.roundTop * 2 && bar.frame.width > 4) {
      bar.points[2].cornerRadius = conf.horizontalBarChart.roundTop;
      bar.points[3].cornerRadius = conf.horizontalBarChart.roundTop;
    }

    group.push(bar);
    n = n + 1;
    y0 = canvas.y + margin;
  }
} // Grouped bar chart

function createGroupBarChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.columns,
      margin = xStep * Number(conf.groupedBarChart.margin) / 2,
      barWidth = xStep * (1 - Number(conf.groupedBarChart.margin)) / data.rows,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + Math.abs(data.niceMax) / yAxe * canvas.height;

  for (var j = 0; j < data.columns; j++) {
    for (var _n = 0; _n < data.rows; _n++) {
      x1 = x0 + barWidth;
      y0 = zero;
      y1 = zero - canvas.height / yAxe * Number(data.table[_n][j]);
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [conf.colors.common[colorIndex(_n, conf.colors.common)]],
        borders: [{
          enabled: false
        }]
      };
      bar.name = "Bar_" + (_n + 1) + "_" + (j + 1);

      if (bar.frame.height > conf.groupedBarChart.roundTop * 2 && bar.frame.height > 4) {
        bar.points[1].cornerRadius = conf.groupedBarChart.roundTop;
        bar.points[2].cornerRadius = conf.groupedBarChart.roundTop;
      }

      group.push(bar);
      x0 = x0 + barWidth;
    }

    x0 = x0 + margin * 2;
  }
} // Grouped horizontal bar chart

function createGroupHorizontalBarChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.height / data.columns,
      margin = xStep * Number(conf.groupedHorizontalBarChart.margin) / 2,
      barWidth = xStep * (1 - Number(conf.groupedHorizontalBarChart.margin)) / data.rows,
      y0 = canvas.y + margin,
      x1,
      x0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.x + Math.abs(data.niceMin) / yAxe * canvas.width;

  for (var j = 0; j < data.columns; j++) {
    for (var _n2 = 0; _n2 < data.rows; _n2++) {
      x1 = zero + canvas.width / yAxe * Number(data.table[_n2][j]);
      x0 = zero;
      y1 = y0 + barWidth;
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [conf.colors.common[colorIndex(_n2, conf.colors.common)]],
        borders: [{
          enabled: false
        }]
      };
      bar.name = "Bar_" + (_n2 + 1) + "_" + (j + 1);

      if (bar.frame.width > conf.groupedHorizontalBarChart.roundTop * 2 && bar.frame.width > 4) {
        bar.points[2].cornerRadius = conf.groupedHorizontalBarChart.roundTop;
        bar.points[3].cornerRadius = conf.groupedHorizontalBarChart.roundTop;
      }

      group.push(bar);
      y0 = y0 + barWidth;
    }

    y0 = y0 + margin * 2;
  }
} // Pie chart

function createPieChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var radius = canvas.width / 2,
      xCenter = canvas.x + radius,
      yCenter = canvas.y + radius,
      pathData,
      sum = data.table[i].reduce(function (partial_sum, a) {
    return Number(partial_sum) + Number(a);
  }),
      startAngle,
      endAngle,
      multi;

  if (sum == 100) {
    multi = 3.6;
  } else {
    multi = 360 / sum;
  }

  if (conf.sorting == 0) {
    var compareNumeric = function compareNumeric(a, b) {
      return b - a;
    };

    var sortedItems = data.table[i];
    sortedItems.sort(compareNumeric);
    data.table[i] = sortedItems;
  }

  if (conf.typeOfCircle == 0) {
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
  } else {
    multi = multi / 2;
    startAngle = -90;
    endAngle = Number(data.table[i][0]) * multi - 90;
  }

  for (var j = 0; j < data.columns; j++) {
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y, "L", xCenter, yCenter, "L", start.x, start.y].join(" ");
    var pie = ShapePath.fromSVGPath(pathData);
    pie.style = {
      fills: [conf.colors.common[colorIndex(j, conf.colors.common)]],
      borders: [{
        enabled: false
      }]
    };
    pie.name = "Pie_" + j;
    group.push(pie);
    startAngle = startAngle + Number(data.table[i][j]) * multi;
    endAngle = endAngle + Number(data.table[i][j + 1]) * multi;
  }
} // Donut chart

function createDonutChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

  if (conf.donutChart.thicknessOfDonut > canvas.width / 2) {
    conf.donutChart.thicknessOfDonut = canvas.width / 4;
  }

  var radius = canvas.width / 2 - conf.donutChart.thicknessOfDonut / 2,
      xCenter = canvas.x + radius + conf.donutChart.thicknessOfDonut / 2,
      yCenter = canvas.y + radius + conf.donutChart.thicknessOfDonut / 2,
      pathData,
      sum = data.table[i].reduce(function (partial_sum, a) {
    return Number(partial_sum) + Number(a);
  }),
      startAngle,
      endAngle,
      multi;

  if (sum == 100) {
    multi = 3.6;
  } else {
    multi = 360 / sum;
  }

  if (conf.sorting == 0) {
    var compareNumeric = function compareNumeric(a, b) {
      return b - a;
    };

    var sortedItems = data.table[i];
    sortedItems.sort(compareNumeric);
    data.table[i] = sortedItems;
  }

  if (conf.typeOfCircle == 0) {
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
  } else {
    multi = multi / 2;
    startAngle = -90;
    endAngle = Number(data.table[i][0]) * multi - 90;
  }

  for (var j = 0; j < data.columns; j++) {
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y].join(" ");
    var donut = ShapePath.fromSVGPath(pathData);
    donut.style = {
      borders: [{
        color: conf.colors.common[colorIndex(j, conf.colors.common)],
        thickness: conf.donutChart.thicknessOfDonut
      }],
      borderOptions: {
        lineEnd: Style.LineEnd.Butt
      }
    };
    donut.name = "Donut_" + j;
    group.push(donut);
    startAngle = startAngle + Number(data.table[i][j]) * multi;
    endAngle = endAngle + Number(data.table[i][j + 1]) * multi;
  }
} // Progress chart

function createProgressChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

  var progress, pathData;

  var bgColor,
      bgColorType = _typeof(conf.progressChart.backgroundColor),
      bgLayer;

  if (bgColorType === 'object') {
    bgColor = conf.progressChart.backgroundColor[0];
  } else {
    bgColor = conf.progressChart.backgroundColor;
  }

  if (canvas.layerType == "Oval") {
    var radius = canvas.width / 2 - conf.progressChart.thicknessOfProgress / 2,
        xCenter = canvas.x + radius + conf.progressChart.thicknessOfProgress / 2,
        yCenter = canvas.y + radius + conf.progressChart.thicknessOfProgress / 2,
        startAngle,
        endAngle,
        multi = 3.6;

    if (conf.typeOfCircle == 0) {
      startAngle = 0;
      endAngle = data.table[i][0] * multi;
    } else {
      multi = multi / 2;
      startAngle = -90;
      endAngle = Number(data.table[i][0]) * multi - 90;
    }

    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y].join(" ");
    progress = ShapePath.fromSVGPath(pathData);
    progress.style = {
      borders: [{
        color: conf.colors.progressChart[0],
        thickness: conf.progressChart.thicknessOfProgress
      }]
    };

    if (conf.typeOfCircle == 0) {
      canvas.layer.style = {
        borders: [{
          color: bgColor,
          thickness: conf.progressChart.thicknessOfProgress,
          position: Style.BorderPosition.Inside
        }]
      };
    } else {
      startAngle = -90;
      endAngle = 90;

      var _start = polarToCartesian(xCenter, yCenter, radius, endAngle),
          _end = polarToCartesian(xCenter, yCenter, radius, startAngle),
          _arcSweep = endAngle - startAngle <= 180 ? "0" : "1";

      pathData = ["M", _start.x, _start.y, "A", radius, radius, 0, _arcSweep, 0, _end.x, _end.y].join(" ");
      bgLayer = ShapePath.fromSVGPath(pathData);
      bgLayer.style = {
        borders: [{
          color: bgColor,
          thickness: conf.progressChart.thicknessOfProgress
        }]
      };
      bgLayer.name = "Background";
      group.push(bgLayer);
      canvas.layer.style = {
        borders: [{
          enabled: false
        }]
      };
    }
  } else {
    var xStart = canvas.x,
        xEnd = canvas.x + canvas.width / 100 * data.table[i][0],
        y = canvas.y + canvas.height / 2;

    if (conf.progressChart.endOfLine == 1) {
      xStart = xStart + canvas.height / 2;
    }

    pathData = ["M", xStart, y, "L", xEnd, y].join(" ");
    progress = ShapePath.fromSVGPath(pathData);
    progress.style = {
      borders: [{
        color: conf.colors.progressChart[0],
        thickness: canvas.height
      }]
    };
    canvas.layer.style = {
      fills: [{
        color: bgColor,
        fillType: Style.FillType.Color
      }],
      borders: [{
        enabled: false
      }]
    };
  }

  if (conf.progressChart.endOfLine == 0) {
    progress.style.borderOptions.lineEnd = Style.LineEnd.Butt;
  } else {
    progress.style.borderOptions.lineEnd = Style.LineEnd.Round;
    canvas.layer.points.forEach(function (point) {
      point.cornerRadius = canvas.height / 2;
    });
  }

  progress.name = "Progress bar";
  group.push(progress);
} // Sparkline

function createSparkline(canvas, conf, data, max, min, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

  var x0 = canvas.x,
      y = 0,
      yAxe = max - min,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - min),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0);

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - min);
    pathData += lineToPoint(xNext, y);
    xLast = xNext;
    yLast = y;
  }

  var line = ShapePath.fromSVGPath(pathData);
  line.style = {
    borders: [{
      color: conf.colors.sparkline[0],
      thickness: conf.sparkline.lineWidth
    }]
  };
  line.name = "Sparkline";
  group.push(line);
  var dot = new ShapePath({
    name: "Dot",
    shapeType: ShapePath.ShapeType.Oval,
    frame: new Rectangle(Math.round(xLast - conf.sparkline.dotDiameter / 2), Math.round(yLast - conf.sparkline.dotDiameter / 2), conf.sparkline.dotDiameter, conf.sparkline.dotDiameter)
  });
  dot.style = {
    fills: [conf.colors.sparkline[0]],
    borders: [{
      enabled: false
    }]
  };
  group.push(dot);
} // Scatter plot

function createScatterPlot(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

  var x = 0,
      y = 0,
      yAxe = data.yNiceMax - data.yNiceMin,
      xAxe = data.xNiceMax - data.xNiceMin,
      yZero = canvas.y + canvas.height,
      xZero = canvas.x,
      radius = conf.scatterPlot.dotDiameter;

  if (data.rows > 2) {
    var maxRad = conf.scatterPlot.dotDiameter;
    var valMax = Math.max.apply(Math, _toConsumableArray(data.table[2]));
    radius = Math.ceil(maxRad * data.table[2][i] / valMax);
  }

  x = xZero + canvas.width / xAxe * (Number(data.table[0][i]) - data.xNiceMin);
  y = yZero - canvas.height / yAxe * (Number(data.table[1][i]) - data.yNiceMin);
  var dot = new ShapePath({
    name: "Dot_" + (i + 1),
    shapeType: ShapePath.ShapeType.Oval,
    frame: new Rectangle(Math.round(x - radius / 2), Math.round(y - radius / 2), radius, radius)
  });
  dot.style = {
    fills: [conf.colors.scatterPlot[0]],
    borders: [{
      enabled: false
    }]
  };
  group.push(dot);
} // Candlestick chart

function createCandlestickChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      step = Math.floor(canvas.width / data.columns),
      margin = (1 - Number(conf.candlestickChart.margin)) / 2 * step,
      xBar = step - 2 * margin,
      x0 = canvas.x + margin,
      y0 = 0,
      x1 = 0,
      y1 = 0,
      x0line = canvas.x + step / 2,
      y0line = 0,
      y1line = 0,
      n = 0,
      candleColor;

  for (var z = 0; z < data.columns; z++) {
    x0line = x0line + step * n;
    x0 = x0line - Math.floor(xBar / 2);
    x1 = x0line + Math.floor(xBar / 2);

    if (data.table[1][z] > data.table[2][z]) {
      y0 = zero - canvas.height / yAxe * (Number(data.table[2][z]) - data.niceMin);
      y1 = zero - canvas.height / yAxe * (Number(data.table[1][z]) - data.niceMin);
      y0line = zero - canvas.height / yAxe * (Number(data.table[3][z]) - data.niceMin);
      y1line = zero - canvas.height / yAxe * (Number(data.table[0][z]) - data.niceMin);
      candleColor = conf.colors.candlestickChart[0];
    } else {
      y0 = zero - canvas.height / yAxe * (Number(data.table[1][z]) - data.niceMin);
      y1 = zero - canvas.height / yAxe * (Number(data.table[2][z]) - data.niceMin);
      y0line = zero - canvas.height / yAxe * (Number(data.table[3][z]) - data.niceMin);
      y1line = zero - canvas.height / yAxe * (Number(data.table[0][z]) - data.niceMin);
      candleColor = conf.colors.candlestickChart[1];
    }

    var lineData = moveToPoint(x0line, y0line);
    lineData += lineToPoint(x0line, y1line);
    var line = ShapePath.fromSVGPath(lineData);
    line.style = {
      borders: [{
        color: candleColor,
        thickness: 1
      }]
    };
    line.name = "Line";
    group.push(line);
    var barData = moveToPoint(x0, y0);
    barData += lineToPoint(x0, y1);
    barData += lineToPoint(x1, y1);
    barData += lineToPoint(x1, y0);
    barData += " Z";
    var bar = ShapePath.fromSVGPath(barData);
    bar.style = {
      fills: [candleColor],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Candle";
    group.push(bar);
    n = 1;
  }
} // Heatmap

function createHeatmap(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  function isInteger(num) {
    return (num ^ 0) === num;
  }

  var division = conf.heatmap.segments,
      margin = conf.heatmap.margin,
      xStep = (canvas.width - margin * (data.rows - 1)) / data.rows,
      yStep = (canvas.height - margin * (data.columns - 1)) / data.columns,
      x0 = canvas.x,
      y0 = canvas.y,
      x1,
      y1,
      barArray = new Array();
  var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, false);
  data.niceMax = niceScales.niceMaximum;
  data.niceMin = niceScales.niceMinimum;

  if (data.niceMin > 0) {
    data.niceMin = 0;
  }

  var opacityStep = 1 / division;

  for (var i = 0; i < data.rows; i++) {
    for (var j = 0; j < data.columns; j++) {
      x1 = x0 + xStep;
      y1 = y0 + yStep;
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var rangeStep = void 0,
          opacity = void 0,
          textRangeMax = void 0,
          textRangeMin = void 0,
          color = void 0;

      if (data.table[i][j] >= 0) {
        rangeStep = data.niceMax / division;
        color = conf.colors.heatmap[0];

        if (isInteger(data.table[i][j] / rangeStep)) {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep + 1);
          textRangeMin = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          textRangeMax = (Math.ceil(data.table[i][j] / rangeStep) + 1) * rangeStep;

          if (Number(data.table[i][j]) === data.niceMax) {
            opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
            textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
            textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          }
        } else {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
          textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
          textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
        }
      } else {
        rangeStep = data.niceMin / division;

        if (conf.colors.heatmap.length > 1) {
          color = conf.colors.heatmap[1];
        } else {
          color = conf.colors.heatmap[0];
        }

        if (isInteger(data.table[i][j] / rangeStep)) {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep + 1);
          textRangeMin = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          textRangeMax = (Math.ceil(data.table[i][j] / rangeStep) + 1) * rangeStep;

          if (Number(data.table[i][j]) === data.niceMin) {
            opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
            textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
            textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          }
        } else {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
          textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
          textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
        }
      }

      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [color],
        borders: [{
          enabled: false
        }],
        opacity: opacity
      };
      bar.name = "Value: " + data.table[i][j] + ", range: " + textRangeMin + "—" + textRangeMax;
      group.push(bar);
      y0 += yStep + margin;
    }

    y0 = canvas.y;
    x0 += xStep + margin;
  }

  return barArray;
} // CREATE CHART

function createChart(canvas, configuration) {
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      Group = __webpack_require__(/*! sketch/dom */ "sketch/dom").Group,
      sketch = __webpack_require__(/*! sketch */ "sketch"),
      doc = sketch.getSelectedDocument();

  var data,
      dataFromPopup = configuration,
      conf = dataFromPopup.settings,
      strConfig = JSON.stringify(configuration),
      editableConfig = JSON.stringify(configuration),
      chartType = dataFromPopup.data.chartName,
      email = Settings.globalSettingForKey('user_email'); // CONVERT FONT SETTINGS

  if (conf.labels.textCase === "ORIGINAL" || conf.labels.textCase === "TITLE") {
    conf.labels.textCase = "none";
  } else if (conf.labels.textCase === "UPPER") {
    conf.labels.textCase = "uppercase";
  } else {
    conf.labels.textCase = "lowercase";
  }

  if (conf.labels.fontStyle.toLowerCase().indexOf("bold") >= 0) {
    conf.labels.fontStyle = 9;
  } else if (conf.labels.fontStyle.toLowerCase().indexOf("semibold") >= 0) {
    conf.labels.fontStyle = 8;
  } else if (conf.labels.fontStyle.toLowerCase().indexOf("light") >= 0) {
    conf.labels.fontStyle = 3;
  } else if (conf.labels.fontStyle.toLowerCase().indexOf("thin") >= 0) {
    conf.labels.fontStyle = 2;
  } else {
    conf.labels.fontStyle = 5;
  } // COLLECT STATS


  var appVersion = context.plugin.version(),
      userId = Settings.globalSettingForKey('userId'),
      accountType = Settings.globalSettingForKey('user_type');
  collectStats(userId, email, appVersion, chartType, accountType);
  canvas.forEach(function (canvas, index) {
    var _chartGroup$layers;

    var parent = doc.getLayerWithID(canvas.parent),
        layer = doc.getLayerWithID(canvas.layer),
        numParam = conf.labels.type != 0 ? canvas.height : false,
        numWidthParam = conf.labels.type != 0 ? canvas.width : false;
    canvas.parent = parent;
    canvas.layer = layer;
    layer.selected = false; // UNGROUP LAYERS

    if (canvas.conf != undefined) {
      var _parent = canvas.parent,
          group = canvas.layer,
          newX = canvas.layer.frame.x,
          newY = canvas.layer.frame.y,
          oldCanvas = canvas.layer.layers[0];
      var yMin = null,
          yMax = null,
          xMin = null,
          xMax = null;
      var axesNums = canvas.layer.name.match(/\[(.*?)]/g);
      var axesRange = [];

      if (axesNums != null) {
        var axes = axesNums[0].replace(/\[(.*?)\]/g, "$1").split(";");
        axes.forEach(function (num) {
          var splitedAxe = num.split("-");

          if (splitedAxe.length > 1) {
            axesRange.push(splitedAxe);
          }
        });
      }

      if (axesRange.length > 0) {
        yMin = axesRange[0][0];
        yMax = axesRange[0][1];

        if (axesRange.length > 1) {
          xMin = axesRange[1][0];
          xMax = axesRange[1][1];
        }
      }

      _parent.layers.push(oldCanvas);

      oldCanvas.frame.x = newX + oldCanvas.frame.x;
      oldCanvas.frame.y = newY + oldCanvas.frame.y;
      group.remove();
      canvas = {
        layer: oldCanvas,
        height: oldCanvas.frame.height,
        width: oldCanvas.frame.width,
        x: oldCanvas.frame.x,
        y: oldCanvas.frame.y,
        layerType: oldCanvas.shapeType,
        startNum: "false",
        yMin: yMin,
        yMax: yMax,
        xMin: xMin,
        xMax: xMax,
        parent: oldCanvas.parent,
        conf: canvas.setting
      };
    } // PREPARE DATA


    if (dataFromPopup.data.selected == "random") {
      var random = dataFromPopup.data.random;
      data = createRandomData(random.categories.value, random.items.value, random.min, random.max, random.randType, chartType);
      var tempData = JSON.parse(strConfig);
      tempData.data.random.data = [data.header].concat(_toConsumableArray(data.table));
      strConfig = JSON.stringify(tempData);
    } else if (dataFromPopup.data.selected == "table") {
      data = processData(dataFromPopup.data.csv);
    } else {
      data = processJSON(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
    } // PREPARE STACKED DATA


    if (chartType === "stackedAreaChart" || chartType === "verticalBarChart" || chartType === "horizontalBarChart" || chartType === "streamGraph") {
      for (var i = 1; i < data.rows; i++) {
        for (var j = 0; j < data.columns; j++) {
          data.table[i][j] = Number(data.table[i - 1][j]) + Number(data.table[i][j]);
        }
      }

      var zeroArray = new Array();

      for (var _i12 = 0; _i12 < data.columns; _i12++) {
        zeroArray[_i12] = 0;
      }

      ;
      data.table.unshift(zeroArray);
      data.rows = data.rows + 1; // New min and max

      data.max = Math.max.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
      data.min = Math.min.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
    } // REMOVE LABELS AND GRIDS FOR SMALL CHARTS


    if (canvas.width < 200 && canvas.height < 100) {
      conf.labels.type = 0;
      conf.grid.type = 0;
      conf.lineChart.dotType = 0;
      numParam = false;
      numWidthParam = false;
    } // CREATE NODES ARRAY


    var nodes = [canvas.layer]; // SELECT CHART

    if (chartType == "lineChart") {
      if (conf.beginAtZero === 0) {
        if (data.min > 0) {
          data.min = 0;
        } else if (data.max < 0) {
          data.max = 0;
        }
      } // Scale Y axis


      var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);
      data.niceMax = niceScales.niceMaximum;
      data.niceMin = niceScales.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var marginsData = calculateMargins(canvas, data, conf, chartType); // Labels

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, marginsData, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, marginsData.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, marginsData);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      } // Chart


      for (var _i13 = 0; _i13 < data.rows; _i13++) {
        createLineChart(canvas, conf, data, _i13, nodes);
      }
    } else if (chartType == "areaChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales.niceMaximum;
      data.niceMin = _niceScales.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i14 = 0; _i14 < data.rows; _i14++) {
        createAreaChart(canvas, conf, data, _i14, nodes);
      }
    } else if (chartType == "stackedAreaChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales2 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales2.niceMaximum;
      data.niceMin = _niceScales2.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData2 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData2, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData2.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData2);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i15 = 1; _i15 < data.rows; _i15++) {
        createStackedAreaChart(canvas, conf, data, _i15, nodes);
      }
    } else if (chartType == "verticalBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales3 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales3.niceMaximum;
      data.niceMin = _niceScales3.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData3 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData3.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData3.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "horizontal");
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i16 = 1; _i16 < data.rows; _i16++) {
        createVerticalBarChart(canvas, conf, data, _i16, nodes);
      }
    } else if (chartType == "horizontalBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales4 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales4.niceMaximum;
      data.niceMin = _niceScales4.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData4 = calculateMarginsHorizontal(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData4.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData4.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "vertical");
      }

      for (var _i17 = 1; _i17 < data.rows; _i17++) {
        createHorizontalBarChart(canvas, conf, data, _i17, nodes);
      }
    } else if (chartType == "groupedBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales5 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales5.niceMaximum;
      data.niceMin = _niceScales5.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData5 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData5.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData5.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "horizontal");
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      createGroupBarChart(canvas, conf, data, nodes);
    } else if (chartType == "groupedHorizontalBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales6 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales6.niceMaximum;
      data.niceMin = _niceScales6.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData6 = calculateMarginsHorizontal(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData6.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData6.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "vertical");
      }

      createGroupHorizontalBarChart(canvas, conf, data, nodes);
    } else if (chartType == "streamGraph") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales7 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales7.niceMaximum;
      data.niceMin = _niceScales7.niceMinimum;

      for (var _i18 = 0; _i18 < data.rows; _i18++) {
        for (var _j4 = 0; _j4 < data.columns; _j4++) {
          data.table[_i18][_j4] = Number(data.table[_i18][_j4]) + (data.niceMax - Number(data.table[data.rows - 1][_j4])) / 2;
        }
      } // Margins


      if (conf.labels.type == 1 || conf.labels.type == 2) {
        conf.labels.type = 3;
      }

      var _marginsData7 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData7, chartType);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData7);
      }

      for (var _i19 = 1; _i19 < data.rows; _i19++) {
        createStackedAreaChart(canvas, conf, data, _i19, nodes);
      }
    } else if (chartType == "scatterPlot") {
      var _xMin = Math.min.apply(Math, _toConsumableArray(data.table[0])),
          _xMax = Math.max.apply(Math, _toConsumableArray(data.table[0])),
          _yMin = Math.min.apply(Math, _toConsumableArray(data.table[1])),
          _yMax = Math.max.apply(Math, _toConsumableArray(data.table[1]));

      if (conf.beginAtZero === 0) {
        if (_xMin > 0) {
          _xMin = 0;
        }

        if (_yMin > 0) {
          _yMin = 0;
        }
      }

      var xNiceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_xMin, _xMax, numWidthParam),
          yNiceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_yMin, _yMax, numParam);
      data.xNiceMax = xNiceScales.niceMaximum;
      data.xNiceMin = xNiceScales.niceMinimum;
      data.yNiceMax = yNiceScales.niceMaximum;
      data.yNiceMin = yNiceScales.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.yNiceMin = canvas.yMin;
        data.yNiceMax = canvas.yMax;
      }

      if (canvas.xMin != null && canvas.xMax != null) {
        data.xNiceMin = canvas.xMin;
        data.xNiceMax = canvas.xMax;
      } // Margins


      var _marginsData8 = calculateMarginsHistogram(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData8.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData8.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i20 = 0; _i20 < data.columns; _i20++) {
        createScatterPlot(canvas, conf, data, _i20, nodes);
      }
    } else if (chartType == "candlestickChart") {
      var maxLine = Math.max.apply(Math, _toConsumableArray(data.table[0])),
          minLine = Math.min.apply(Math, _toConsumableArray(data.table[3]));

      if (conf.beginAtZero === 0) {
        if (minLine > 0) {
          minLine = 0;
        }
      }

      var _niceScales8 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(minLine, maxLine, numParam);

      data.niceMax = _niceScales8.niceMaximum;
      data.niceMin = _niceScales8.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData9 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData9, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData9.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData9);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      createCandlestickChart(canvas, conf, data, nodes);
    } else if (chartType == "pieChart") {
      createPieChart(canvas, conf, data, index, nodes);
    } else if (chartType == "donutChart") {
      createDonutChart(canvas, conf, data, index, nodes);
    } else if (chartType == "progressChart") {
      createProgressChart(canvas, conf, data, index, nodes);
    } else if (chartType == "sparkline") {
      var max = Math.max.apply(Math, _toConsumableArray(data.table[index])),
          min = Math.min.apply(Math, _toConsumableArray(data.table[index])),
          _niceScales9 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(min, max, false);

      max = _niceScales9.niceMaximum;
      min = _niceScales9.niceMinimum;
      createSparkline(canvas, conf, data, max, min, index, nodes);
    } else if (chartType == "histogram") {
      var inRange = function inRange(x, min, max) {
        return (x - min) * (x - max) <= 0;
      };

      var transformData = function transformData(data) {
        var minStepPx = 10;

        if (canvas.width < 200 && canvas.height < 100) {
          minStepPx = 5;
        }

        var range = data.xNiceMax - data.xNiceMin,
            maxNumTicks = Math.floor(canvas.width / minStepPx),
            dividers = [0.1, 0.2, 0.5];
        var step = dividers[0],
            numLines = Math.ceil(range / step),
            i = 0,
            count = 1;

        while (numLines >= maxNumTicks) {
          step = dividers[i] * count;
          numLines = Math.ceil(range / step);

          if (i === 2) {
            i = 0;
            count = count * 10;
          } else {
            i++;
          }
        }

        var newData = [];

        var _loop = function _loop(_i21) {
          var countOfNums = 0;
          data.table[0].forEach(function (num) {
            if (inRange(num, step * _i21, step * (_i21 + 1))) {
              countOfNums += 1;
            }
          });
          newData.push(countOfNums);
        };

        for (var _i21 = 0; _i21 < data.xNiceMax / step; _i21++) {
          _loop(_i21);
        }

        return newData;
      };

      var _min = Math.min.apply(Math, _toConsumableArray(data.table[0])),
          _max = Math.max.apply(Math, _toConsumableArray(data.table[0]));

      data.xNiceMin = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_min, _max, numWidthParam).niceMinimum;
      data.xNiceMax = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_min, _max, numWidthParam).niceMaximum;

      var newData = transformData(data),
          _yMin2 = Math.min.apply(Math, _toConsumableArray(newData)),
          _yMax2 = Math.max.apply(Math, _toConsumableArray(newData));

      data.table[1] = newData;

      if (conf.beginAtZero === 0) {
        if (_yMin2 > 0) {
          _yMin2 = 0;
        }
      }

      data.yNiceMax = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_yMin2, _yMax2, numParam).niceMaximum;
      data.yNiceMin = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_yMin2, _yMax2, numParam).niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.yNiceMin = canvas.yMin;
        data.yNiceMax = canvas.yMax;
      } // Margins


      var _marginsData10 = calculateMarginsHistogram(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData10.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData10.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      createHistogram(canvas, conf, data, nodes);
    } else if (chartType == "heatmap") {
      var horizontalHeaders = [];

      if (dataFromPopup.data.selected == "table" && (dataFromPopup.data.csv.type === "google" || dataFromPopup.data.csv.type === "csv")) {
        dataFromPopup.data.csv.columns.forEach(function (column) {
          if (column.checked) {
            horizontalHeaders.push(column.name);
          }
        });
      } else if (dataFromPopup.data.selected == "json") {
        dataFromPopup.data.json.keys.forEach(function (key) {
          if (key.checked) {
            horizontalHeaders.push(key.name);
          }
        });
      } else {
        for (var _i22 = 0; _i22 < data.rows; _i22++) {
          horizontalHeaders[_i22] = "Text";
        }
      }

      data.horizontalHeaders = horizontalHeaders; // Margins

      var _marginsData11 = calculateMarginsHeatmap(canvas, data, conf, chartType);

      console.log("margins: true"); // Labels

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData11.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        xAxisDistrLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData11.minW);
      }

      console.log("labels: true");
      createHeatmap(canvas, conf, data, nodes);
      console.log(nodes);
    } // CREATE GROUP


    var chartGroup = new Group({
      name: dataFromPopup.data.fullChartName,
      parent: canvas.parent
    });

    (_chartGroup$layers = chartGroup.layers).push.apply(_chartGroup$layers, nodes);

    Settings.setLayerSettingForKey(chartGroup, 'localConf', JSON.parse(editableConfig));
    chartGroup.adjustToFit(); // UPDATE DATA

    dataFromPopup = JSON.parse(strConfig);
  });
} // TEST CHART

function testChart(canvas, configuration) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      doc = sketch.getSelectedDocument();

  var artboard = doc.getLayerWithID(canvas[0].layer);
  artboard.selected = false;
  var canvases = {
    l: [500, 310],
    m: [250, 150],
    s: [50, 30]
  },
      margin = 30,
      step = 0,
      chartL = [['lineChart', 2, 10], ['areaChart', 2, 10], ["stackedAreaChart", 3, 10], ["streamGraph", 3, 10], ["verticalBarChart", 2, 10], ["horizontalBarChart", 2, 5], ["groupedBarChart", 3, 5], ["groupedHorizontalBarChart", 2, 5], ["scatterPlot", 2, 20], ["candlestickChart", 4, 20], ["heatmap", 6, 4], ["histogram", 1, 100], ["pieChart", 1, 5], ["donutChart", 1, 5], ["progressChart", 1, 1], ["sparkline", 1, 40]],
      chartM = [['lineChart', 2, 5], ['areaChart', 2, 5], ["stackedAreaChart", 3, 5], ["streamGraph", 3, 5], ["verticalBarChart", 2, 5], ["horizontalBarChart", 2, 3], ["groupedBarChart", 2, 5], ["groupedHorizontalBarChart", 2, 3], ["scatterPlot", 2, 20], ["candlestickChart", 4, 10], ["heatmap", 6, 4], ["histogram", 1, 100], ["pieChart", 1, 5], ["donutChart", 1, 5], ["progressChart", 1, 1], ["sparkline", 1, 20]],
      chartS = [['lineChart', 2, 5], ['areaChart', 2, 5], ["stackedAreaChart", 3, 5], ["streamGraph", 3, 5], ["verticalBarChart", 2, 5], ["horizontalBarChart", 2, 3], ["groupedBarChart", 2, 5], ["groupedHorizontalBarChart", 2, 3], ["scatterPlot", 2, 10], ["candlestickChart", 4, 5], ["heatmap", 6, 4], ["histogram", 1, 100], ["pieChart", 1, 5], ["donutChart", 1, 5], ["progressChart", 1, 1], ["sparkline", 1, 10]];
  chartL.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin,
          width: canvases.l[1],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin,
          width: canvases.l[0],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas);
      _testCanvas.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.l[0] + 30;
  });
  step = 0;
  margin = 30;
  chartL.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];
    newConf.settings.labels.type = 0;
    newConf.settings.grid.type = 0;

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin + 340,
          width: canvases.l[1],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas2 = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin + 340,
          width: canvases.l[0],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas2);
      _testCanvas2.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.l[0] + 30;
  });
  step = 0;
  margin = 30;
  chartM.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin + 680,
          width: canvases.m[1],
          height: canvases.m[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas3 = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin + 680,
          width: canvases.m[0],
          height: canvases.m[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas3);
      _testCanvas3.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.m[0] + 30;
  });
  step = 0;
  margin = 30;
  chartS.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin + 680 + 180,
          width: canvases.s[1],
          height: canvases.s[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas4 = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin + 680 + 180,
          width: canvases.s[0],
          height: canvases.s[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas4);
      _testCanvas4.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.s[0] + 30;
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/create.js":
/*!***********************!*\
  !*** ./src/create.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common */ "./src/common.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch-module-web-view */ "./node_modules/sketch-module-web-view/lib/index.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @skpm/dialog */ "./node_modules/@skpm/dialog/lib/index.js");
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_skpm_dialog__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch-module-web-view/remote */ "./node_modules/sketch-module-web-view/remote.js");
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__);




/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      fetch = __webpack_require__(/*! sketch-polyfill-fetch */ "./node_modules/sketch-polyfill-fetch/lib/index.js"); // Global settings


  var status = Settings.globalSettingForKey('user_status'),
      email = Settings.globalSettingForKey('user_email'),
      templateURL = "https://chart.pavelkuligin.ru/settings/" + email,
      userId = Settings.globalSettingForKey('userId'),
      templates = Settings.globalSettingForKey('chartplugin.templates'),
      canvas = Object(_common__WEBPACK_IMPORTED_MODULE_0__["getCanvas"])(context)[0],
      today = Date.now();

  if (templates === undefined) {
    templates = JSON.stringify(Object(_common__WEBPACK_IMPORTED_MODULE_0__["defaultConf"])());
  } else {
    templates = JSON.stringify(Object(_common__WEBPACK_IMPORTED_MODULE_0__["renewTemplate"])(JSON.parse(templates)));
  }

  if (userId === undefined) {
    Settings.setGlobalSettingForKey('userId', NSUUID.UUID().UUIDString());
  } // Checking subscription asinc


  Object(_common__WEBPACK_IMPORTED_MODULE_0__["checkSubscribtion"])(email); // Pass request to webView

  if (canvas.length > 0) {
    var options = {
      identifier: 'chart',
      width: 500,
      height: 380,
      show: false,
      minimizable: false,
      maximizable: false,
      alwaysOnTop: true
    },
        browserWindow = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_1___default.a(options),
        webContents = browserWindow.webContents;
    var canvasData = {
      canvas: canvas,
      conf: templates,
      status: status
    },
        dataStr = JSON.stringify(canvasData);
    fetch(templateURL).then(function (res) {
      return res.json();
    }).then(function (data) {
      if (email != undefined) {
        if (data.settings != undefined) {
          templates = JSON.stringify(Object(_common__WEBPACK_IMPORTED_MODULE_0__["renewTemplate"])(data.settings.data));
          Settings.setGlobalSettingForKey('chartplugin.templates', templates);
          webContents.executeJavaScript('applyTemplate(' + templates + ')');
        }

        Object(_common__WEBPACK_IMPORTED_MODULE_0__["setTemplate"])(templates, email);
      }
    });
    webContents.on('did-finish-load', function () {
      webContents.executeJavaScript('dataMsg(' + dataStr + ')');
      browserWindow.show();
    });
    webContents.on('externalLinkClicked', function (url) {
      NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
    });
    webContents.on('nativeLog', function (type, meta) {
      if (type == 'csv') {
        var getFile = function getFile() {
          var fileURL = _skpm_dialog__WEBPACK_IMPORTED_MODULE_2___default.a.showOpenDialog({
            title: "Choose CSV file",
            filters: [{
              name: 'CSV',
              extensions: ['csv']
            }],
            properties: ['openFile']
          })._value.filePaths[0];

          return fileURL;
        };

        var url = getFile();
        var result = NSString.stringWithContentsOfFile_encoding_error(url, NSUTF8StringEncoding, null),
            shortName = url.split("/");
        var newText = result.replace(/[\n]/g, ";").split('"'),
            cuttedText = new Array(),
            counter = 1;

        for (var i = 0; i < newText.length; i++) {
          if (counter % 2 == 0) {
            cuttedText[i] = newText[i].replace(/,/g, "");
          } else {
            cuttedText[i] = newText[i];
          }

          counter += 1;
        }

        var dataTable = cuttedText.join("").split(";");

        for (var _i in dataTable) {
          dataTable[_i] = dataTable[_i].split(",");
        }

        var tableObject = {
          name: shortName[shortName.length - 1],
          type: "csv",
          table: dataTable
        };
        var dataTableString = JSON.stringify(tableObject);
        var tableGS = 'tableGS(' + dataTableString + ')';
        Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__["sendToWebview"])('chart', tableGS);
      } else if (type == 'google') {
        var gsData = meta;
        var sheetsLink = "https://sheets.googleapis.com/v4/spreadsheets/" + gsData.sheet + "?&fields=sheets.properties&key=AIzaSyAOyxH85I1NqnV2Ta-rHKn7_MZpwVBTzmk";
        fetch(sheetsLink).then(function (res) {
          return res.json();
        }).then(function (data) {
          data.sheets.forEach(function (sheet) {
            if (sheet.properties.sheetId === Number(gsData.id)) {
              var title = sheet.properties.title.replace(/ /g, "%20");
              var valuesLink = "https://sheets.googleapis.com/v4/spreadsheets/" + gsData.sheet + "/values/%27" + title + "%27%21A1:BZ100?key=AIzaSyAOyxH85I1NqnV2Ta-rHKn7_MZpwVBTzmk";
              log(valuesLink);
              fetch(valuesLink).then(function (res) {
                return res.json();
              }).then(function (valuesArray) {
                var tableObject = {
                  name: gsData.original,
                  type: "google",
                  table: valuesArray.values
                };
                var dataTableString = JSON.stringify(tableObject);
                var tableGS = 'tableGS(' + dataTableString + ')';
                Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__["sendToWebview"])('chart', tableGS);
              });
            }
          });
        });
      } else if (type == 'http') {
        fetch(meta).then(function (res) {
          return {
            name: meta,
            json: res.json()._value
          };
        }).then(function (jsonObject) {
          var shortName = jsonObject.name.split("/");
          var jObject = {
            name: shortName[shortName.length - 1],
            json: jsonObject.json
          };
          var jsonString = JSON.stringify(jObject);
          var jObjectRequest = 'loadJSON(' + jsonString + ')';
          Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__["sendToWebview"])('chart', jObjectRequest);
        });
      } else if (type == 'json') {
        var _getFile = function _getFile() {
          var fileURL = _skpm_dialog__WEBPACK_IMPORTED_MODULE_2___default.a.showOpenDialog({
            title: "Choose file",
            filters: [{
              name: 'JSON',
              extensions: ['json']
            }],
            properties: ['openFile']
          })._value.filePaths[0];

          return fileURL;
        };

        var _url = _getFile();

        var _result = NSString.stringWithContentsOfFile_encoding_error(_url, NSUTF8StringEncoding, null),
            JSONresult = JSON.parse(_result),
            _shortName = _url.split("/");

        var jObject = {
          name: _shortName[_shortName.length - 1],
          json: JSONresult
        };
        var jsonString = JSON.stringify(jObject);
        var jObjectRequest = 'loadJSON(' + jsonString + ')';
        Object(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_3__["sendToWebview"])('chart', jObjectRequest);
      } else {
        var data = JSON.parse(meta);

        if (data.updateTemplate) {
          data.conf.settings.updatable = true;
          var newSettings = new Array();
          templates = JSON.parse(templates);
          templates.forEach(function (template) {
            if (template.name === data.conf.settings.name) {
              newSettings.push(data.conf.settings);
            } else {
              newSettings.push(template);
            }
          });

          if (status) {
            Object(_common__WEBPACK_IMPORTED_MODULE_0__["setTemplate"])(JSON.stringify(newSettings), email);
          }

          Settings.setGlobalSettingForKey('chartplugin.templates', JSON.stringify(newSettings));
        } else {
          data.conf.settings.updatable = false;
        }

        if (status) {
          Object(_common__WEBPACK_IMPORTED_MODULE_0__["createChart"])(data.canvas, data.conf);
        } else {
          if (data.conf.data.chartName === "lineChart" || data.conf.data.chartName === "areaChart") {
            Object(_common__WEBPACK_IMPORTED_MODULE_0__["createChart"])(data.canvas, data.conf);
          }
        } // testChart(canvas, data.conf)


        browserWindow.destroy();
      }
    });
    browserWindow.loadURL(__webpack_require__(/*! ../assets/createChart.html */ "./assets/createChart.html"));
  } else {
    UI.message('Select a layer to create a chart');
  }
});

/***/ }),

/***/ "./src/nicenum.js":
/*!************************!*\
  !*** ./src/nicenum.js ***!
  \************************/
/*! exports provided: calculateNiceNum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateNiceNum", function() { return calculateNiceNum; });
function calculateNiceNum(minNum, maxNum, height) {
  // Nice max and min functions
  var minPoint,
      maxPoint,
      maxTicks = 10,
      minStep = 30,
      range,
      tickSpacing,
      niceMin,
      niceMax;
  /**
   * Instantiates a new instance of the NiceScale class.
   *
   *  min the minimum data point on the axis
   *  max the maximum data point on the axis
   */

  function niceScale(min, max) {
    minPoint = min;
    maxPoint = max;
    calculate();

    if (height != false) {
      var _range = niceMax - niceMin,
          maxNumTicks = Math.floor(height / minStep),
          dividers = [0.1, 0.2, 0.5];

      var step = dividers[0],
          numLines = Math.ceil(_range / step),
          i = 0,
          count = 1;

      while (numLines >= maxNumTicks) {
        step = dividers[i] * count;
        numLines = Math.ceil(_range / step);

        if (i === 2) {
          i = 0;
          count = count * 10;
        } else {
          i++;
        }
      }

      niceMax = niceMin + step * numLines;
    }

    return {
      niceMinimum: niceMin,
      niceMaximum: niceMax
    };
  }
  /**
   * Calculate and update values for tick spacing and nice
   * minimum and maximum data points on the axis.
   */


  function calculate() {
    range = niceNum(maxPoint - minPoint, false);
    tickSpacing = niceNum(range / (maxTicks - 1), true);
    niceMin = Math.floor(minPoint / tickSpacing) * tickSpacing;
    niceMax = Math.ceil(maxPoint / tickSpacing) * tickSpacing;
  }
  /**
   * Returns a "nice" number approximately equal to range Rounds
   * the number if round = true Takes the ceiling if round = false.
   *
   *  localRange the data range
   *  round whether to round the result
   *  a "nice" number to be used for the data range
   */


  function niceNum(localRange, round) {
    var exponent;
    /** exponent of localRange */

    var fraction;
    /** fractional part of localRange */

    var niceFraction;
    /** nice, rounded fraction */

    exponent = Math.floor(Math.log10(localRange));
    fraction = localRange / Math.pow(10, exponent);

    if (round) {
      if (fraction < 1.5) niceFraction = 1;else if (fraction < 3) niceFraction = 2;else if (fraction < 7) niceFraction = 5;else niceFraction = 10;
    } else {
      if (fraction <= 1) niceFraction = 1;else if (fraction <= 2) niceFraction = 2;else if (fraction <= 5) niceFraction = 5;else niceFraction = 10;
    }

    return niceFraction * Math.pow(10, exponent);
  }

  return niceScale(minNum, maxNum);
}

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__create.js.map