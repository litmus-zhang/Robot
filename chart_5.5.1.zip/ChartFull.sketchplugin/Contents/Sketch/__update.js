var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/update.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var error;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          error
        );
        if (error != null) {
          return reject(error);
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, error) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          if (error) {
            finished = true;
            return reject(error);
          }
          return resolve(response(res, data));
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var exception;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          exception
        );
        if (exception != null) {
          var error = new TypeError(
            String(
              typeof exception.localizedDescription === "function"
                ? exception.localizedDescription()
                : exception
            )
          );
          reject(error);
          return;
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
          break;
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, exception) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          finished = true;
          try {
            if (exception) {
              var error = new TypeError(
                String(
                  typeof exception.localizedDescription === "function"
                    ? exception.localizedDescription()
                    : exception
                )
              );
              reject(error);
              return;
            }
            resolve(response(res, data));
          } catch (err) {
            reject(err);
          }
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./src/common.js":
/*!***********************!*\
  !*** ./src/common.js ***!
  \***********************/
/*! exports provided: setTemplate, checkSubscribtion, collectStats, getCanvas, defaultConf, renewTemplate, colorIndex, calculateMargins, calculateMarginsHorizontal, calculateMarginsHistogram, calculateMarginsHeatmap, moveToPoint, lineToPoint, curveToPoint, path, createOval, polarToCartesian, xAxisGrid, xAxisDistrGrid, yAxisGrid, xAxisLabels, xAxisDistrLabels, yAxisLabels, createRandomData, processData, processJSON, createDots, createLineChart, createAreaChart, createStackedAreaChart, createHistogram, createVerticalBarChart, createHorizontalBarChart, createGroupBarChart, createGroupHorizontalBarChart, createPieChart, createDonutChart, createProgressChart, createSparkline, createScatterPlot, createCandlestickChart, createHeatmap, createChart, testChart */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setTemplate", function() { return setTemplate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkSubscribtion", function() { return checkSubscribtion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collectStats", function() { return collectStats; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCanvas", function() { return getCanvas; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultConf", function() { return defaultConf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renewTemplate", function() { return renewTemplate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorIndex", function() { return colorIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMargins", function() { return calculateMargins; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMarginsHorizontal", function() { return calculateMarginsHorizontal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMarginsHistogram", function() { return calculateMarginsHistogram; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateMarginsHeatmap", function() { return calculateMarginsHeatmap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveToPoint", function() { return moveToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lineToPoint", function() { return lineToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "curveToPoint", function() { return curveToPoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "path", function() { return path; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createOval", function() { return createOval; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "polarToCartesian", function() { return polarToCartesian; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisGrid", function() { return xAxisGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisDistrGrid", function() { return xAxisDistrGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yAxisGrid", function() { return yAxisGrid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisLabels", function() { return xAxisLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xAxisDistrLabels", function() { return xAxisDistrLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yAxisLabels", function() { return yAxisLabels; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createRandomData", function() { return createRandomData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processData", function() { return processData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processJSON", function() { return processJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDots", function() { return createDots; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createLineChart", function() { return createLineChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createAreaChart", function() { return createAreaChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStackedAreaChart", function() { return createStackedAreaChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHistogram", function() { return createHistogram; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createVerticalBarChart", function() { return createVerticalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHorizontalBarChart", function() { return createHorizontalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createGroupBarChart", function() { return createGroupBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createGroupHorizontalBarChart", function() { return createGroupHorizontalBarChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPieChart", function() { return createPieChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createDonutChart", function() { return createDonutChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createProgressChart", function() { return createProgressChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSparkline", function() { return createSparkline; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createScatterPlot", function() { return createScatterPlot; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createCandlestickChart", function() { return createCandlestickChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createHeatmap", function() { return createHeatmap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createChart", function() { return createChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "testChart", function() { return testChart; });
/* harmony import */ var _nicenum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nicenum */ "./src/nicenum.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

 // GENERAL
// check cloud templates

function setTemplate(template, email) {
  var settings = {
    email: email,
    settings: {
      data: JSON.parse(template)
    }
  };
  fetch('https://chart.pavelkuligin.ru/settings/', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Origin': null
    },
    body: JSON.stringify(settings)
  });
} // return the status of subscription

function checkSubscribtion(email) {
  var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      API = "https://api.gumroad.com/v2/products/mPhu9ohiu6ddjaUOUuQ8IQ==/subscribers?access_token=190c56c544530cf3e170a90141c87cf060d920a96f7f0c221d0ee63a06fbdc5d",
      teamAPI = "https://api.gumroad.com/v2/products/Xr8PoVPBvwGyfs5A07MbqQ==/subscribers?access_token=190c56c544530cf3e170a90141c87cf060d920a96f7f0c221d0ee63a06fbdc5d";

  var count = 0,
      teamCount = 0;
  fetch(API).then(function (res) {
    return res.json();
  }).then(function (gumroad) {
    gumroad.subscribers.forEach(function (client) {
      if (client.email.toLowerCase() === email) {
        count += 1;
      }
    });

    if (count > 0) {
      Settings.setGlobalSettingForKey('user_status', true);
      Settings.setGlobalSettingForKey('user_type', 'PRO');
    } else {
      fetch(teamAPI).then(function (res) {
        return res.json();
      }).then(function (gumroad) {
        gumroad.subscribers.forEach(function (client) {
          if (client.email.toLowerCase() === email) {
            teamCount += 1;
          }
        });

        if (teamCount > 0) {
          Settings.setGlobalSettingForKey('user_status', true);
          Settings.setGlobalSettingForKey('user_type', 'TEAM');
        } else {
          Settings.setGlobalSettingForKey('user_status', false);
          Settings.setGlobalSettingForKey('user_type', 'FREE');
        }
      });
    }
  });
} // collect stats

function collectStats(userId, email, appVersion, option, meta) {
  var date = Math.floor(Date.now() / 1000),
      stats = {
    "userId": userId,
    "email": email,
    "date": date,
    "app": "Chart",
    "appVersion": appVersion,
    "option": option,
    "platform": "Sketch",
    "meta": meta
  };
  fetch('https://chart.pavelkuligin.ru/collect', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: stats
  }).then(function (res) {
    if (res.ok) {} else {}
  }).catch(function (error) {});
} // function that returns all parameters of canvases

function getCanvas(context) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      doc = sketch.getSelectedDocument();

  var selection = doc.selectedLayers,
      canvasArr = new Array(),
      error = false,
      canvas;

  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  if (selection.length > 0) {
    selection.forEach(function (layer) {
      if (layer.shapeType === "Rectangle" || layer.shapeType === "Oval") {
        layer.style.fills = [];
        layer.style.borders = [];
      }

      var setting = Settings.layerSettingForKey(layer, 'localConf');
      var yMin = null,
          yMax = null,
          xMin = null,
          xMax = null;
      var axesNums = layer.name.match(/\[(.*?)]/g);
      var axesRange = [];

      if (axesNums != null) {
        var axes = axesNums[0].replace(/\[(.*?)\]/g, "$1").split(";");
        axes.forEach(function (num) {
          var splitedAxe = num.split("-");

          if (splitedAxe.length > 1) {
            axesRange.push(splitedAxe);
          }
        });
      }

      if (axesRange.length > 0) {
        yMin = axesRange[0][0];
        yMax = axesRange[0][1];

        if (axesRange.length > 1) {
          xMin = axesRange[1][0];
          xMax = axesRange[1][1];
        }
      }

      canvas = {
        layer: layer.id,
        height: layer.frame.height,
        width: layer.frame.width,
        x: layer.frame.x,
        y: layer.frame.y,
        layerType: layer.shapeType,
        startNum: "false",
        yMin: yMin,
        yMax: yMax,
        xMin: xMin,
        xMax: xMax,
        parent: layer.parent.id,
        conf: setting
      };
      canvasArr.push(canvas);
    });
  }

  return [canvasArr, error];
} // default configuration

function defaultConf() {
  var template = [{
    "name": "Default template",
    "id": 0,
    "colors": {
      "common": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "progressChart": ["#e31a1c"],
      "sparkline": ["#343434"],
      "scatterPlot": ["#1f78b4"],
      "candlestickChart": ["#33a02c", "#e31a1c"],
      "heatmap": ["#a6cee3"]
    },
    "grid": {
      "type": 1,
      "lineWidth": 1,
      "color": "#F0F0F0"
    },
    "labels": {
      "type": 1,
      "fontName": "Roboto",
      "fontStyle": "Regular",
      "textCase": "ORIGINAL",
      "fontSize": 10,
      "lineHeight": 10,
      "letterSpacing": 0,
      "color": "#a3a3a3",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom"
    },
    "beginAtZero": 0,
    "lineType": 0,
    "sorting": 0,
    "typeOfCircle": 0,
    "lineChart": {
      "lineWidth": 2,
      "dotType": 1,
      "dotDiameter": 8
    },
    "areaChart": {
      "lineWidth": 0,
      "opacity": 0.8
    },
    "verticalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "horizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "groupedBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": 30
    },
    "progressChart": {
      "backgroundColor": "#f7f7f7",
      "thicknessOfProgress": 10,
      "endOfLine": 0
    },
    "sparkline": {
      "lineWidth": 1,
      "dotDiameter": 4
    },
    "scatterPlot": {
      "dotDiameter": 8
    },
    "candlestickChart": {
      "margin": 0.4,
      "unfilledNegativeBoxes": false
    },
    "histogram": {
      "margin": 2
    },
    "heatmap": {
      "margin": 0,
      "segments": 4
    }
  }];

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

  Settings.setGlobalSettingForKey('chartplugin.templates', JSON.stringify(template));
  return template;
} // apply new options in template

function renewTemplate(templates) {
  var newTemplate = {
    "name": "Default template",
    "id": 0,
    "colors": {
      "common": ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
      "progressChart": ["#e31a1c"],
      "sparkline": ["#343434"],
      "scatterPlot": ["#1f78b4"],
      "candlestickChart": ["#33a02c", "#e31a1c"],
      "heatmap": ["#a6cee3"]
    },
    "grid": {
      "type": 1,
      "lineWidth": 1,
      "color": "#F0F0F0"
    },
    "labels": {
      "type": 1,
      "fontName": "Roboto",
      "fontStyle": "Regular",
      "textCase": "ORIGINAL",
      "fontSize": 10,
      "lineHeight": 10,
      "letterSpacing": 0,
      "color": "#a3a3a3",
      "yAxisPosition": "left",
      "xAxisPosition": "bottom"
    },
    "beginAtZero": 0,
    "lineType": 0,
    "sorting": 0,
    "typeOfCircle": 0,
    "lineChart": {
      "lineWidth": 2,
      "dotType": 1,
      "dotDiameter": 8
    },
    "areaChart": {
      "lineWidth": 0,
      "opacity": 0.8
    },
    "verticalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "horizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0,
      "useOneColor": true
    },
    "groupedBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "groupedHorizontalBarChart": {
      "margin": 0.4,
      "roundTop": 0
    },
    "donutChart": {
      "thicknessOfDonut": 30
    },
    "progressChart": {
      "backgroundColor": "#f7f7f7",
      "thicknessOfProgress": 10,
      "endOfLine": 0
    },
    "sparkline": {
      "lineWidth": 1,
      "dotDiameter": 4
    },
    "scatterPlot": {
      "dotDiameter": 8
    },
    "candlestickChart": {
      "margin": 0.4,
      "unfilledNegativeBoxes": false
    },
    "histogram": {
      "margin": 2
    },
    "heatmap": {
      "margin": 0,
      "segments": 4
    }
  };

  if (templates.length === 0) {
    templates = [newTemplate];
  }

  templates.forEach(function (oldTemplate) {
    var newKeys = Object.keys(newTemplate);
    newKeys.forEach(function (key, i) {
      if (oldTemplate[key] === undefined) {
        oldTemplate[key] = newTemplate[key];
      }

      if (_typeof(newTemplate[key]) === 'object') {
        Object.keys(newTemplate[key]).forEach(function (secondKey) {
          if (oldTemplate[key] != undefined) {
            if (oldTemplate[key][secondKey] === undefined) {
              oldTemplate[key][secondKey] = newTemplate[key][secondKey];

              if (secondKey === 'lineHeight') {
                oldTemplate[key][secondKey] = oldTemplate.labels.fontSize;
              }
            }
          }
        });
      }
    });
  });

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

  Settings.setGlobalSettingForKey('chartplugin.templates', JSON.stringify(templates));
  return templates;
} // colorPalette index

function colorIndex(i, colorPalette) {
  var colorLength = colorPalette.length;

  if (i + 1 > colorLength) {
    var rest = (i + 1) % colorLength;

    if (rest == 0) {
      return colorLength - 1;
    } else {
      return rest - 1;
    }
  } else {
    return i;
  }
} // margins

function calculateMargins(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      realLabelsIndex = [],
      realLabelsX = [],
      minMaxArray = [data.niceMin, data.niceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // Y labels

  for (var i = 0; i < minMaxArray.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArray[i].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    yLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minW = 10 + Math.max.apply(Math, yLabelsWidth); // X labels

  for (var _i = 0; _i < data.header.length; _i++) {
    var _text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.header[_i].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    xLabelsWidth.push(_text.frame.width);

    _text.remove();
  }

  var minX = Math.max.apply(Math, xLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  }

  if (conf.labels.type === 1) {
    minW > xLabelsWidth[0] / 2 ? margins.left = minW : margins.left = Math.ceil(xLabelsWidth[0] / 2);
    margins.top = conf.labels.fontSize / 2;
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);

    if (chartType == "verticalBarChart" || chartType == "groupedBarChart") {
      margins.right = 0;
    }
  } else if (conf.labels.type === 2) {
    margins.left = minW;
    margins.top = conf.labels.fontSize / 2;
    margins.bottom = conf.labels.fontSize / 2;
  } else if (conf.labels.type === 3) {
    margins.left = Math.ceil(xLabelsWidth[0] / 2);
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);

    if (chartType == "verticalBarChart" || chartType == "groupedBarChart") {
      margins.left = 0;
      margins.right = 0;
    }
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;

  if (chartType === "candlestickChart") {
    initialStep = Math.floor(canvas.width / data.columns);
    counter = Math.ceil(minX / initialStep);
    numLabels = Math.ceil(data.columns / counter) - 1;
    step = initialStep * counter;
  } // workaround for first and last label case


  if (data.header != false) {
    data.header.forEach(function (header) {
      if (header === "") {
        counter = 1;
        numLabels = data.header.length - 1;
        step = canvas.width / (data.columns - 1);

        if (chartType === "candlestickChart") {
          step = initialStep;
        }
      }
    });
  } // positions of all labels


  for (var _i2 = 0; _i2 < numLabels + 1; _i2++) {
    var positionX = canvas.x + step * _i2;
    realLabelsIndex.push(_i2 * counter);
    realLabelsX.push(Math.floor(positionX) + xLabelsWidth[_i2 * counter]);
  }

  var actualWidth = canvas.width + canvas.x,
      lastLabelX = realLabelsX[realLabelsX.length - 1] - xLabelsWidth[realLabelsIndex[realLabelsIndex.length - 1]] / 2;

  if (actualWidth > lastLabelX) {
    canvas.width += margins.right;

    if (chartType === "candlestickChart") {
      initialStep = Math.floor(canvas.width / data.columns);
    } else {
      initialStep = canvas.width / (data.columns - 1);
    }

    step = initialStep * counter;
  }

  if (canvas.width % 2) {
    canvas.width = canvas.width - 1;
  }

  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter,
    initialStep: initialStep
  };
}
function calculateMarginsHorizontal(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      minMaxArray = [data.niceMin, data.niceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // X labels

  for (var i = 0; i < minMaxArray.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArray[i].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    yLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minX = Math.max.apply(Math, yLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  } // Y labels


  for (var _i3 = 0; _i3 < data.header.length; _i3++) {
    var _text2 = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.header[_i3].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    xLabelsWidth.push(_text2.frame.width);

    _text2.remove();
  }

  var minW = 10 + Math.max.apply(Math, xLabelsWidth);

  if (conf.labels.type === 1) {
    margins.left = minW;
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(yLabelsWidth[yLabelsWidth.length - 1] / 2);
  } else if (conf.labels.type === 2) {
    margins.left = Math.ceil(yLabelsWidth[0] / 2);
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(yLabelsWidth[yLabelsWidth.length - 1] / 2);
  } else if (conf.labels.type === 3) {
    margins.left = minW;
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;
  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter
  };
}
function calculateMarginsHistogram(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      realLabelsIndex = [],
      realLabelsX = [],
      minMaxArrayX = [data.xNiceMin, data.xNiceMax],
      minMaxArrayY = [data.yNiceMin, data.yNiceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // X labels

  for (var i = 0; i < minMaxArrayX.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArrayX[i].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    xLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minX = Math.max.apply(Math, xLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  } // Y labels


  for (var _i4 = 0; _i4 < minMaxArrayY.length; _i4++) {
    var _text3 = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: minMaxArrayY[_i4].toString() + data.symbol,
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    yLabelsWidth.push(_text3.frame.width);

    _text3.remove();
  }

  var minW = 10 + Math.max.apply(Math, yLabelsWidth);

  if (conf.labels.type === 1) {
    margins.top = conf.labels.fontSize / 2;
    margins.left = minW;
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);
  } else if (conf.labels.type === 2) {
    margins.left = minW;
    margins.top = conf.labels.fontSize / 2;
    margins.bottom = conf.labels.fontSize / 2;
  } else if (conf.labels.type === 3) {
    margins.left = Math.ceil(xLabelsWidth[0] / 2);
    margins.bottom = 10 + conf.labels.fontSize;
    margins.right = Math.ceil(xLabelsWidth[xLabelsWidth.length - 1] / 2);
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;
  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter
  };
}
function calculateMarginsHeatmap(canvas, data, conf, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var originalWidth = canvas.width,
      xLabelsWidth = [],
      yLabelsWidth = [],
      minMaxArray = [data.niceMin, data.niceMax],
      margins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }; // X labels

  for (var i = 0; i < data.horizontalHeaders.length; i++) {
    var text = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.horizontalHeaders[i].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    xLabelsWidth.push(text.frame.width);
    text.remove();
  }

  var minX = Math.max.apply(Math, xLabelsWidth) + 20;

  if (minX < 60) {
    minX = 60;
  } else if (minX > 100) {
    minX = 100;
  } // Y labels


  for (var _i5 = 0; _i5 < data.header.length; _i5++) {
    var _text4 = new Text({
      frame: new Rectangle(canvas.x, canvas.y, 100, conf.labels.lineHeight),
      text: data.header[_i5].toString(),
      style: {
        alignment: Text.Alignment.center,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });

    yLabelsWidth.push(_text4.frame.width);

    _text4.remove();
  }

  var minW = 10 + Math.max.apply(Math, yLabelsWidth);

  if (conf.labels.type === 1) {
    margins.left = minW;
    margins.bottom = 10 + conf.labels.fontSize;
  } else if (conf.labels.type === 2) {
    margins.bottom = 10 + conf.labels.fontSize;
  } else if (conf.labels.type === 3) {
    margins.left = minW;
  }

  canvas.x = canvas.x + margins.left;
  canvas.y = canvas.y + margins.top;
  canvas.width = canvas.width - margins.left - margins.right;
  canvas.height = canvas.height - margins.top - margins.bottom; // helpers

  var initialStep = canvas.width / (data.columns - 1),
      counter = Math.ceil(minX / initialStep),
      numLabels = Math.floor((data.columns - 1) / counter),
      step = initialStep * counter;
  return {
    minX: minX,
    minW: minW,
    numLabels: numLabels,
    step: step,
    counter: counter
  };
} // Helper SVG functions

function moveToPoint(x, y) {
  return "M " + Math.floor(x) + " " + Math.floor(y);
}
function lineToPoint(x, y) {
  return " L " + Math.floor(x) + " " + Math.floor(y);
}
function curveToPoint(points) {
  return " C " + Math.floor(points.c1x) + " " + Math.floor(points.c1y) + " " + Math.floor(points.c2x) + " " + Math.floor(points.c2y) + " " + Math.floor(points.x) + " " + Math.floor(points.y);
}
function path(canvas, data, conf, i, dir) {
  var x0 = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1),
      y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - data.niceMin);

  if (dir === "back") {
    x0 = canvas.x + canvas.width;
    y0 = zero - canvas.height / yAxe * (Number(data.table[i][data.columns - 1]) - data.niceMin);
  }

  var xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0),
      m = 0,
      dx1 = 0,
      dy1 = 0,
      dx2 = 0,
      dy2 = 0,
      preP = {
    x: x0,
    y: y0
  },
      nexP = {},
      f,
      t;

  function gradient(a, b) {
    return (b.y - a.y) / (b.x - a.x);
  }

  if (dir === "forward") {
    for (var j = 1; j < data.columns; j++) {
      if (conf.lineType === 0) {
        f = 0.5;
        t = 0;
      } else if (conf.lineType === 1) {
        f = 0;
        t = 0;
      } else {
        f = 0.3;
        t = 0.5;
      }

      xNext = xLast + xStep;
      y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
      var curP = {
        x: xNext,
        y: y
      };

      if (j == data.columns - 1) {
        dx2 = 0;
        dy2 = 0;
      } else {
        nexP = {
          x: xNext + xStep,
          y: zero - canvas.height / yAxe * (Number(data.table[i][j + 1]) - data.niceMin)
        };
        m = gradient(preP, nexP);
        dx2 = (nexP.x - curP.x) * -f;
        dy2 = dx2 * m * t;
      }

      var points = {
        x: curP.x,
        y: curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: curP.x + dx2,
        c2y: curP.y + dy2
      };
      pathData += curveToPoint(points);
      dx1 = dx2;
      dy1 = dy2;
      preP = curP;
      xLast = xNext;
      yLast = y;
    }
  } else {
    pathData = "";

    for (var _j = data.columns - 2; _j >= 0; _j--) {
      if (conf.lineType === 0) {
        f = 0.5;
        t = 0;
      } else if (conf.lineType === 1) {
        f = 0;
        t = 0;
      } else {
        f = 0.3;
        t = 0.5;
      }

      xNext = xLast - xStep;
      y = zero - canvas.height / yAxe * (Number(data.table[i][_j]) - data.niceMin);
      var _curP = {
        x: xNext,
        y: y
      };

      if (_j == 0) {
        dx2 = 0;
        dy2 = 0;
      } else {
        nexP = {
          x: xNext - xStep,
          y: zero - canvas.height / yAxe * (Number(data.table[i][_j - 1]) - data.niceMin)
        };
        m = gradient(preP, nexP);
        dx2 = (nexP.x - _curP.x) * -f;
        dy2 = dx2 * m * t;
      }

      var _points = {
        x: _curP.x,
        y: _curP.y,
        c1x: preP.x - dx1,
        c1y: preP.y - dy1,
        c2x: _curP.x + dx2,
        c2y: _curP.y + dy2
      };
      pathData += curveToPoint(_points);
      dx1 = dx2;
      dy1 = dy2;
      preP = _curP;
      xLast = xNext;
      yLast = y;
    }
  }

  return pathData;
}
function createOval(cx, cy, r) {
  var oval = "M " + cx + " " + cy + " m -" + r + ", 0 a " + r + "," + r + " 0 1,0 " + r * 2 + ",0 a " + r + "," + r + " 0 1,0 -" + r * 2 + ",0";
  return oval;
}
function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
  var angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return {
    x: centerX + radius * Math.cos(angleInRadians),
    y: centerY + radius * Math.sin(angleInRadians)
  };
} // GRIDS

function xAxisGrid(conf, canvas, data, group, chartType, marginsData) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var numLines = marginsData.numLabels,
      step = marginsData.step,
      counter = marginsData.counter,
      lineCounter;

  if (chartType === "candlestickChart") {
    var _path = moveToPoint(canvas.x, canvas.y) + lineToPoint(canvas.x, canvas.y + canvas.height),
        gridLine = ShapePath.fromSVGPath(_path);

    gridLine.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    gridLine.name = "Grid_v_0";
    group.push(gridLine);
  }

  for (var i = 0; i < numLines + 1; i++) {
    var positionX = canvas.x + step * i;

    if (chartType === "candlestickChart") {
      positionX = canvas.x + marginsData.initialStep / 2 + step * i;
    }

    var _path2 = moveToPoint(positionX, canvas.y) + lineToPoint(positionX, canvas.y + canvas.height),
        _gridLine = ShapePath.fromSVGPath(_path2);

    _gridLine.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    _gridLine.name = "Grid_v_" + (i + 1);
    group.push(_gridLine);
    lineCounter = i;
  }

  if (canvas.width > step * numLines) {
    var _path3 = moveToPoint(canvas.x + canvas.width, canvas.y) + lineToPoint(canvas.x + canvas.width, canvas.y + canvas.height),
        _gridLine2 = ShapePath.fromSVGPath(_path3);

    _gridLine2.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    _gridLine2.name = "Grid_v_" + (lineCounter + 1);
    group.push(_gridLine2);
  }
}
function xAxisDistrGrid(conf, canvas, data, group, dir) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  if (dir === "horizontal") {
    var xStep = canvas.width / data.columns,
        x0x = canvas.x,
        y0x = canvas.y,
        y1x = canvas.y + canvas.height;

    for (var i = 0; i < data.columns + 1; i++) {
      var _path4 = moveToPoint(x0x, y0x) + lineToPoint(x0x, y1x),
          gridLine = ShapePath.fromSVGPath(_path4);

      gridLine.style = {
        borders: [{
          color: conf.grid.color,
          thickness: conf.grid.lineWidth
        }]
      };
      gridLine.name = "Grid_v_" + (i + 1);
      group.push(gridLine);
      x0x = x0x + xStep;
    }
  } else {
    var yStep = canvas.height / data.columns,
        _y0x = canvas.y,
        _x0x = canvas.x,
        x1x = canvas.x + canvas.width;

    for (var _i6 = 0; _i6 < data.columns + 1; _i6++) {
      var _path5 = moveToPoint(_x0x, _y0x) + lineToPoint(x1x, _y0x),
          _gridLine3 = ShapePath.fromSVGPath(_path5);

      _gridLine3.style = {
        borders: [{
          color: conf.grid.color,
          thickness: conf.grid.lineWidth
        }]
      };
      _gridLine3.name = "Grid_v_" + (_i6 + 1);
      group.push(_gridLine3);
      _y0x = _y0x + yStep;
    }
  }
}
function yAxisGrid(conf, canvas, data, group, dir, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var minStepPx = 30,
      range = data.niceMax - data.niceMin,
      maxNumTicks = Math.floor(canvas.height / minStepPx),
      dividers = [0.1, 0.2, 0.5],
      axisNum = data.niceMin;

  if (chartType === "scatterPlot" && dir === "vertical" || chartType === "histogram" && dir === "vertical") {
    range = data.yNiceMax - data.yNiceMin;
    axisNum = data.yNiceMin;
  } else if (chartType === "scatterPlot" && dir === "horizontal" || chartType === "histogram" && dir === "horizontal") {
    range = data.xNiceMax - data.xNiceMin;
    axisNum = data.xNiceMin;
  }

  if (dir === "horizontal") {
    minStepPx = 40;
    maxNumTicks = Math.floor(canvas.width / minStepPx);
  }

  var step = dividers[0],
      numLines = Math.ceil(range / step),
      i = 0,
      count = 1;

  while (numLines >= maxNumTicks) {
    step = dividers[i] * count;
    numLines = Math.ceil(range / step);

    if (i === 2) {
      i = 0;
      count = count * 10;
    } else {
      i++;
    }
  }

  var textStep = step;
  step = canvas.height / numLines;

  if (dir === "horizontal") {
    step = canvas.width / numLines;
  }

  for (var _i7 = 0; _i7 < numLines + 1; _i7++) {
    var positionY = canvas.y + canvas.height - step * _i7,
        _path6 = moveToPoint(canvas.x, positionY) + lineToPoint(canvas.x + canvas.width, positionY);

    if (dir === "horizontal") {
      positionY = canvas.x + step * _i7;
      _path6 = moveToPoint(positionY, canvas.y) + lineToPoint(positionY, canvas.y + canvas.height);
    }

    var gridLine = ShapePath.fromSVGPath(_path6);
    gridLine.style = {
      borders: [{
        color: conf.grid.color,
        thickness: conf.grid.lineWidth
      }]
    };
    gridLine.name = "Grid_" + (_i7 + 1);
    group.push(gridLine);
  }
} // LABELS

function xAxisLabels(canvas, data, group, conf, marginsData, chartType) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var numLabels = marginsData.numLabels,
      step = marginsData.step,
      counter = marginsData.counter;

  for (var i = 0; i < numLabels + 1; i++) {
    var positionX = canvas.x + step * i;

    if (chartType === "candlestickChart") {
      positionX = canvas.x + marginsData.initialStep / 2 + step * i;
    }

    if (data.header != false && data.header[i] != "") {
      var text = new Text({
        frame: new Rectangle(Math.floor(positionX), Math.floor(canvas.y + canvas.height + 10), 50, conf.labels.lineHeight),
        text: data.header[i * counter].toString(),
        style: {
          alignment: Text.Alignment.center,
          fontSize: conf.labels.fontSize,
          fontFamily: conf.labels.fontName,
          fontWeight: conf.labels.fontStyle,
          kerning: conf.labels.letterSpacing,
          paragraphSpacing: 0,
          textTransform: conf.labels.textCase,
          lineHeight: conf.labels.lineHeight,
          textColor: conf.labels.color + 'ff',
          fills: [],
          borders: [{
            enabled: false
          }]
        }
      });
      group.push(text);
      text.frame.x = text.frame.x - text.frame.width / 2;
    }
  }
}
function xAxisDistrLabels(canvas, data, group, conf, dir, chartType, minW) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  if (dir === "horizontal") {
    var xStep = canvas.width / data.columns,
        x0x = canvas.x,
        numberColumns = data.columns;

    if (chartType === "heatmap") {
      var margin = conf.heatmap.margin;
      data.header = data.horizontalHeaders;
      numberColumns = data.rows;
      xStep = (canvas.width - margin * (numberColumns - 1)) / numberColumns;
      x0x = canvas.x;
    }

    for (var i = 0; i < numberColumns; i++) {
      if (data.header != false) {
        var text = new Text({
          fixedWidth: true,
          frame: new Rectangle(Math.floor(x0x), Math.floor(canvas.y + canvas.height + 10), xStep, conf.labels.lineHeight),
          text: data.header[i],
          style: {
            alignment: Text.Alignment.center,
            fontSize: conf.labels.fontSize,
            fontFamily: conf.labels.fontName,
            fontWeight: conf.labels.fontStyle,
            kerning: conf.labels.letterSpacing,
            paragraphSpacing: 0,
            textTransform: conf.labels.textCase,
            lineHeight: conf.labels.lineHeight,
            textColor: conf.labels.color + 'ff',
            fills: [],
            borders: [{
              enabled: false
            }]
          }
        });
        group.push(text);
      }

      x0x = x0x + xStep;

      if (chartType === "heatmap") {
        x0x += conf.heatmap.margin;
      }
    }
  } else {
    var yStep = canvas.height / data.columns,
        y0x = canvas.y + (yStep - 10) / 2;

    for (var _i8 = 0; _i8 < data.columns; _i8++) {
      if (data.header != false) {
        var _text5 = new Text({
          frame: new Rectangle(Math.floor(canvas.x - minW), Math.floor(y0x), 30, conf.labels.lineHeight),
          text: data.header[_i8],
          style: {
            alignment: Text.Alignment.right,
            fontSize: conf.labels.fontSize,
            fontFamily: conf.labels.fontName,
            fontWeight: conf.labels.fontStyle,
            kerning: conf.labels.letterSpacing,
            paragraphSpacing: 0,
            textTransform: conf.labels.textCase,
            lineHeight: conf.labels.lineHeight,
            textColor: conf.labels.color + 'ff',
            fills: [],
            borders: [{
              enabled: false
            }]
          }
        });

        group.push(_text5);
      }

      y0x = y0x + yStep;
    }
  }
}
function yAxisLabels(canvas, data, group, conf, dir, chartType, minW) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      Text = sketch.Text,
      Rectangle = sketch.Rectangle;

  var minStepPx = 30,
      range = data.niceMax - data.niceMin,
      maxNumTicks = Math.floor(canvas.height / minStepPx),
      dividers = [0.1, 0.2, 0.5],
      axisNum = data.niceMin;

  if (chartType === "scatterPlot" && dir === "vertical" || chartType === "histogram" && dir === "vertical") {
    range = data.yNiceMax - data.yNiceMin;
    axisNum = data.yNiceMin;
  } else if (chartType === "scatterPlot" && dir === "horizontal" || chartType === "histogram" && dir === "horizontal") {
    range = data.xNiceMax - data.xNiceMin;
    axisNum = data.xNiceMin;
  }

  if (dir === "horizontal") {
    minStepPx = 40;
    maxNumTicks = Math.floor(canvas.width / minStepPx);
  }

  var step = dividers[0],
      numLines = Math.ceil(range / step),
      i = 0,
      count = 1;

  while (numLines >= maxNumTicks) {
    step = dividers[i] * count;
    numLines = Math.ceil(range / step);

    if (i === 2) {
      i = 0;
      count = count * 10;
    } else {
      i++;
    }
  }

  var textStep = step;
  step = canvas.height / numLines;

  if (dir === "horizontal") {
    step = canvas.width / numLines;
  }

  for (var _i9 = 0; _i9 < numLines + 1; _i9++) {
    var textFrame = new Rectangle(Math.floor(canvas.x - minW), Math.floor(canvas.y + canvas.height - step * _i9 - conf.labels.lineHeight / 2), 50, conf.labels.lineHeight),
        textAlignment = Text.Alignment.right;

    if (dir === "horizontal") {
      textFrame = new Rectangle(Math.floor(canvas.x + step * _i9), Math.floor(canvas.y + canvas.height + conf.labels.lineHeight), 40, conf.labels.lineHeight);
      textAlignment = Text.Alignment.center;
    }

    var textValue = void 0;

    if (data.symbol === "%") {
      textValue = (Math.round(axisNum * 100) / 100).toString() + data.symbol;
    } else {
      textValue = data.symbol + (Math.round(axisNum * 100) / 100).toString();
    }

    var text = new Text({
      frame: textFrame,
      text: textValue,
      style: {
        alignment: textAlignment,
        fontSize: conf.labels.fontSize,
        fontFamily: conf.labels.fontName,
        fontWeight: conf.labels.fontStyle,
        kerning: conf.labels.letterSpacing,
        paragraphSpacing: 0,
        textTransform: conf.labels.textCase,
        lineHeight: conf.labels.lineHeight,
        textColor: conf.labels.color + 'ff',
        fills: [],
        borders: [{
          enabled: false
        }]
      }
    });
    group.push(text);

    if (dir == "vertical") {
      text.frame.width = minW - 10;
    }

    if (dir == "horizontal") {
      text.frame.x = text.frame.x - text.frame.width / 2;
    }

    axisNum = Math.round(axisNum * 100) / 100 + textStep;
  }
} // PROCESS DATA
// Create random data set

function createRandomData(rows, columns, min, max, distr, type) {
  var dataRow = new Array(),
      dataTable = new Array(),
      dataMax = new Array(),
      dataMin = new Array(),
      headers = [];

  function randNum(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var data = new Array();

    for (var i = 0; i < col; i++) {
      data[i] = Number(Math.random() * (max - min) + min).toFixed(0);
    }

    return data;
  }

  function trendUp(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
        data = new Array();

    for (var i = 0; i < col; i++) {
      var tempNum = min + step * (Math.random() * (1.3 - 0.5) + 0.5);
      min += tempNum - min;
      data[i] = tempNum.toFixed(0);
    }

    return data;
  }

  function trendDown(min, max, col) {
    min = Number(min);
    max = Number(max);
    col = Number(col);
    var step = (max - min) / col,
        data = new Array();

    for (var i = 0; i < col; i++) {
      var tempNum = max - step * (Math.random() * (1.3 - 0.5) + 0.5);
      max -= max - tempNum;
      data[i] = tempNum.toFixed(0);
    }

    return data;
  }

  function normalDistr(min, max, col) {
    max = Number(max);
    min = Number(min);
    col = Number(col - 1);
    var data = new Array(),
        originalMax = max;

    for (var i = 0; i <= col; i++) {
      max = max * Math.random();
      var c = min,
          b = 4 * (max - min) / col,
          a = -b / col;
      var tempNum = a * Math.pow(i, 2) + b * i + c;
      data[i] = tempNum.toFixed(0);
      max = originalMax;
    }

    return data;
  }

  var funcArr = [randNum, trendUp, trendDown, normalDistr];

  if (type == "candlestickChart") {
    var newRandom = function newRandom(min, max) {
      return Math.random() * (max - min) + min;
    };

    var range = max - min,
        minTrend = min + newRandom(range * 0.1, range * 0.3),
        maxTrend = max - newRandom(range * 0.1, range * 0.3),
        trendStep = (maxTrend - minTrend) / columns,
        startUp = minTrend,
        startDown = maxTrend,
        centerPoint,
        high,
        close,
        open,
        low,
        delta,
        highArr = new Array(),
        closeArr = new Array(),
        openArr = new Array(),
        lowArr = new Array();

    for (var j = 0; j < columns; j++) {
      if (distr == "1") {
        // Up
        centerPoint = Number(startUp) + trendStep * newRandom(0.7, 1.3);
        startUp = centerPoint;
      } else if (distr == "2") {
        // Down
        centerPoint = Number(startDown) - trendStep * newRandom(0.7, 1.3);
        startDown = centerPoint;
      } else {
        // Noise
        centerPoint = newRandom(range * 0.1, range * 0.9);
      }

      high = centerPoint * newRandom(1.1, 1.3);
      low = centerPoint * newRandom(0.7, 0.9);
      delta = high - low;
      close = newRandom(Number(low) + 0.2 * delta, Number(high) - 0.2 * delta);

      if (close < high - (high - low) / 2) {
        var openDelta = high - close;
        open = newRandom(Number(close) + 0.2 * openDelta, Number(high) - 0.2 * openDelta);
      } else {
        var openDelta = close - low;
        open = newRandom(Number(low) + 0.2 * openDelta, Number(close) - 0.2 * openDelta);
      }

      highArr[j] = high.toFixed(0);
      closeArr[j] = close.toFixed(0);
      openArr[j] = open.toFixed(0);
      lowArr[j] = low.toFixed(0);
    }

    dataTable[0] = highArr;
    dataTable[1] = closeArr;
    dataTable[2] = openArr;
    dataTable[3] = lowArr;
  } else {
    for (var i = 0; i < rows; i++) {
      if (distr == "0") {
        dataRow = randNum(min, max, columns);
      } else if (distr == "1") {
        dataRow = trendUp(min, max, columns);
      } else if (distr == "2") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = trendDown(min, max, columns);
        }
      } else if (distr == "3") {
        if (type == "scatterPlot" && i == 0) {
          dataRow = trendUp(min, max, columns);
        } else {
          dataRow = normalDistr(min, max, columns);
        }
      } else {
        var _randNum = Number(Math.random() * (funcArr.length - 1)).toFixed(0);

        dataRow = funcArr[_randNum](min, max, columns);
      }

      dataTable[i] = dataRow;
      dataMax[i] = Math.max.apply(Math, _toConsumableArray(dataRow));
      dataMin[i] = Math.min.apply(Math, _toConsumableArray(dataRow));
    }
  }

  for (var h = 0; h < columns; h++) {
    headers[h] = "Text";
  }

  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers,
    symbol: ""
  };
  return dataObj;
} // Create data set from real data

function processData(csv) {
  function transpose(a) {
    return Object.keys(a[0]).map(function (c) {
      return a.map(function (r) {
        return r[c];
      });
    });
  }

  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  function tableMin(N) {
    var min = new Array();

    for (var i in N) {
      min[i] = Math.min.apply(Math, _toConsumableArray(N[i]));
    }

    return Math.min.apply(Math, min);
  }

  function tableMax(N) {
    var max = new Array();

    for (var i in N) {
      max[i] = Math.max.apply(Math, _toConsumableArray(N[i]));
    }

    return Math.max.apply(Math, max);
  }

  function parseNumber(num) {
    var numText = num.toString(),
        commaIndex = numText.lastIndexOf(','),
        dotIndex = numText.lastIndexOf('.'),
        cleanNumber;
    symbol = numText.match(/[%$£€]/);

    if (symbol === null) {
      symbol = "";
    } else {
      symbol = symbol[0];
    }

    if (commaIndex >= 0 && commaIndex > dotIndex) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    } else if (dotIndex >= 0 && dotIndex > commaIndex) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (commaIndex < 0) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (dotIndex < 0) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    }

    return cleanNumber;
  }

  var dataObj, symbol;

  if (csv.type === null) {
    var col = csv.data[0].length,
        row = csv.data.length,
        newData = csv.data,
        header;

    if (csv.headers == true) {
      header = newData[0];
      newData.splice(0, 1);

      for (var i = 0; i < row - 1; i++) {
        for (var j = 0; j < col; j++) {
          newData[i][j] = parseFloat(parseNumber(newData[i][j]));
        }
      }

      row = row - 1;
    } else {
      header = false;

      for (var _i10 = 0; _i10 < row; _i10++) {
        for (var _j2 = 0; _j2 < col; _j2++) {
          newData[_i10][_j2] = parseFloat(parseNumber(newData[_i10][_j2]));
        }
      }
    }

    dataObj = {
      table: newData,
      rows: row,
      columns: col,
      min: tableMin(newData),
      max: tableMax(newData),
      header: header,
      symbol: symbol
    };
  } else {
    var _newData = new Array(),
        selectedRows = new Array(),
        headerIndex,
        transposedTable = transpose(csv.data);

    csv.columns.forEach(function (column) {
      if (column.checked) {
        selectedRows.push(column.index);
      }
    });
    selectedRows.forEach(function (row) {
      _newData.push(transposedTable[row]);
    });

    for (var _i11 = 0; _i11 < _newData.length; _i11++) {
      for (var _j3 = 0; _j3 < _newData[0].length; _j3++) {
        _newData[_i11][_j3] = parseFloat(parseNumber(_newData[_i11][_j3]));
      }
    }

    csv.header.forEach(function (header) {
      if (header.checked) {
        headerIndex = header.index;
      }
    });
    dataObj = {
      table: _newData,
      rows: _newData.length,
      columns: _newData[0].length,
      min: tableMin(_newData),
      max: tableMax(_newData),
      header: transposedTable[headerIndex],
      symbol: symbol
    };
  }

  return dataObj;
} // Create data set from JSON

function processJSON(JSON, rawKeys, rawHeader) {
  var keys = new Array(),
      headerKey = "",
      dataTable = new Array(),
      dataMax = new Array(),
      dataMin = new Array();

  function getValues(obj, key) {
    var objects = [];

    for (var i in obj) {
      if (!obj.hasOwnProperty(i)) continue;

      if (_typeof(obj[i]) == 'object') {
        objects = objects.concat(getValues(obj[i], key));
      } else if (i == key) {
        objects.push(obj[i]);
      }
    }

    return objects;
  }

  function parseNumber(num) {
    var numText = num.toString(),
        commaIndex = numText.lastIndexOf(','),
        dotIndex = numText.lastIndexOf('.'),
        cleanNumber;
    symbol = numText.match(/[%$£€]/);

    if (symbol === null) {
      symbol = "";
    } else {
      symbol = symbol[0];
    }

    if (commaIndex >= 0 && commaIndex > dotIndex) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    } else if (dotIndex >= 0 && dotIndex > commaIndex) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (commaIndex < 0) {
      cleanNumber = numText.replace(/[^\d.-]/g, '');
    } else if (dotIndex < 0) {
      cleanNumber = numText.replace(/[^\d,-]/g, '').replace(/[,]/g, '.');
    }

    return cleanNumber;
  }

  rawKeys.forEach(function (key) {
    if (key.checked == true) {
      keys.push(key.name);
    }
  });
  rawHeader.forEach(function (header) {
    if (header.checked == true) {
      headerKey = header.name;
    }
  });
  var headers = getValues(JSON, headerKey),
      symbol;

  for (var i in keys) {
    var row = getValues(JSON, keys[i]);

    for (var j in row) {
      row[j] = parseFloat(parseNumber(row[j]));
    }

    dataTable[i] = row;
    dataMax[i] = Math.max.apply(Math, _toConsumableArray(dataTable[i]));
    dataMin[i] = Math.min.apply(Math, _toConsumableArray(dataTable[i]));
  }

  var dataObj = {
    table: dataTable,
    max: Math.max.apply(Math, dataMax),
    min: Math.min.apply(Math, dataMin),
    rows: dataTable.length,
    columns: dataTable[0].length,
    header: headers,
    symbol: symbol
  };
  return dataObj;
} // CHARTS
// Line chart

function createDots(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style,
      Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

  var x = canvas.x,
      y = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1),
      radius = conf.lineChart.dotDiameter;

  for (var j = 0; j < data.columns; j++) {
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var dot = new ShapePath({
      name: "Dot_" + (i + 1) + (j + 1),
      shapeType: ShapePath.ShapeType.Oval,
      frame: new Rectangle(Math.floor(x) - radius / 2, Math.floor(y) - radius / 2, radius, radius)
    });

    if (conf.lineChart.dotType == 1) {
      dot.style = {
        fills: [conf.colors.common[colorIndex(i, conf.colors.common)]],
        borders: [{
          enabled: false
        }]
      };
    } else {
      dot.style = {
        fills: ["#fff"],
        borders: [{
          color: conf.colors.common[colorIndex(i, conf.colors.common)],
          thickness: conf.lineChart.lineWidth,
          position: Style.BorderPosition.Inside
        }]
      };
    }

    group.push(dot);
    x = x + xStep;
  }
}
function createLineChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var pathData = path(canvas, data, conf, i, "forward");
  var line = ShapePath.fromSVGPath(pathData);
  line.style = {
    borders: [{
      color: conf.colors.common[colorIndex(i, conf.colors.common)],
      thickness: conf.lineChart.lineWidth
    }]
  };
  line.name = "Line_" + (i + 1);
  group.push(line); // Dots

  if (conf.lineChart.dotType != 0) {
    createDots(canvas, conf, data, i, group);
  }
} // Area chart

function createAreaChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var pathData = path(canvas, data, conf, i, "forward"),
      zero;

  if (data.niceMin < 0) {
    zero = canvas.y + canvas.height * data.niceMax / (data.niceMax - data.niceMin);
  } else {
    zero = canvas.y + canvas.height;
  }

  pathData += lineToPoint(canvas.x + canvas.width, zero);
  pathData += lineToPoint(canvas.x, zero);
  pathData += " Z";
  var area = ShapePath.fromSVGPath(pathData);
  area.style = {
    fills: [conf.colors.common[colorIndex(i, conf.colors.common)]],
    borders: [{
      enabled: false
    }],
    opacity: conf.areaChart.opacity
  };
  area.name = "Area_" + (i + 1);
  group.push(area);

  if (conf.areaChart.lineWidth > 0) {
    var topLine = path(canvas, data, conf, i, "forward");
    var line = ShapePath.fromSVGPath(topLine);
    line.style = {
      borders: [{
        color: conf.colors.common[colorIndex(i, conf.colors.common)],
        thickness: conf.areaChart.lineWidth
      }]
    };
    line.name = "Line";
    group.push(line);
  }
} // Stacked area chart

function createStackedAreaChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var pathData = path(canvas, data, conf, i, "forward"),
      zero;

  if (data.niceMax < 0) {
    zero = canvas.y;
  } else {
    zero = canvas.y + canvas.height;
  }

  var yAxe = data.niceMax - data.niceMin,
      yEnd = zero - canvas.height / yAxe * (Number(data.table[i - 1][data.columns - 1]) - data.niceMin);
  pathData += lineToPoint(canvas.x + canvas.width, yEnd);
  pathData += path(canvas, data, conf, i - 1, "back");
  pathData += " Z";
  var area = ShapePath.fromSVGPath(pathData);
  area.style = {
    fills: [conf.colors.common[colorIndex(i - 1, conf.colors.common)]],
    borders: [{
      enabled: false
    }]
  };
  area.name = "Area_" + (i + 1);
  group.push(area);
} // Histogram

function createHistogram(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.table[1].length,
      margin = conf.histogram.margin,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.yNiceMax - data.yNiceMin,
      zero = canvas.y + canvas.height,
      barArray = new Array();

  for (var j = 0; j < data.table[1].length; j++) {
    x0 = x0 + xStep * n;
    x1 = x0 + xStep - 2 * margin;
    y0 = zero;
    y1 = zero - canvas.height / yAxe * (Number(data.table[1][j]) - data.yNiceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors.common[0]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + (j + 1);
    group.push(bar);
    n = n + 1;
    x0 = canvas.x + margin;
  }

  return barArray;
} // Vertical bar chart

function createVerticalBarChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.columns,
      margin = conf.verticalBarChart.margin / 2 * xStep,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height;

  for (var j = 0; j < data.columns; j++) {
    x0 = x0 + xStep * n;
    x1 = x0 + xStep - 2 * margin;
    y0 = zero - canvas.height / yAxe * (Number(data.table[i - 1][j]) - data.niceMin);
    y1 = zero - canvas.height / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors.common[colorIndex(i - 1, conf.colors.common)]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + i + "_" + (j + 1);

    if (i === data.rows - 1 && bar.frame.height > conf.verticalBarChart.roundTop * 2 && bar.frame.height > 4) {
      bar.points[1].cornerRadius = conf.verticalBarChart.roundTop;
      bar.points[2].cornerRadius = conf.verticalBarChart.roundTop;
    }

    group.push(bar);
    n = n + 1;
    x0 = canvas.x + margin;
  }
} // Horizontal bar chart

function createHorizontalBarChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.height / data.columns,
      margin = conf.horizontalBarChart.margin / 2 * xStep,
      y0 = canvas.y + margin,
      x1,
      x0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.x;

  for (var j = 0; j < data.columns; j++) {
    y0 = y0 + xStep * n;
    y1 = y0 + xStep - 2 * margin;
    x0 = zero + canvas.width / yAxe * (Number(data.table[i - 1][j]) - data.niceMin);
    x1 = zero + canvas.width / yAxe * (Number(data.table[i][j]) - data.niceMin);
    var pathData = moveToPoint(x0, y0);
    pathData += lineToPoint(x0, y1);
    pathData += lineToPoint(x1, y1);
    pathData += lineToPoint(x1, y0);
    pathData += " Z";
    var bar = ShapePath.fromSVGPath(pathData);
    bar.style = {
      fills: [conf.colors.common[colorIndex(i - 1, conf.colors.common)]],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Bar_" + i + "_" + (j + 1);

    if (i === data.rows - 1 && bar.frame.width > conf.horizontalBarChart.roundTop * 2 && bar.frame.width > 4) {
      bar.points[2].cornerRadius = conf.horizontalBarChart.roundTop;
      bar.points[3].cornerRadius = conf.horizontalBarChart.roundTop;
    }

    group.push(bar);
    n = n + 1;
    y0 = canvas.y + margin;
  }
} // Grouped bar chart

function createGroupBarChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.width / data.columns,
      margin = xStep * Number(conf.groupedBarChart.margin) / 2,
      barWidth = xStep * (1 - Number(conf.groupedBarChart.margin)) / data.rows,
      x0 = canvas.x + margin,
      x1,
      y0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + Math.abs(data.niceMax) / yAxe * canvas.height;

  for (var j = 0; j < data.columns; j++) {
    for (var _n = 0; _n < data.rows; _n++) {
      x1 = x0 + barWidth;
      y0 = zero;
      y1 = zero - canvas.height / yAxe * Number(data.table[_n][j]);
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [conf.colors.common[colorIndex(_n, conf.colors.common)]],
        borders: [{
          enabled: false
        }]
      };
      bar.name = "Bar_" + (_n + 1) + "_" + (j + 1);

      if (bar.frame.height > conf.groupedBarChart.roundTop * 2 && bar.frame.height > 4) {
        bar.points[1].cornerRadius = conf.groupedBarChart.roundTop;
        bar.points[2].cornerRadius = conf.groupedBarChart.roundTop;
      }

      group.push(bar);
      x0 = x0 + barWidth;
    }

    x0 = x0 + margin * 2;
  }
} // Grouped horizontal bar chart

function createGroupHorizontalBarChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var xStep = canvas.height / data.columns,
      margin = xStep * Number(conf.groupedHorizontalBarChart.margin) / 2,
      barWidth = xStep * (1 - Number(conf.groupedHorizontalBarChart.margin)) / data.rows,
      y0 = canvas.y + margin,
      x1,
      x0,
      y1,
      y = 0,
      n = 0,
      yAxe = data.niceMax - data.niceMin,
      zero = canvas.x + Math.abs(data.niceMin) / yAxe * canvas.width;

  for (var j = 0; j < data.columns; j++) {
    for (var _n2 = 0; _n2 < data.rows; _n2++) {
      x1 = zero + canvas.width / yAxe * Number(data.table[_n2][j]);
      x0 = zero;
      y1 = y0 + barWidth;
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [conf.colors.common[colorIndex(_n2, conf.colors.common)]],
        borders: [{
          enabled: false
        }]
      };
      bar.name = "Bar_" + (_n2 + 1) + "_" + (j + 1);

      if (bar.frame.width > conf.groupedHorizontalBarChart.roundTop * 2 && bar.frame.width > 4) {
        bar.points[2].cornerRadius = conf.groupedHorizontalBarChart.roundTop;
        bar.points[3].cornerRadius = conf.groupedHorizontalBarChart.roundTop;
      }

      group.push(bar);
      y0 = y0 + barWidth;
    }

    y0 = y0 + margin * 2;
  }
} // Pie chart

function createPieChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var radius = canvas.width / 2,
      xCenter = canvas.x + radius,
      yCenter = canvas.y + radius,
      pathData,
      sum = data.table[i].reduce(function (partial_sum, a) {
    return Number(partial_sum) + Number(a);
  }),
      startAngle,
      endAngle,
      multi;

  if (sum == 100) {
    multi = 3.6;
  } else {
    multi = 360 / sum;
  }

  if (conf.sorting == 0) {
    var compareNumeric = function compareNumeric(a, b) {
      return b - a;
    };

    var sortedItems = data.table[i];
    sortedItems.sort(compareNumeric);
    data.table[i] = sortedItems;
  }

  if (conf.typeOfCircle == 0) {
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
  } else {
    multi = multi / 2;
    startAngle = -90;
    endAngle = Number(data.table[i][0]) * multi - 90;
  }

  for (var j = 0; j < data.columns; j++) {
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y, "L", xCenter, yCenter, "L", start.x, start.y].join(" ");
    var pie = ShapePath.fromSVGPath(pathData);
    pie.style = {
      fills: [conf.colors.common[colorIndex(j, conf.colors.common)]],
      borders: [{
        enabled: false
      }]
    };
    pie.name = "Pie_" + j;
    group.push(pie);
    startAngle = startAngle + Number(data.table[i][j]) * multi;
    endAngle = endAngle + Number(data.table[i][j + 1]) * multi;
  }
} // Donut chart

function createDonutChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

  if (conf.donutChart.thicknessOfDonut > canvas.width / 2) {
    conf.donutChart.thicknessOfDonut = canvas.width / 4;
  }

  var radius = canvas.width / 2 - conf.donutChart.thicknessOfDonut / 2,
      xCenter = canvas.x + radius + conf.donutChart.thicknessOfDonut / 2,
      yCenter = canvas.y + radius + conf.donutChart.thicknessOfDonut / 2,
      pathData,
      sum = data.table[i].reduce(function (partial_sum, a) {
    return Number(partial_sum) + Number(a);
  }),
      startAngle,
      endAngle,
      multi;

  if (sum == 100) {
    multi = 3.6;
  } else {
    multi = 360 / sum;
  }

  if (conf.sorting == 0) {
    var compareNumeric = function compareNumeric(a, b) {
      return b - a;
    };

    var sortedItems = data.table[i];
    sortedItems.sort(compareNumeric);
    data.table[i] = sortedItems;
  }

  if (conf.typeOfCircle == 0) {
    startAngle = 0;
    endAngle = data.table[i][0] * multi;
  } else {
    multi = multi / 2;
    startAngle = -90;
    endAngle = Number(data.table[i][0]) * multi - 90;
  }

  for (var j = 0; j < data.columns; j++) {
    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y].join(" ");
    var donut = ShapePath.fromSVGPath(pathData);
    donut.style = {
      borders: [{
        color: conf.colors.common[colorIndex(j, conf.colors.common)],
        thickness: conf.donutChart.thicknessOfDonut
      }],
      borderOptions: {
        lineEnd: Style.LineEnd.Butt
      }
    };
    donut.name = "Donut_" + j;
    group.push(donut);
    startAngle = startAngle + Number(data.table[i][j]) * multi;
    endAngle = endAngle + Number(data.table[i][j + 1]) * multi;
  }
} // Progress chart

function createProgressChart(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

  var progress, pathData;

  var bgColor,
      bgColorType = _typeof(conf.progressChart.backgroundColor),
      bgLayer;

  if (bgColorType === 'object') {
    bgColor = conf.progressChart.backgroundColor[0];
  } else {
    bgColor = conf.progressChart.backgroundColor;
  }

  if (canvas.layerType == "Oval") {
    var radius = canvas.width / 2 - conf.progressChart.thicknessOfProgress / 2,
        xCenter = canvas.x + radius + conf.progressChart.thicknessOfProgress / 2,
        yCenter = canvas.y + radius + conf.progressChart.thicknessOfProgress / 2,
        startAngle,
        endAngle,
        multi = 3.6;

    if (conf.typeOfCircle == 0) {
      startAngle = 0;
      endAngle = data.table[i][0] * multi;
    } else {
      multi = multi / 2;
      startAngle = -90;
      endAngle = Number(data.table[i][0]) * multi - 90;
    }

    var start = polarToCartesian(xCenter, yCenter, radius, endAngle),
        end = polarToCartesian(xCenter, yCenter, radius, startAngle),
        arcSweep = endAngle - startAngle <= 180 ? "0" : "1";
    pathData = ["M", start.x, start.y, "A", radius, radius, 0, arcSweep, 0, end.x, end.y].join(" ");
    progress = ShapePath.fromSVGPath(pathData);
    progress.style = {
      borders: [{
        color: conf.colors.progressChart[0],
        thickness: conf.progressChart.thicknessOfProgress
      }]
    };

    if (conf.typeOfCircle == 0) {
      canvas.layer.style = {
        borders: [{
          color: bgColor,
          thickness: conf.progressChart.thicknessOfProgress,
          position: Style.BorderPosition.Inside
        }]
      };
    } else {
      startAngle = -90;
      endAngle = 90;

      var _start = polarToCartesian(xCenter, yCenter, radius, endAngle),
          _end = polarToCartesian(xCenter, yCenter, radius, startAngle),
          _arcSweep = endAngle - startAngle <= 180 ? "0" : "1";

      pathData = ["M", _start.x, _start.y, "A", radius, radius, 0, _arcSweep, 0, _end.x, _end.y].join(" ");
      bgLayer = ShapePath.fromSVGPath(pathData);
      bgLayer.style = {
        borders: [{
          color: bgColor,
          thickness: conf.progressChart.thicknessOfProgress
        }]
      };
      bgLayer.name = "Background";
      group.push(bgLayer);
      canvas.layer.style = {
        borders: [{
          enabled: false
        }]
      };
    }
  } else {
    var xStart = canvas.x,
        xEnd = canvas.x + canvas.width / 100 * data.table[i][0],
        y = canvas.y + canvas.height / 2;

    if (conf.progressChart.endOfLine == 1) {
      xStart = xStart + canvas.height / 2;
    }

    pathData = ["M", xStart, y, "L", xEnd, y].join(" ");
    progress = ShapePath.fromSVGPath(pathData);
    progress.style = {
      borders: [{
        color: conf.colors.progressChart[0],
        thickness: canvas.height
      }]
    };
    canvas.layer.style = {
      fills: [{
        color: bgColor,
        fillType: Style.FillType.Color
      }],
      borders: [{
        enabled: false
      }]
    };
  }

  if (conf.progressChart.endOfLine == 0) {
    progress.style.borderOptions.lineEnd = Style.LineEnd.Butt;
  } else {
    progress.style.borderOptions.lineEnd = Style.LineEnd.Round;
    canvas.layer.points.forEach(function (point) {
      point.cornerRadius = canvas.height / 2;
    });
  }

  progress.name = "Progress bar";
  group.push(progress);
} // Sparkline

function createSparkline(canvas, conf, data, max, min, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

  var x0 = canvas.x,
      y = 0,
      yAxe = max - min,
      zero = canvas.y + canvas.height,
      xStep = canvas.width / (data.columns - 1);
  var y0 = zero - canvas.height / yAxe * (Number(data.table[i][0]) - min),
      xLast = x0,
      yLast = y0,
      xNext = 0,
      pathData = moveToPoint(x0, y0);

  for (var j = 1; j < data.columns; j++) {
    xNext = xLast + xStep;
    y = zero - canvas.height / yAxe * (Number(data.table[i][j]) - min);
    pathData += lineToPoint(xNext, y);
    xLast = xNext;
    yLast = y;
  }

  var line = ShapePath.fromSVGPath(pathData);
  line.style = {
    borders: [{
      color: conf.colors.sparkline[0],
      thickness: conf.sparkline.lineWidth
    }]
  };
  line.name = "Sparkline";
  group.push(line);
  var dot = new ShapePath({
    name: "Dot",
    shapeType: ShapePath.ShapeType.Oval,
    frame: new Rectangle(Math.round(xLast - conf.sparkline.dotDiameter / 2), Math.round(yLast - conf.sparkline.dotDiameter / 2), conf.sparkline.dotDiameter, conf.sparkline.dotDiameter)
  });
  dot.style = {
    fills: [conf.colors.sparkline[0]],
    borders: [{
      enabled: false
    }]
  };
  group.push(dot);
} // Scatter plot

function createScatterPlot(canvas, conf, data, i, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

  var x = 0,
      y = 0,
      yAxe = data.yNiceMax - data.yNiceMin,
      xAxe = data.xNiceMax - data.xNiceMin,
      yZero = canvas.y + canvas.height,
      xZero = canvas.x,
      radius = conf.scatterPlot.dotDiameter;

  if (data.rows > 2) {
    var maxRad = conf.scatterPlot.dotDiameter;
    var valMax = Math.max.apply(Math, _toConsumableArray(data.table[2]));
    radius = Math.ceil(maxRad * data.table[2][i] / valMax);
  }

  x = xZero + canvas.width / xAxe * (Number(data.table[0][i]) - data.xNiceMin);
  y = yZero - canvas.height / yAxe * (Number(data.table[1][i]) - data.yNiceMin);
  var dot = new ShapePath({
    name: "Dot_" + (i + 1),
    shapeType: ShapePath.ShapeType.Oval,
    frame: new Rectangle(Math.round(x - radius / 2), Math.round(y - radius / 2), radius, radius)
  });
  dot.style = {
    fills: [conf.colors.scatterPlot[0]],
    borders: [{
      enabled: false
    }]
  };
  group.push(dot);
} // Candlestick chart

function createCandlestickChart(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  var yAxe = data.niceMax - data.niceMin,
      zero = canvas.y + canvas.height,
      step = Math.floor(canvas.width / data.columns),
      margin = (1 - Number(conf.candlestickChart.margin)) / 2 * step,
      xBar = step - 2 * margin,
      x0 = canvas.x + margin,
      y0 = 0,
      x1 = 0,
      y1 = 0,
      x0line = canvas.x + step / 2,
      y0line = 0,
      y1line = 0,
      n = 0,
      candleColor;

  for (var z = 0; z < data.columns; z++) {
    x0line = x0line + step * n;
    x0 = x0line - Math.floor(xBar / 2);
    x1 = x0line + Math.floor(xBar / 2);

    if (data.table[1][z] > data.table[2][z]) {
      y0 = zero - canvas.height / yAxe * (Number(data.table[2][z]) - data.niceMin);
      y1 = zero - canvas.height / yAxe * (Number(data.table[1][z]) - data.niceMin);
      y0line = zero - canvas.height / yAxe * (Number(data.table[3][z]) - data.niceMin);
      y1line = zero - canvas.height / yAxe * (Number(data.table[0][z]) - data.niceMin);
      candleColor = conf.colors.candlestickChart[0];
    } else {
      y0 = zero - canvas.height / yAxe * (Number(data.table[1][z]) - data.niceMin);
      y1 = zero - canvas.height / yAxe * (Number(data.table[2][z]) - data.niceMin);
      y0line = zero - canvas.height / yAxe * (Number(data.table[3][z]) - data.niceMin);
      y1line = zero - canvas.height / yAxe * (Number(data.table[0][z]) - data.niceMin);
      candleColor = conf.colors.candlestickChart[1];
    }

    var lineData = moveToPoint(x0line, y0line);
    lineData += lineToPoint(x0line, y1line);
    var line = ShapePath.fromSVGPath(lineData);
    line.style = {
      borders: [{
        color: candleColor,
        thickness: 1
      }]
    };
    line.name = "Line";
    group.push(line);
    var barData = moveToPoint(x0, y0);
    barData += lineToPoint(x0, y1);
    barData += lineToPoint(x1, y1);
    barData += lineToPoint(x1, y0);
    barData += " Z";
    var bar = ShapePath.fromSVGPath(barData);
    bar.style = {
      fills: [candleColor],
      borders: [{
        enabled: false
      }]
    };
    bar.name = "Candle";
    group.push(bar);
    n = 1;
  }
} // Heatmap

function createHeatmap(canvas, conf, data, group) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath;

  function isInteger(num) {
    return (num ^ 0) === num;
  }

  var division = conf.heatmap.segments,
      margin = conf.heatmap.margin,
      xStep = (canvas.width - margin * (data.rows - 1)) / data.rows,
      yStep = (canvas.height - margin * (data.columns - 1)) / data.columns,
      x0 = canvas.x,
      y0 = canvas.y,
      x1,
      y1,
      barArray = new Array();
  var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, false);
  data.niceMax = niceScales.niceMaximum;
  data.niceMin = niceScales.niceMinimum;

  if (data.niceMin > 0) {
    data.niceMin = 0;
  }

  var opacityStep = 1 / division;

  for (var i = 0; i < data.rows; i++) {
    for (var j = 0; j < data.columns; j++) {
      x1 = x0 + xStep;
      y1 = y0 + yStep;
      var pathData = moveToPoint(x0, y0);
      pathData += lineToPoint(x0, y1);
      pathData += lineToPoint(x1, y1);
      pathData += lineToPoint(x1, y0);
      pathData += " Z";
      var rangeStep = void 0,
          opacity = void 0,
          textRangeMax = void 0,
          textRangeMin = void 0,
          color = void 0;

      if (data.table[i][j] >= 0) {
        rangeStep = data.niceMax / division;
        color = conf.colors.heatmap[0];

        if (isInteger(data.table[i][j] / rangeStep)) {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep + 1);
          textRangeMin = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          textRangeMax = (Math.ceil(data.table[i][j] / rangeStep) + 1) * rangeStep;

          if (Number(data.table[i][j]) === data.niceMax) {
            opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
            textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
            textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          }
        } else {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
          textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
          textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
        }
      } else {
        rangeStep = data.niceMin / division;

        if (conf.colors.heatmap.length > 1) {
          color = conf.colors.heatmap[1];
        } else {
          color = conf.colors.heatmap[0];
        }

        if (isInteger(data.table[i][j] / rangeStep)) {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep + 1);
          textRangeMin = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          textRangeMax = (Math.ceil(data.table[i][j] / rangeStep) + 1) * rangeStep;

          if (Number(data.table[i][j]) === data.niceMin) {
            opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
            textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
            textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
          }
        } else {
          opacity = opacityStep * Math.ceil(data.table[i][j] / rangeStep);
          textRangeMin = (Math.ceil(data.table[i][j] / rangeStep) - 1) * rangeStep;
          textRangeMax = Math.ceil(data.table[i][j] / rangeStep) * rangeStep;
        }
      }

      var bar = ShapePath.fromSVGPath(pathData);
      bar.style = {
        fills: [color],
        borders: [{
          enabled: false
        }],
        opacity: opacity
      };
      bar.name = "Value: " + data.table[i][j] + ", range: " + textRangeMin + "—" + textRangeMax;
      group.push(bar);
      y0 += yStep + margin;
    }

    y0 = canvas.y;
    x0 += xStep + margin;
  }

  return barArray;
} // CREATE CHART

function createChart(canvas, configuration) {
  function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
  }

  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      Group = __webpack_require__(/*! sketch/dom */ "sketch/dom").Group,
      sketch = __webpack_require__(/*! sketch */ "sketch"),
      doc = sketch.getSelectedDocument();

  var data,
      dataFromPopup = configuration,
      conf = dataFromPopup.settings,
      strConfig = JSON.stringify(configuration),
      editableConfig = JSON.stringify(configuration),
      chartType = dataFromPopup.data.chartName,
      email = Settings.globalSettingForKey('user_email'); // CONVERT FONT SETTINGS

  if (conf.labels.textCase === "ORIGINAL" || conf.labels.textCase === "TITLE") {
    conf.labels.textCase = "none";
  } else if (conf.labels.textCase === "UPPER") {
    conf.labels.textCase = "uppercase";
  } else {
    conf.labels.textCase = "lowercase";
  }

  if (conf.labels.fontStyle.toLowerCase().indexOf("bold") >= 0) {
    conf.labels.fontStyle = 9;
  } else if (conf.labels.fontStyle.toLowerCase().indexOf("semibold") >= 0) {
    conf.labels.fontStyle = 8;
  } else if (conf.labels.fontStyle.toLowerCase().indexOf("light") >= 0) {
    conf.labels.fontStyle = 3;
  } else if (conf.labels.fontStyle.toLowerCase().indexOf("thin") >= 0) {
    conf.labels.fontStyle = 2;
  } else {
    conf.labels.fontStyle = 5;
  } // COLLECT STATS


  var appVersion = context.plugin.version(),
      userId = Settings.globalSettingForKey('userId'),
      accountType = Settings.globalSettingForKey('user_type');
  collectStats(userId, email, appVersion, chartType, accountType);
  canvas.forEach(function (canvas, index) {
    var _chartGroup$layers;

    var parent = doc.getLayerWithID(canvas.parent),
        layer = doc.getLayerWithID(canvas.layer),
        numParam = conf.labels.type != 0 ? canvas.height : false,
        numWidthParam = conf.labels.type != 0 ? canvas.width : false;
    canvas.parent = parent;
    canvas.layer = layer;
    layer.selected = false; // UNGROUP LAYERS

    if (canvas.conf != undefined) {
      var _parent = canvas.parent,
          group = canvas.layer,
          newX = canvas.layer.frame.x,
          newY = canvas.layer.frame.y,
          oldCanvas = canvas.layer.layers[0];
      var yMin = null,
          yMax = null,
          xMin = null,
          xMax = null;
      var axesNums = canvas.layer.name.match(/\[(.*?)]/g);
      var axesRange = [];

      if (axesNums != null) {
        var axes = axesNums[0].replace(/\[(.*?)\]/g, "$1").split(";");
        axes.forEach(function (num) {
          var splitedAxe = num.split("-");

          if (splitedAxe.length > 1) {
            axesRange.push(splitedAxe);
          }
        });
      }

      if (axesRange.length > 0) {
        yMin = axesRange[0][0];
        yMax = axesRange[0][1];

        if (axesRange.length > 1) {
          xMin = axesRange[1][0];
          xMax = axesRange[1][1];
        }
      }

      _parent.layers.push(oldCanvas);

      oldCanvas.frame.x = newX + oldCanvas.frame.x;
      oldCanvas.frame.y = newY + oldCanvas.frame.y;
      group.remove();
      canvas = {
        layer: oldCanvas,
        height: oldCanvas.frame.height,
        width: oldCanvas.frame.width,
        x: oldCanvas.frame.x,
        y: oldCanvas.frame.y,
        layerType: oldCanvas.shapeType,
        startNum: "false",
        yMin: yMin,
        yMax: yMax,
        xMin: xMin,
        xMax: xMax,
        parent: oldCanvas.parent,
        conf: canvas.setting
      };
    } // PREPARE DATA


    if (dataFromPopup.data.selected == "random") {
      var random = dataFromPopup.data.random;
      data = createRandomData(random.categories.value, random.items.value, random.min, random.max, random.randType, chartType);
      var tempData = JSON.parse(strConfig);
      tempData.data.random.data = [data.header].concat(_toConsumableArray(data.table));
      strConfig = JSON.stringify(tempData);
    } else if (dataFromPopup.data.selected == "table") {
      data = processData(dataFromPopup.data.csv);
    } else {
      data = processJSON(dataFromPopup.data.json.data, dataFromPopup.data.json.keys, dataFromPopup.data.json.header);
    } // PREPARE STACKED DATA


    if (chartType === "stackedAreaChart" || chartType === "verticalBarChart" || chartType === "horizontalBarChart" || chartType === "streamGraph") {
      for (var i = 1; i < data.rows; i++) {
        for (var j = 0; j < data.columns; j++) {
          data.table[i][j] = Number(data.table[i - 1][j]) + Number(data.table[i][j]);
        }
      }

      var zeroArray = new Array();

      for (var _i12 = 0; _i12 < data.columns; _i12++) {
        zeroArray[_i12] = 0;
      }

      ;
      data.table.unshift(zeroArray);
      data.rows = data.rows + 1; // New min and max

      data.max = Math.max.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
      data.min = Math.min.apply(Math, _toConsumableArray(data.table[data.rows - 1]));
    } // REMOVE LABELS AND GRIDS FOR SMALL CHARTS


    if (canvas.width < 200 && canvas.height < 100) {
      conf.labels.type = 0;
      conf.grid.type = 0;
      conf.lineChart.dotType = 0;
      numParam = false;
      numWidthParam = false;
    } // CREATE NODES ARRAY


    var nodes = [canvas.layer]; // SELECT CHART

    if (chartType == "lineChart") {
      if (conf.beginAtZero === 0) {
        if (data.min > 0) {
          data.min = 0;
        } else if (data.max < 0) {
          data.max = 0;
        }
      } // Scale Y axis


      var niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);
      data.niceMax = niceScales.niceMaximum;
      data.niceMin = niceScales.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var marginsData = calculateMargins(canvas, data, conf, chartType); // Labels

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, marginsData, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, marginsData.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, marginsData);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      } // Chart


      for (var _i13 = 0; _i13 < data.rows; _i13++) {
        createLineChart(canvas, conf, data, _i13, nodes);
      }
    } else if (chartType == "areaChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales.niceMaximum;
      data.niceMin = _niceScales.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i14 = 0; _i14 < data.rows; _i14++) {
        createAreaChart(canvas, conf, data, _i14, nodes);
      }
    } else if (chartType == "stackedAreaChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales2 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales2.niceMaximum;
      data.niceMin = _niceScales2.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData2 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData2, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData2.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData2);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i15 = 1; _i15 < data.rows; _i15++) {
        createStackedAreaChart(canvas, conf, data, _i15, nodes);
      }
    } else if (chartType == "verticalBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales3 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales3.niceMaximum;
      data.niceMin = _niceScales3.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData3 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData3.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData3.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "horizontal");
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i16 = 1; _i16 < data.rows; _i16++) {
        createVerticalBarChart(canvas, conf, data, _i16, nodes);
      }
    } else if (chartType == "horizontalBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales4 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales4.niceMaximum;
      data.niceMin = _niceScales4.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData4 = calculateMarginsHorizontal(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData4.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData4.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "vertical");
      }

      for (var _i17 = 1; _i17 < data.rows; _i17++) {
        createHorizontalBarChart(canvas, conf, data, _i17, nodes);
      }
    } else if (chartType == "groupedBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales5 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales5.niceMaximum;
      data.niceMin = _niceScales5.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData5 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData5.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData5.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "horizontal");
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      createGroupBarChart(canvas, conf, data, nodes);
    } else if (chartType == "groupedHorizontalBarChart") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales6 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales6.niceMaximum;
      data.niceMin = _niceScales6.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData6 = calculateMarginsHorizontal(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData6.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData6.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisDistrGrid(conf, canvas, data, nodes, "vertical");
      }

      createGroupHorizontalBarChart(canvas, conf, data, nodes);
    } else if (chartType == "streamGraph") {
      if (data.min > 0) {
        data.min = 0;
      } else if (data.max < 0) {
        data.max = 0;
      }

      var _niceScales7 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(data.min, data.max, numParam);

      data.niceMax = _niceScales7.niceMaximum;
      data.niceMin = _niceScales7.niceMinimum;

      for (var _i18 = 0; _i18 < data.rows; _i18++) {
        for (var _j4 = 0; _j4 < data.columns; _j4++) {
          data.table[_i18][_j4] = Number(data.table[_i18][_j4]) + (data.niceMax - Number(data.table[data.rows - 1][_j4])) / 2;
        }
      } // Margins


      if (conf.labels.type == 1 || conf.labels.type == 2) {
        conf.labels.type = 3;
      }

      var _marginsData7 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData7, chartType);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData7);
      }

      for (var _i19 = 1; _i19 < data.rows; _i19++) {
        createStackedAreaChart(canvas, conf, data, _i19, nodes);
      }
    } else if (chartType == "scatterPlot") {
      var _xMin = Math.min.apply(Math, _toConsumableArray(data.table[0])),
          _xMax = Math.max.apply(Math, _toConsumableArray(data.table[0])),
          _yMin = Math.min.apply(Math, _toConsumableArray(data.table[1])),
          _yMax = Math.max.apply(Math, _toConsumableArray(data.table[1]));

      if (conf.beginAtZero === 0) {
        if (_xMin > 0) {
          _xMin = 0;
        }

        if (_yMin > 0) {
          _yMin = 0;
        }
      }

      var xNiceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_xMin, _xMax, numWidthParam),
          yNiceScales = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_yMin, _yMax, numParam);
      data.xNiceMax = xNiceScales.niceMaximum;
      data.xNiceMin = xNiceScales.niceMinimum;
      data.yNiceMax = yNiceScales.niceMaximum;
      data.yNiceMin = yNiceScales.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.yNiceMin = canvas.yMin;
        data.yNiceMax = canvas.yMax;
      }

      if (canvas.xMin != null && canvas.xMax != null) {
        data.xNiceMin = canvas.xMin;
        data.xNiceMax = canvas.xMax;
      } // Margins


      var _marginsData8 = calculateMarginsHistogram(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData8.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData8.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      for (var _i20 = 0; _i20 < data.columns; _i20++) {
        createScatterPlot(canvas, conf, data, _i20, nodes);
      }
    } else if (chartType == "candlestickChart") {
      var maxLine = Math.max.apply(Math, _toConsumableArray(data.table[0])),
          minLine = Math.min.apply(Math, _toConsumableArray(data.table[3]));

      if (conf.beginAtZero === 0) {
        if (minLine > 0) {
          minLine = 0;
        }
      }

      var _niceScales8 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(minLine, maxLine, numParam);

      data.niceMax = _niceScales8.niceMaximum;
      data.niceMin = _niceScales8.niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.niceMin = canvas.yMin;
        data.niceMax = canvas.yMax;
      } // Margins


      var _marginsData9 = calculateMargins(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisLabels(canvas, data, nodes, conf, _marginsData9, chartType);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData9.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        xAxisGrid(conf, canvas, data, nodes, chartType, _marginsData9);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      createCandlestickChart(canvas, conf, data, nodes);
    } else if (chartType == "pieChart") {
      createPieChart(canvas, conf, data, index, nodes);
    } else if (chartType == "donutChart") {
      createDonutChart(canvas, conf, data, index, nodes);
    } else if (chartType == "progressChart") {
      createProgressChart(canvas, conf, data, index, nodes);
    } else if (chartType == "sparkline") {
      var max = Math.max.apply(Math, _toConsumableArray(data.table[index])),
          min = Math.min.apply(Math, _toConsumableArray(data.table[index])),
          _niceScales9 = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(min, max, false);

      max = _niceScales9.niceMaximum;
      min = _niceScales9.niceMinimum;
      createSparkline(canvas, conf, data, max, min, index, nodes);
    } else if (chartType == "histogram") {
      var inRange = function inRange(x, min, max) {
        return (x - min) * (x - max) <= 0;
      };

      var transformData = function transformData(data) {
        var minStepPx = 10;

        if (canvas.width < 200 && canvas.height < 100) {
          minStepPx = 5;
        }

        var range = data.xNiceMax - data.xNiceMin,
            maxNumTicks = Math.floor(canvas.width / minStepPx),
            dividers = [0.1, 0.2, 0.5];
        var step = dividers[0],
            numLines = Math.ceil(range / step),
            i = 0,
            count = 1;

        while (numLines >= maxNumTicks) {
          step = dividers[i] * count;
          numLines = Math.ceil(range / step);

          if (i === 2) {
            i = 0;
            count = count * 10;
          } else {
            i++;
          }
        }

        var newData = [];

        var _loop = function _loop(_i21) {
          var countOfNums = 0;
          data.table[0].forEach(function (num) {
            if (inRange(num, step * _i21, step * (_i21 + 1))) {
              countOfNums += 1;
            }
          });
          newData.push(countOfNums);
        };

        for (var _i21 = 0; _i21 < data.xNiceMax / step; _i21++) {
          _loop(_i21);
        }

        return newData;
      };

      var _min = Math.min.apply(Math, _toConsumableArray(data.table[0])),
          _max = Math.max.apply(Math, _toConsumableArray(data.table[0]));

      data.xNiceMin = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_min, _max, numWidthParam).niceMinimum;
      data.xNiceMax = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_min, _max, numWidthParam).niceMaximum;

      var newData = transformData(data),
          _yMin2 = Math.min.apply(Math, _toConsumableArray(newData)),
          _yMax2 = Math.max.apply(Math, _toConsumableArray(newData));

      data.table[1] = newData;

      if (conf.beginAtZero === 0) {
        if (_yMin2 > 0) {
          _yMin2 = 0;
        }
      }

      data.yNiceMax = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_yMin2, _yMax2, numParam).niceMaximum;
      data.yNiceMin = Object(_nicenum__WEBPACK_IMPORTED_MODULE_0__["calculateNiceNum"])(_yMin2, _yMax2, numParam).niceMinimum;

      if (canvas.yMin != null && canvas.yMax != null) {
        data.yNiceMin = canvas.yMin;
        data.yNiceMax = canvas.yMax;
      } // Margins


      var _marginsData10 = calculateMarginsHistogram(canvas, data, conf, chartType); // Labels


      if (conf.labels.type == 1 || conf.labels.type == 3) {
        yAxisLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData10.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        yAxisLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData10.minW);
      } // Grid


      if (conf.grid.type == 1 || conf.grid.type == 3) {
        yAxisGrid(conf, canvas, data, nodes, "horizontal", chartType);
      }

      if (conf.grid.type == 1 || conf.grid.type == 2) {
        yAxisGrid(conf, canvas, data, nodes, "vertical", chartType);
      }

      createHistogram(canvas, conf, data, nodes);
    } else if (chartType == "heatmap") {
      var horizontalHeaders = [];

      if (dataFromPopup.data.selected == "table" && (dataFromPopup.data.csv.type === "google" || dataFromPopup.data.csv.type === "csv")) {
        dataFromPopup.data.csv.columns.forEach(function (column) {
          if (column.checked) {
            horizontalHeaders.push(column.name);
          }
        });
      } else if (dataFromPopup.data.selected == "json") {
        dataFromPopup.data.json.keys.forEach(function (key) {
          if (key.checked) {
            horizontalHeaders.push(key.name);
          }
        });
      } else {
        for (var _i22 = 0; _i22 < data.rows; _i22++) {
          horizontalHeaders[_i22] = "Text";
        }
      }

      data.horizontalHeaders = horizontalHeaders; // Margins

      var _marginsData11 = calculateMarginsHeatmap(canvas, data, conf, chartType);

      console.log("margins: true"); // Labels

      if (conf.labels.type == 1 || conf.labels.type == 3) {
        xAxisDistrLabels(canvas, data, nodes, conf, "vertical", chartType, _marginsData11.minW);
      }

      if (conf.labels.type == 1 || conf.labels.type == 2) {
        xAxisDistrLabels(canvas, data, nodes, conf, "horizontal", chartType, _marginsData11.minW);
      }

      console.log("labels: true");
      createHeatmap(canvas, conf, data, nodes);
      console.log(nodes);
    } // CREATE GROUP


    var chartGroup = new Group({
      name: dataFromPopup.data.fullChartName,
      parent: canvas.parent
    });

    (_chartGroup$layers = chartGroup.layers).push.apply(_chartGroup$layers, nodes);

    Settings.setLayerSettingForKey(chartGroup, 'localConf', JSON.parse(editableConfig));
    chartGroup.adjustToFit(); // UPDATE DATA

    dataFromPopup = JSON.parse(strConfig);
  });
} // TEST CHART

function testChart(canvas, configuration) {
  var sketch = __webpack_require__(/*! sketch */ "sketch"),
      ShapePath = sketch.ShapePath,
      doc = sketch.getSelectedDocument();

  var artboard = doc.getLayerWithID(canvas[0].layer);
  artboard.selected = false;
  var canvases = {
    l: [500, 310],
    m: [250, 150],
    s: [50, 30]
  },
      margin = 30,
      step = 0,
      chartL = [['lineChart', 2, 10], ['areaChart', 2, 10], ["stackedAreaChart", 3, 10], ["streamGraph", 3, 10], ["verticalBarChart", 2, 10], ["horizontalBarChart", 2, 5], ["groupedBarChart", 3, 5], ["groupedHorizontalBarChart", 2, 5], ["scatterPlot", 2, 20], ["candlestickChart", 4, 20], ["heatmap", 6, 4], ["histogram", 1, 100], ["pieChart", 1, 5], ["donutChart", 1, 5], ["progressChart", 1, 1], ["sparkline", 1, 40]],
      chartM = [['lineChart', 2, 5], ['areaChart', 2, 5], ["stackedAreaChart", 3, 5], ["streamGraph", 3, 5], ["verticalBarChart", 2, 5], ["horizontalBarChart", 2, 3], ["groupedBarChart", 2, 5], ["groupedHorizontalBarChart", 2, 3], ["scatterPlot", 2, 20], ["candlestickChart", 4, 10], ["heatmap", 6, 4], ["histogram", 1, 100], ["pieChart", 1, 5], ["donutChart", 1, 5], ["progressChart", 1, 1], ["sparkline", 1, 20]],
      chartS = [['lineChart', 2, 5], ['areaChart', 2, 5], ["stackedAreaChart", 3, 5], ["streamGraph", 3, 5], ["verticalBarChart", 2, 5], ["horizontalBarChart", 2, 3], ["groupedBarChart", 2, 5], ["groupedHorizontalBarChart", 2, 3], ["scatterPlot", 2, 10], ["candlestickChart", 4, 5], ["heatmap", 6, 4], ["histogram", 1, 100], ["pieChart", 1, 5], ["donutChart", 1, 5], ["progressChart", 1, 1], ["sparkline", 1, 10]];
  chartL.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin,
          width: canvases.l[1],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin,
          width: canvases.l[0],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas);
      _testCanvas.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.l[0] + 30;
  });
  step = 0;
  margin = 30;
  chartL.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];
    newConf.settings.labels.type = 0;
    newConf.settings.grid.type = 0;

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin + 340,
          width: canvases.l[1],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas2 = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin + 340,
          width: canvases.l[0],
          height: canvases.l[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas2);
      _testCanvas2.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.l[0] + 30;
  });
  step = 0;
  margin = 30;
  chartM.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin + 680,
          width: canvases.m[1],
          height: canvases.m[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas3 = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin + 680,
          width: canvases.m[0],
          height: canvases.m[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas3);
      _testCanvas3.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.m[0] + 30;
  });
  step = 0;
  margin = 30;
  chartS.forEach(function (chartType) {
    var newConfString = JSON.stringify(configuration),
        newConf = JSON.parse(newConfString);
    newConf.data.chartName = chartType[0];
    newConf.data.random.categories.value = chartType[1];
    newConf.data.random.items.value = chartType[2];

    if (chartType[0] === "pieChart" || chartType[0] === "donutChart" || chartType[0] === "progressChart") {
      var testCanvas = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Oval,
        frame: {
          x: margin + step,
          y: margin + 680 + 180,
          width: canvases.s[1],
          height: canvases.s[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });
      artboard.layers.push(testCanvas);
      testCanvas.selected = true;
    } else {
      var _testCanvas4 = new ShapePath({
        name: 'Test',
        shapeType: ShapePath.ShapeType.Rectangle,
        frame: {
          x: margin + step,
          y: margin + 680 + 180,
          width: canvases.s[0],
          height: canvases.s[1]
        },
        style: {
          fills: [],
          borders: []
        }
      });

      artboard.layers.push(_testCanvas4);
      _testCanvas4.selected = true;
    }

    var newCanvas = getCanvas()[0];
    createChart(newCanvas, newConf);
    step += canvases.s[0] + 30;
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/nicenum.js":
/*!************************!*\
  !*** ./src/nicenum.js ***!
  \************************/
/*! exports provided: calculateNiceNum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateNiceNum", function() { return calculateNiceNum; });
function calculateNiceNum(minNum, maxNum, height) {
  // Nice max and min functions
  var minPoint,
      maxPoint,
      maxTicks = 10,
      minStep = 30,
      range,
      tickSpacing,
      niceMin,
      niceMax;
  /**
   * Instantiates a new instance of the NiceScale class.
   *
   *  min the minimum data point on the axis
   *  max the maximum data point on the axis
   */

  function niceScale(min, max) {
    minPoint = min;
    maxPoint = max;
    calculate();

    if (height != false) {
      var _range = niceMax - niceMin,
          maxNumTicks = Math.floor(height / minStep),
          dividers = [0.1, 0.2, 0.5];

      var step = dividers[0],
          numLines = Math.ceil(_range / step),
          i = 0,
          count = 1;

      while (numLines >= maxNumTicks) {
        step = dividers[i] * count;
        numLines = Math.ceil(_range / step);

        if (i === 2) {
          i = 0;
          count = count * 10;
        } else {
          i++;
        }
      }

      niceMax = niceMin + step * numLines;
    }

    return {
      niceMinimum: niceMin,
      niceMaximum: niceMax
    };
  }
  /**
   * Calculate and update values for tick spacing and nice
   * minimum and maximum data points on the axis.
   */


  function calculate() {
    range = niceNum(maxPoint - minPoint, false);
    tickSpacing = niceNum(range / (maxTicks - 1), true);
    niceMin = Math.floor(minPoint / tickSpacing) * tickSpacing;
    niceMax = Math.ceil(maxPoint / tickSpacing) * tickSpacing;
  }
  /**
   * Returns a "nice" number approximately equal to range Rounds
   * the number if round = true Takes the ceiling if round = false.
   *
   *  localRange the data range
   *  round whether to round the result
   *  a "nice" number to be used for the data range
   */


  function niceNum(localRange, round) {
    var exponent;
    /** exponent of localRange */

    var fraction;
    /** fractional part of localRange */

    var niceFraction;
    /** nice, rounded fraction */

    exponent = Math.floor(Math.log10(localRange));
    fraction = localRange / Math.pow(10, exponent);

    if (round) {
      if (fraction < 1.5) niceFraction = 1;else if (fraction < 3) niceFraction = 2;else if (fraction < 7) niceFraction = 5;else niceFraction = 10;
    } else {
      if (fraction <= 1) niceFraction = 1;else if (fraction <= 2) niceFraction = 2;else if (fraction <= 5) niceFraction = 5;else niceFraction = 10;
    }

    return niceFraction * Math.pow(10, exponent);
  }

  return niceScale(minNum, maxNum);
}

/***/ }),

/***/ "./src/update.js":
/*!***********************!*\
  !*** ./src/update.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common */ "./src/common.js");

/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings"),
      UI = __webpack_require__(/*! sketch/ui */ "sketch/ui"),
      fetch = __webpack_require__(/*! sketch-polyfill-fetch */ "./node_modules/sketch-polyfill-fetch/lib/index.js");

  var canvas = Object(_common__WEBPACK_IMPORTED_MODULE_0__["getCanvas"])(context)[0],
      email = Settings.globalSettingForKey('user_email'),
      status = Settings.globalSettingForKey('user_status'),
      templateURL = "https://chart.pavelkuligin.ru/settings/" + email,
      templates = JSON.parse(Settings.globalSettingForKey('chartplugin.templates'));

  if (canvas.length > 0) {
    canvas.forEach(function (canvas) {
      if (canvas.conf.settings.updatable) {
        templates.forEach(function (template) {
          if (template.id === Number(canvas.conf.settings.id)) {
            canvas.conf.settings = template;
            canvas.conf.settings.updatable = true;
          }
        });
      }

      if (canvas.conf.data.selected == "table" && canvas.conf.data.csv.type == "google") {
        UI.message('Fetching data...');
        var regexSheet = /d\/([a-zA-Z0-9-_]+)/g;
        var regexId = /gid=([0-9]+)/g;
        var sheets = regexSheet.exec(canvas.conf.data.csv.name);
        var ids = regexId.exec(canvas.conf.data.csv.name);
        var sheetsLink = "https://sheets.googleapis.com/v4/spreadsheets/" + sheets[1] + "?&fields=sheets.properties&key=AIzaSyAOyxH85I1NqnV2Ta-rHKn7_MZpwVBTzmk";
        fetch(sheetsLink).then(function (res) {
          return res.json();
        }).then(function (data) {
          data.sheets.forEach(function (sheet) {
            if (sheet.properties.sheetId === Number(ids[1])) {
              var title = sheet.properties.title.replace(/ /g, "%20");
              var valuesLink = "https://sheets.googleapis.com/v4/spreadsheets/" + sheets[1] + "/values/%27" + title + "%27%21A1:BZ100?key=AIzaSyAOyxH85I1NqnV2Ta-rHKn7_MZpwVBTzmk";
              fetch(valuesLink).then(function (res) {
                return res.json();
              }).then(function (valuesArray) {
                valuesArray.values.shift();
                canvas.conf.data.csv.data = valuesArray.values;
                var finalCanvas = [canvas];
                Object(_common__WEBPACK_IMPORTED_MODULE_0__["createChart"])(finalCanvas, canvas.conf);
              });
            }
          });
        });
      } else if (canvas.conf.data.selected == "json" && canvas.conf.data.json.jsonLink != null) {
        UI.message('Fetching data...');
        fetch(canvas.conf.data.json.jsonLink).then(function (res) {
          return {
            json: res.json()._value
          };
        }).then(function (jsonObject) {
          canvas.conf.data.json.data = jsonObject.json;
          var finalCanvas = [canvas];
          Object(_common__WEBPACK_IMPORTED_MODULE_0__["createChart"])(finalCanvas, canvas.conf);
        });
      } else {
        var finalCanvas = [canvas];
        Object(_common__WEBPACK_IMPORTED_MODULE_0__["createChart"])(finalCanvas, canvas.conf);
        UI.message('🎉 Chart updated!');
      }
    });
  } else {
    UI.message('Select chart to update');
  }
});

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__update.js.map